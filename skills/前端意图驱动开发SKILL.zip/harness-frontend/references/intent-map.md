# 意图映射层（INTENT_MAP）

> 组件与 API 解耦的关键机制

## 核心问题

**传统做法的痛点：**
- 组件直接调用 API，知道太多实现细节
- API 字段改变，组件代码必须跟着改
- 前后端开发时互相等待，效率低
- AI 写组件时不知道有哪些 API，AI 写 API 时不知道哪些组件在用

**根本原因：** 组件和 API 强耦合，缺少中间的意图翻译层。

## 什么是意图映射层

INTENT_MAP 是组件和 API 之间的翻译层，回答一个核心问题：

**组件需要的数据，从哪个 API 的哪些字段来？**

```typescript
// api/intent-map.ts
export const INTENT_MAP = {
  'UserCard': {
    // 这个组件从哪个 API 获取数据
    source: 'GET /api/users',

    // 字段映射：组件字段 → API 字段
    fields: {
      // 组件需要的字段名    API 实际的字段名           置信度
      'id':             { from: 'user.id',              confidence: 1.0 },
      'name':           { from: 'user.fullName',        confidence: 1.0 },
      'avatar':         { from: 'user.avatarUrl',       confidence: 0.9 },
      'department':     { from: 'user.dept.name',       confidence: 0.7, fallback: '未知部门' },
      'badge':          { from: 'user.vipLevel',        confidence: 0.3, fallback: null },
      //                                                 ↑ 实验性字段，可能不存在
    }
  }
}
```

## 三方受益

### 1. 组件开发者（前端）

**不需要知道：**
- API 路径是什么
- API 返回结构长什么样
- 字段名在 API 里叫什么

**只需要知道：**
- 我需要哪些数据
- 数据的类型是什么

```typescript
// UserCard/types.ts
// 组件只定义自己需要的数据结构
export interface UserCardProps {
  id: string
  name: string
  avatar?: string
  department?: string
  badge?: number | null
}

// UserCard/index.tsx
// 组件只用数据，不关心数据从哪来
export const UserCard: FC<UserCardProps> = ({ id, name, avatar, department, badge }) => {
  return (
    <div className="flex items-center gap-4 p-4 bg-white rounded-lg shadow">
      {avatar && <img src={avatar} alt={name} className="w-12 h-12 rounded-full" />}
      <div>
        <h3 className="font-semibold text-gray-900">{name}</h3>
        {department && <p className="text-sm text-gray-600">{department}</p>}
        {badge && <span className="text-xs bg-yellow-100 text-yellow-800 px-2 py-1 rounded">VIP {badge}</span>}
      </div>
    </div>
  )
}
```

### 2. API 开发者（后端）

**不需要：**
- 猜测前端会怎么用数据
- 提前和前端开会讨论字段名

**只需要：**
- 查看 INTENT_MAP 了解前端需要哪些字段
- 按照 confidence 优先级决定实现顺序

```typescript
// 后端看到 INTENT_MAP 后知道：
// - confidence: 1.0 的字段必须实现（core）
// - confidence: 0.7 的字段可以迭代实现（assumed）
// - confidence: 0.3 的字段暂时不实现，前端用 Mock（experimental）
```

### 3. 维护者

**API 字段改名时：**
```typescript
// 只需要改 INTENT_MAP，组件代码不动
fields: {
  'name': {
    from: 'user.displayName',  // 从 fullName 改成 displayName
    confidence: 1.0
  }
}
```

**API 删除字段时：**
```typescript
// 删除映射，使用 fallback，组件不报错
fields: {
  'department': {
    from: 'user.dept.name',
    confidence: 0.0,           // 标记为已废弃
    fallback: '未知部门'        // 提供默认值
  }
}
```

## 完整工作流程

### 第一步：组件定义数据需求

```typescript
// ApprovalCard/types.ts
/**
 * INTENT: 展示做决策所需的最少信息
 * SUCCESS_SIGNAL: 用户在卡片上停留 < 5秒后做出决策且不打开详情
 *
 * DATA_REQUIREMENTS:
 *   - amount (必须) - 核心决策依据
 *   - applicant (必须) - 知道是谁的申请
 *   - status (必须) - 当前状态
 *   - urgency (可选) - 帮助排序，假设字段
 */
export interface ApprovalCardProps {
  id: string
  amount: number
  applicant: {
    name: string
    department?: string
  }
  status: 'pending' | 'approved' | 'rejected'
  urgency?: 'high' | 'medium' | 'low'
}
```

### 第二步：创建意图映射

```typescript
// api/intent-map.ts
export const INTENT_MAP = {
  'ApprovalCard': {
    source: 'GET /api/approvals',

    fields: {
      'id': {
        from: 'approval.id',
        confidence: 1.0
      },
      'amount': {
        from: 'approval.amount',
        confidence: 1.0
      },
      'applicant.name': {
        from: 'approval.applicant.name',
        confidence: 1.0
      },
      'applicant.department': {
        from: 'approval.applicant.dept',
        confidence: 0.7,
        fallback: null
      },
      'status': {
        from: 'approval.status',
        confidence: 1.0
      },
      'urgency': {
        from: 'approval.priority',     // 注意：后端叫 priority
        confidence: 0.6,
        fallback: null,
        // 假设：紧急程度帮助审批者排序
        // 验证：观察用户是否按 urgency 筛选
        assumption: '用户会根据紧急程度优先处理'
      }
    }
  }
}
```

### 第三步：数据映射 Hook

```typescript
// hooks/useIntentData.ts
import { INTENT_MAP } from '@/api/intent-map'

/**
 * 根据意图映射自动转换 API 数据为组件需要的形状
 */
export function useIntentData<T>(
  intentKey: string,
  rawData: any
): T {
  const mapping = INTENT_MAP[intentKey]

  if (!mapping) {
    throw new Error(`Intent mapping not found: ${intentKey}`)
  }

  const result: any = {}

  for (const [componentField, config] of Object.entries(mapping.fields)) {
    const value = getNestedValue(rawData, config.from)

    // 使用实际值或 fallback
    result[componentField] = value !== undefined
      ? value
      : config.fallback
  }

  return result as T
}

// 辅助函数：获取嵌套对象的值
function getNestedValue(obj: any, path: string): any {
  return path.split('.').reduce((current, key) => current?.[key], obj)
}
```

### 第四步：组件使用映射数据

```typescript
// pages/ApprovalList.tsx
import { useQuery } from '@tanstack/react-query'
import { useIntentData } from '@/hooks/useIntentData'
import { ApprovalCard, ApprovalCardProps } from '@/components/ApprovalCard'

export const ApprovalList = () => {
  // 1. 获取原始 API 数据
  const { data: rawData, isLoading } = useQuery({
    queryKey: ['approvals'],
    queryFn: () => fetch('/api/approvals').then(r => r.json())
  })

  // 2. 通过意图映射转换数据
  const approvals = rawData?.approvals.map((item: any) =>
    useIntentData<ApprovalCardProps>('ApprovalCard', item)
  )

  if (isLoading) return <Spinner />

  return (
    <div className="space-y-4">
      {approvals?.map((approval) => (
        <ApprovalCard key={approval.id} {...approval} />
      ))}
    </div>
  )
}
```

## 置信度分层与映射

意图映射层的 confidence 与状态分层对应：

```typescript
export const INTENT_MAP = {
  'ApprovalCard': {
    source: 'GET /api/approvals',

    fields: {
      // Core 层（confidence: 0.9-1.0）
      // 核心业务字段，必须有，后端必须实现
      'id':     { from: 'approval.id',     confidence: 1.0 },
      'amount': { from: 'approval.amount', confidence: 1.0 },
      'status': { from: 'approval.status', confidence: 1.0 },

      // Assumed 层（confidence: 0.6-0.8）
      // 假设有用的字段，后端应该实现，但可以迭代
      'urgency': {
        from: 'approval.priority',
        confidence: 0.7,
        fallback: null,
        assumption: '用户会根据紧急程度排序'
      },

      // Experimental 层（confidence: 0.0-0.5）
      // 实验性字段，后端暂时不实现，前端用 Mock
      'similarCases': {
        from: 'approval.similar',
        confidence: 0.3,
        fallback: [],
        note: '成本高，价值未验证，前端用 Mock 探索'
      }
    }
  }
}
```

## 自动生成 API Schema

意图映射可以自动生成给后端的接口文档：

```typescript
// scripts/generate-api-schema.ts
import { INTENT_MAP } from '../api/intent-map'

/**
 * 根据 INTENT_MAP 生成 API Schema
 * 输出给后端智能体使用
 */
export function generateAPISchema() {
  const schemas: Record<string, any> = {}

  for (const [componentName, mapping] of Object.entries(INTENT_MAP)) {
    const endpoint = mapping.source

    if (!schemas[endpoint]) {
      schemas[endpoint] = {
        endpoint,
        intent: `为 ${componentName} 组件提供数据`,
        fields: {},
        usedBy: []
      }
    }

    schemas[endpoint].usedBy.push(componentName)

    // 收集字段需求
    for (const [componentField, config] of Object.entries(mapping.fields)) {
      const apiField = config.from

      if (!schemas[endpoint].fields[apiField]) {
        schemas[endpoint].fields[apiField] = {
          type: inferType(componentField),
          confidence: config.confidence,
          requiredBy: [],
          assumption: config.assumption
        }
      }

      schemas[endpoint].fields[apiField].requiredBy.push(componentName)

      // 更新最高 confidence
      if (config.confidence > schemas[endpoint].fields[apiField].confidence) {
        schemas[endpoint].fields[apiField].confidence = config.confidence
      }
    }
  }

  return schemas
}

// 生成给后端的 YAML 格式
export function exportToYAML(schemas: any) {
  return Object.values(schemas).map(schema => `
GET ${schema.endpoint}:
  intent: ${schema.intent}
  used_by: ${schema.usedBy.join(', ')}

  fields:
${Object.entries(schema.fields).map(([field, info]: [string, any]) => `
    ${field}:
      type: ${info.type}
      confidence: ${info.confidence}
      required_by: ${info.requiredBy.join(', ')}
      ${info.assumption ? `assumption: "${info.assumption}"` : ''}
      ${info.confidence < 0.6 ? 'note: "experimental, use mock first"' : ''}
`).join('')}
  `).join('\n\n')
}
```

## Mock 数据策略

对于 confidence < 0.6 的字段，前端用 Mock 数据先探索：

```typescript
// api/mock-data.ts
import { INTENT_MAP } from './intent-map'

/**
 * 为低 confidence 字段生成 Mock 数据
 */
export function getMockFields(intentKey: string) {
  const mapping = INTENT_MAP[intentKey]
  const mockFields: Record<string, any> = {}

  for (const [field, config] of Object.entries(mapping.fields)) {
    // confidence < 0.6 的字段使用 Mock
    if (config.confidence < 0.6) {
      mockFields[field] = generateMockValue(field, config)
    }
  }

  return mockFields
}

function generateMockValue(field: string, config: any) {
  // 根据字段名和类型生成合理的 Mock 数据
  if (field.includes('urgency')) {
    return ['high', 'medium', 'low'][Math.floor(Math.random() * 3)]
  }
  if (field.includes('similar')) {
    return []  // 空数组
  }
  return config.fallback
}
```

## 最佳实践

### 1. 映射文件的组织

```
api/
├── intent-map.ts           # 主映射文件
├── intent-map/
│   ├── approval.ts         # 审批相关组件的映射
│   ├── user.ts             # 用户相关组件的映射
│   └── dashboard.ts        # 仪表盘相关组件的映射
└── schemas/                # 自动生成的 API Schema
    └── api-schema.yaml
```

### 2. 命名约定

- 组件字段名：语义化，符合业务逻辑（如 `applicant.name`）
- API 字段名：可以不同，通过映射转换（如 `approval.applicant.name`）
- 映射 key：使用组件名（如 `'ApprovalCard'`）

### 3. Confidence 更新规则

```typescript
// 当 SUCCESS_SIGNAL 验证字段有效时
updateIntentMap('ApprovalCard', 'urgency', {
  confidence: 0.7 + 0.1  // 从 0.7 提升到 0.8
})

// 当 SUCCESS_SIGNAL 验证字段无效时
updateIntentMap('ApprovalCard', 'urgency', {
  confidence: 0.7 - 0.2  // 从 0.7 降低到 0.5
  // confidence < 0.5 后自动标记为待移除
})
```

### 4. 与后端协作

**前端输出：**
```bash
npm run generate-api-schema
# 生成 api/schemas/api-schema.yaml
```

**后端接收：**
- 读取 `api-schema.yaml`
- confidence >= 0.9 的字段优先实现
- confidence < 0.6 的字段暂不实现

**联调验证：**
- 后端实现完成后，前端更新 confidence
- INTENT_MAP 是唯一需要同步的文件

## 总结

意图映射层解决的核心问题：

1. **解耦** - 组件和 API 不再直接依赖
2. **清晰** - 数据需求和来源一目了然
3. **可维护** - API 变更只需改映射文件
4. **协作** - 前后端通过映射文件异步协作
5. **渐进** - confidence 驱动字段的实现优先级

**记住：组件不应该知道 API，组件只应该知道自己需要什么数据。**
