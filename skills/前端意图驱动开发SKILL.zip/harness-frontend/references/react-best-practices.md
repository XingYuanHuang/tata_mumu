# React 实现最佳实践（基于实战经验）

> 本文档总结了多个项目实战中遇到的问题和最佳解决方案

## 一、使用 React 基础模板（强烈推荐）

**⚠️ 不要每次都从头创建项目！**

### 为什么需要模板？

经过黄山旅游网站、微信应用、技术博客等多个项目的实战，我们遇到了很多重复的配置问题：
- Tailwind v3 vs v4 的兼容性问题
- PostCSS 配置错误
- Zustand 使用不当导致无限循环
- 相对路径引用混乱
- 依赖版本冲突

**解决方案：** 使用预配置好的模板，避免重复踩坑。

### 模板位置

```
${SKILL_BASE_DIR}/templates/react-base/
```

### 快速使用

```bash
# 步骤 1：在项目根目录下复制模板内容
cd <项目名>
cp -r ${SKILL_BASE_DIR}/templates/react-base/* .
cp -r ${SKILL_BASE_DIR}/templates/react-base/.gitignore .

# 步骤 2：安装依赖
npm install

# 步骤 3：启动开发服务器
npm run dev > /tmp/dev-server.log 2>&1 &
echo "开发服务器已启动"
```

### 模板包含的内容

```
react-base/
├── package.json              # ✅ 稳定的依赖版本
│   ├── react@18.3.1
│   ├── tailwindcss@3.4.19    # 使用 v3（不是 v4）
│   ├── zustand@5.0.2
│   └── react-router-dom@6.26.1
│
├── vite.config.ts            # ✅ Vite 配置
├── tsconfig.json             # ✅ TypeScript 配置
├── tailwind.config.js        # ✅ Tailwind v3 配置
├── postcss.config.js         # ✅ 正确的 PostCSS 配置
├── index.html                # ✅ 入口 HTML
│
└── src/
    ├── main.tsx              # ✅ 应用入口
    ├── App.tsx               # ✅ 根组件（含路由示例）
    ├── index.css             # ✅ 全局样式（Google Fonts）
    ├── store/index.ts        # ✅ Zustand 最佳实践模板
    ├── types/index.ts        # ✅ TypeScript 类型定义
    ├── components/           # ✅ 共享组件目录
    ├── pages/                # ✅ 页面组件目录
    └── api/mock/             # ✅ Mock 数据目录
```

### 预防的常见错误

1. **✅ Tailwind CSS 配置正确**
   - 使用稳定的 v3 版本
   - PostCSS 配置避免 @tailwindcss/postcss 冲突
   - index.css 中避免复杂的 @layer base 用法

2. **✅ Zustand 最佳实践**
   - 提供了正确的 selector 使用模板
   - 避免无限循环的示例代码
   - 正确的 persist 中间件配置

3. **✅ 目录结构规范**
   - 清晰的文件组织
   - 正确的相对路径引用规范

---

## 二、错误检测机制（强制执行）

**⚠️ 在打开浏览器前必须检测错误！**

### 检测流程

```bash
# 步骤 1：等待 Vite 编译完成（至少 3 秒）
sleep 3

# 步骤 2：检查编译日志是否有错误
tail -100 /tmp/dev-server.log | grep -iE "(error|failed|cannot)" > /tmp/errors.txt

# 步骤 3：分析错误并修复
if [ -s /tmp/errors.txt ]; then
    echo "❌ 检测到错误，正在分析..."
    # 显示错误并修复
    cat /tmp/errors.txt
else
    echo "✅ 编译成功"
    open http://localhost:3000/
fi
```

### 常见错误类型及修复

#### 错误 1：导入路径错误

**错误信息：**
```
Failed to resolve import "../components/Header" from "src/pages/Home/index.tsx"
```

**原因分析：**
- 相对路径层级计算错误
- 忘记了目录嵌套层级

**修复方案：**
```typescript
// ❌ 错误：页面在 src/pages/Home/index.tsx，但用了 ../components
import Header from '../components/Header';

// ✅ 正确：需要上两级才能到 src/
import Header from '../../components/Header';
```

**路径规则：**
- 同级目录：`./Component`
- 上一级：`../Component`
- 上两级：`../../Component`
- 三级以上：考虑配置路径别名

---

#### 错误 2：Zustand selector 无限循环

**错误信息：**
```
Maximum update depth exceeded. This can happen when a component repeatedly
calls setState inside componentWillUpdate or componentDidUpdate.
```

**原因分析：**
- selector 每次都返回新对象/数组
- React 认为状态变化，触发重渲染
- 重渲染又调用 selector，返回新对象
- 导致无限循环

**❌ 错误示例：**
```typescript
// 这会导致无限循环！
function Home() {
  const articles = useStore((state) => state.getPublishedArticles()).slice(0, 6);
  // getPublishedArticles() 每次返回新数组
  // slice() 又创建新数组
  // React 每次都认为 articles 变化了
}
```

**✅ 修复方案 1：直接获取数据**
```typescript
function Home() {
  const articles = useStore((state) =>
    state.articles.filter(a => a.status === 'published').slice(0, 6)
  );
  // 只在 articles 数组引用变化时才重新计算
}
```

**✅ 修复方案 2：使用 useMemo**
```typescript
import { useMemo } from 'react';

function Home() {
  const getPublishedArticles = useStore((state) => state.getPublishedArticles);
  const articles = useMemo(
    () => getPublishedArticles().slice(0, 6),
    [getPublishedArticles]
  );
  // 缓存计算结果
}
```

**Store 最佳实践：**
```typescript
// ✅ 推荐：只存储数据，不存储计算函数
interface AppState {
  articles: Article[];
  // 不推荐：getPublishedArticles: () => Article[];
}

// ✅ 在组件中计算派生状态
const publishedArticles = useStore((state) =>
  state.articles.filter(a => a.status === 'published')
);
```

---

#### 错误 3：Tailwind CSS 配置问题

**错误信息：**
```
Cannot apply unknown utility class `bg-slate-950`
```

**原因分析：**
- 安装了 Tailwind v4 的 @tailwindcss/postcss
- 或 PostCSS 配置不正确
- 或在 @layer base 中使用了复杂的 @apply

**修复方案：**

1. **检查 package.json：**
```json
{
  "devDependencies": {
    "tailwindcss": "^3.4.19",  // ✅ 使用 v3
    "postcss": "^8.4.49",
    "autoprefixer": "^10.4.20"
  }
}
```

2. **检查 postcss.config.js：**
```javascript
// ✅ 正确配置
export default {
  plugins: {
    tailwindcss: {},  // 不是 '@tailwindcss/postcss'
    autoprefixer: {},
  },
}
```

3. **检查 index.css：**
```css
/* ✅ 简化 @layer base */
@tailwind base;
@tailwind components;
@tailwind utilities;

body {
  margin: 0;
  padding: 0;
  font-family: 'Inter', sans-serif;
}

/* ❌ 避免在 @layer base 中使用 @apply */
/* @layer base {
  * {
    @apply border-border;  // 这可能导致错误
  }
} */
```

4. **如果依赖混乱，重新安装：**
```bash
rm -rf node_modules package-lock.json
npm install
```

---

#### 错误 4：TypeScript 类型错误

**错误信息：**
```
Type 'string' is not assignable to type 'number'
```

**修复方案：**
- 检查类型定义，确保数据类型匹配
- 使用类型断言或类型转换
- 更新类型定义文件

---

### 错误检测后的输出模板

**✅ 无错误时：**
```
✅ React 应用已成功启动！

**访问地址：** http://localhost:3000/

**已实现功能：**
- ✅ 首页
- ✅ 文章列表
- ✅ 文章详情
- ✅ 标签页
- ✅ 关于页

**技术栈：**
- React 18 + TypeScript
- Tailwind CSS v3
- React Router v6
- Zustand

请打开浏览器查看效果！
```

**⚠️ 有警告但不影响使用：**
```
⚠️ 应用已启动，但有以下非关键问题：

1. ArticleDetail 组件有类型警告（不影响使用）
2. 部分页面待优化

**可以正常访问：** http://localhost:3000/

是否需要我修复这些问题？
```

**❌ 有严重错误：**
```
❌ 检测到编译错误，正在修复...

**错误类型：** 导入路径错误
**错误文件：** src/pages/Home/index.tsx
**错误原因：** 使用了错误的相对路径

正在修复...
✅ 已修复！重新编译中...
```

---

## 三、完整的 React 实现流程

### 流程总览

```
1. 原型确认 ✅
   ↓
2. 使用模板快速初始化 ⚡
   ↓
3. 创建意图树和实现计划 📋
   ↓
4. 一口气实现所有功能 💪
   ↓
5. 错误检测和修复 🔍
   ↓
6. 启动并打开浏览器 🚀
   ↓
7. 功能清单检查 ✅
```

### 详细步骤

#### 步骤 1：原型确认

（参考 intent-driven-dev.md）

#### 步骤 2：使用模板初始化

```bash
# 进入项目根目录
cd <项目名>

# 复制模板内容
cp -r ${SKILL_BASE_DIR}/templates/react-base/* .
cp -r ${SKILL_BASE_DIR}/templates/react-base/.gitignore .

# 安装依赖
npm install

# 后台启动开发服务器
npm run dev > /tmp/dev-server.log 2>&1 &
DEV_PID=$!
```

#### 步骤 3：创建意图树

在项目根目录创建 `intent-tree.md`，记录：
- 所有页面列表
- 所有组件列表
- 组件调用关系
- 实现清单

#### 步骤 4：实现所有功能

按顺序创建：
1. TypeScript 类型定义（src/types/）
2. Mock 数据（src/api/mock/）
3. Zustand Store（src/store/）
4. 共享组件（src/components/）
5. 页面组件（src/pages/）
6. 路由配置（src/App.tsx）

**⚠️ 关键原则：**
- 严格按照原型实现（布局、颜色、间距）
- 直接复制原型的 Tailwind 类名
- 一次性实现所有功能，不要分批

#### 步骤 5：错误检测

```bash
sleep 3
tail -100 /tmp/dev-server.log | grep -iE "(error|failed)" > /tmp/errors.txt

if [ -s /tmp/errors.txt ]; then
    echo "❌ 发现错误，正在修复..."
    # 根据错误类型修复
else
    echo "✅ 编译成功"
fi
```

#### 步骤 6：打开浏览器

```bash
# 确认端口（可能不是 3000）
PORT=$(lsof -ti:3000 -sTCP:LISTEN || echo "3000")
open http://localhost:${PORT}/
```

#### 步骤 7：功能检查清单

```markdown
✅ 已完成的页面（5个）：
- ✅ 首页 (/)
- ✅ 文章列表 (/articles)
- ✅ 文章详情 (/article/:id)
- ✅ 标签页 (/tags)
- ✅ 关于页 (/about)

✅ 已完成的组件（3个）：
- ✅ Header（导航栏）
- ✅ Footer（底部信息）
- ✅ ArticleCard（文章卡片）

✅ 技术栈：
- React 18.3.1
- TypeScript 5.6.2
- Tailwind CSS 3.4.19
- React Router 6.26.1
- Zustand 5.0.2

🚀 应用已运行：http://localhost:3000/
```

---

## 四、常见问题 FAQ

### Q1：为什么要使用模板而不是 `npm create vite@latest`？

**A:**
- Vite 默认模板可能使用最新的 Tailwind v4（不稳定）
- 需要手动配置 Zustand、React Router
- 没有最佳实践的目录结构
- 没有错误预防机制

我们的模板：
- ✅ 使用稳定的 Tailwind v3
- ✅ 预配置所有常用依赖
- ✅ 包含最佳实践代码示例
- ✅ 预防了所有已知的坑

### Q2：如何更新模板？

**A:** 定期检查依赖更新，但保持 Tailwind 在 v3：
```bash
cd ${SKILL_BASE_DIR}/templates/react-base
npm outdated
npm update  # 不包括 major 版本更新
```

### Q3：模板可以自定义吗？

**A:** 可以，但建议：
- 保持基础技术栈不变（React + Tailwind v3 + Zustand）
- 添加项目特定的配置（如 API 地址）
- 不要修改 PostCSS 和 Tailwind 配置（除非你知道在做什么）

### Q4：为什么不用 Next.js 或 Remix？

**A:**
- 我们的场景是快速原型和单页应用
- Next.js 过于复杂，启动慢
- Vite + React 足够轻量和快速
- 如果需要 SSR，可以后期迁移

---

## 五、实战案例

### 案例 1：技术博客（本次实战）

**遇到的问题：**
1. ❌ 路径引用错误（`../components` → `../../components`）
2. ❌ Zustand 无限循环（selector 返回新数组）
3. ❌ Tailwind v4 PostCSS 冲突
4. ❌ node_modules 残留导致配置冲突

**解决方案：**
- ✅ 统一使用模板，避免配置问题
- ✅ 添加错误检测机制
- ✅ 使用 useMemo 缓存 selector 结果
- ✅ 清理并重装依赖

**成果：**
- 11 个页面全部实现
- 完整的 CRUD 功能
- 零运行时错误

### 案例 2：黄山旅游官网

**遇到的问题：**
1. ❌ 端口占用（8899 被旧项目占用）
2. ❌ Tab 状态刷新后丢失

**解决方案：**
- ✅ 启动前强制清理端口
- ✅ Tab 状态持久化到 URL 参数

**经验教训：**
- 多项目开发时要注意端口管理
- 原型要支持状态持久化

---

## 六、总结

### 关键要点

1. **✅ 使用模板** - 避免重复配置，预防已知问题
2. **✅ 错误检测** - 启动前必须检查错误
3. **✅ Zustand 最佳实践** - 避免无限循环
4. **✅ 路径引用规范** - 清楚目录层级关系
5. **✅ Tailwind v3** - 使用稳定版本

### 开发流程

```
原型确认 → 模板初始化 → 意图树 → 实现功能 → 错误检测 → 启动预览 → 功能清单
```

### 效率提升

- ⏱️ 项目初始化：从 5 分钟 → 30 秒
- 🐛 配置错误：从 10+ 次 → 0 次
- ✅ 代码质量：统一标准，最佳实践

---

**最后更新：** 2024-03-25（基于技术博客项目实战经验）
