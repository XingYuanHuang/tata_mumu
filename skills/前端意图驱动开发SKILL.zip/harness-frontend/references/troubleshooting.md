# 常见问题排查指南

React + Vite + Ant Design + Tailwind CSS 技术栈的常见问题及解决方案。

## Vite 相关问题

### 问题：启动时报错 "Failed to resolve entry"

**现象：**
```
Error: Failed to resolve entry for package "xxx"
```

**原因：** 依赖未正确安装或版本冲突

**解决方案：**
```bash
# 清理依赖重新安装
rm -rf node_modules package-lock.json
npm install
```

### 问题：热更新不工作

**现象：** 修改代码后页面不自动刷新

**原因：** 文件监听失效或配置问题

**解决方案：**
1. 检查 `vite.config.ts` 中的 server 配置
2. 确保文件不在 `.gitignore` 或 exclude 列表中
3. WSL 用户需要配置 usePolling

```typescript
// vite.config.ts
export default defineConfig({
  server: {
    watch: {
      usePolling: true, // WSL 用户需要
    },
  },
})
```

### 问题：路径别名不生效

**现象：** `import xxx from '@/xxx'` 报错找不到模块

**解决方案：**
1. 检查 `vite.config.ts` 配置：
```typescript
import path from 'path'

export default defineConfig({
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
    },
  },
})
```

2. 检查 `tsconfig.json` 配置：
```json
{
  "compilerOptions": {
    "baseUrl": ".",
    "paths": {
      "@/*": ["src/*"]
    }
  }
}
```

## React Hooks 相关问题

### 问题：useState 更新不生效

**现象：** 调用 setState 后值没变化

**原因：** 直接修改了 state 对象

**错误示例：**
```typescript
const [user, setUser] = useState({ name: 'John' })
user.name = 'Jane'  // ❌ 直接修改
setUser(user)       // React 认为是同一个对象，不触发更新
```

**正确做法：**
```typescript
setUser({ ...user, name: 'Jane' })  // ✅ 创建新对象
// 或
setUser(prev => ({ ...prev, name: 'Jane' }))
```

### 问题：useEffect 无限循环

**现象：** useEffect 不停地执行

**原因：** 依赖数组中的对象或数组每次都是新创建的

**错误示例：**
```typescript
const [list, setList] = useState([])

useEffect(() => {
  setList([...list, newItem])  // ❌ 会无限循环
}, [list])
```

**正确做法：**
```typescript
// 使用函数式更新
useEffect(() => {
  setList(prev => [...prev, newItem])
}, [newItem])

// 或者移除不必要的依赖
useEffect(() => {
  loadData()
}, [])  // 只在组件挂载时执行
```

### 问题：闭包陷阱

**现象：** useEffect 中获取的 state 永远是初始值

**原因：** useEffect 的闭包捕获了旧的 state 值

**错误示例：**
```typescript
const [count, setCount] = useState(0)

useEffect(() => {
  const timer = setInterval(() => {
    console.log(count)  // ❌ 永远是 0
  }, 1000)
  return () => clearInterval(timer)
}, [])  // 依赖数组为空
```

**正确做法：**
```typescript
// 方案1：添加依赖
useEffect(() => {
  const timer = setInterval(() => {
    console.log(count)  // ✅ 获取最新值
  }, 1000)
  return () => clearInterval(timer)
}, [count])  // 添加依赖

// 方案2：使用 ref
const countRef = useRef(count)
countRef.current = count

useEffect(() => {
  const timer = setInterval(() => {
    console.log(countRef.current)  // ✅ 获取最新值
  }, 1000)
  return () => clearInterval(timer)
}, [])
```

## Ant Design 相关问题

### 问题：Form 表单 setFieldsValue 不生效

**现象：** 调用 `form.setFieldsValue()` 后表单值没更新

**原因：** 在组件渲染前调用或 Form.Item 缺少 name 属性

**解决方案：**
```typescript
const [form] = Form.useForm()

// ❌ 错误：组件渲染前调用
form.setFieldsValue({ name: 'John' })

// ✅ 正确：在 useEffect 中调用
useEffect(() => {
  form.setFieldsValue({ name: 'John' })
}, [form])

// 确保 Form.Item 有 name 属性
<Form.Item name="name">  {/* 必须有 name */}
  <Input />
</Form.Item>
```

### 问题：Table 的 rowKey 警告

**现象：** Console 中出现 "Each child in a list should have a unique key prop"

**解决方案：**
```typescript
// ❌ 错误：没有指定 rowKey
<Table dataSource={data} />

// ✅ 正确：指定唯一的 rowKey
<Table dataSource={data} rowKey="id" />

// 或使用函数
<Table dataSource={data} rowKey={record => record.id} />
```

### 问题：Modal 关闭后再次打开，表单值没清空

**解决方案：**
```typescript
<Modal
  visible={visible}
  onCancel={onCancel}
  destroyOnClose  // 关闭时销毁 Modal 内容
>
  <Form form={form}>
    {/* ... */}
  </Form>
</Modal>

// 或在关闭时手动重置
const handleCancel = () => {
  form.resetFields()
  onCancel()
}
```

## Tailwind CSS 相关问题

### 问题：Tailwind 样式不生效

**原因1：** `tailwind.config.js` 的 content 配置不正确

**解决方案：**
```javascript
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",  // 确保包含所有组件文件
  ],
  // ...
}
```

**原因2：** 未导入 Tailwind CSS

**解决方案：** 在 `src/index.css` 中添加：
```css
@tailwind base;
@tailwind components;
@tailwind utilities;
```

### 问题：Tailwind 与 Ant Design 样式冲突

**现象：** Ant Design 组件样式异常

**原因：** Tailwind 的 preflight（CSS reset）覆盖了 Ant Design 的样式

**解决方案：** 禁用 preflight
```javascript
// tailwind.config.js
export default {
  corePlugins: {
    preflight: false,  // 禁用 preflight
  },
  // ...
}
```

### 问题：动态类名不生效

**错误示例：**
```typescript
// ❌ 错误：动态拼接类名
const textColor = isError ? 'red' : 'blue'
<div className={`text-${textColor}-500`} />  // 不会生效
```

**原因：** Tailwind 在构建时扫描完整的类名字符串，动态拼接的类名不会被识别

**正确做法：**
```typescript
// ✅ 方案1：完整的类名
<div className={isError ? 'text-red-500' : 'text-blue-500'} />

// ✅ 方案2：使用 classnames 库
import classNames from 'classnames'
<div className={classNames(
  'text-base',
  {
    'text-red-500': isError,
    'text-blue-500': !isError,
  }
)} />
```

## TypeScript 相关问题

### 问题：Ant Design 组件类型报错

**现象：** `Type 'xxx' is not assignable to type 'yyy'`

**解决方案：** 导入正确的类型
```typescript
import type { FormInstance } from 'antd/es/form'
import type { TableColumnsType } from 'antd/es/table'
import type { SelectProps } from 'antd/es/select'

const columns: TableColumnsType<User> = [
  // ...
]
```

### 问题：事件类型不明确

**常用事件类型：**
```typescript
import { ChangeEvent, MouseEvent, FormEvent } from 'react'

// Input 的 onChange
const handleChange = (e: ChangeEvent<HTMLInputElement>) => {
  console.log(e.target.value)
}

// Button 的 onClick
const handleClick = (e: MouseEvent<HTMLButtonElement>) => {
  console.log('clicked')
}

// Form 的 onSubmit
const handleSubmit = (e: FormEvent<HTMLFormElement>) => {
  e.preventDefault()
}
```

## 性能问题

### 问题：列表滚动卡顿

**原因：** 渲染项太多

**解决方案：** 使用虚拟滚动
```typescript
// 使用 Ant Design Table 的虚拟滚动
import { Table } from 'antd'

<Table
  dataSource={largeDataSet}
  scroll={{ y: 600 }}
  virtual  // 启用虚拟滚动
/>

// 或使用 react-window
import { FixedSizeList } from 'react-window'
```

### 问题：父组件更新导致子组件重渲染

**解决方案：** 使用 React.memo
```typescript
import { memo } from 'react'

const ExpensiveChild = memo<Props>(({ data }) => {
  // 只有当 data 变化时才重新渲染
  return <div>{/* ... */}</div>
})
```

### 问题：内联函数导致子组件重渲染

**错误示例：**
```typescript
// ❌ 每次渲染都创建新函数
<Child onClick={() => handleClick(id)} />
```

**正确做法：**
```typescript
// ✅ 使用 useCallback
const onClick = useCallback(() => handleClick(id), [id])
<Child onClick={onClick} />
```

## 构建和部署问题

### 问题：打包后白屏

**原因1：** 路由配置问题（使用了 BrowserRouter 但服务器未配置）

**解决方案：** 使用 HashRouter 或配置服务器重定向
```typescript
// 使用 HashRouter
import { HashRouter } from 'react-router-dom'

<HashRouter>
  <App />
</HashRouter>
```

**原因2：** 静态资源路径错误

**解决方案：** 配置 base
```typescript
// vite.config.ts
export default defineConfig({
  base: '/your-app/',  // 如果部署在子路径
})
```

### 问题：环境变量在生产环境不生效

**解决方案：** 使用正确的环境变量命名
```bash
# .env.production
VITE_API_URL=https://api.example.com

# 代码中使用
const apiUrl = import.meta.env.VITE_API_URL
```

注意：环境变量必须以 `VITE_` 开头才会被暴露到客户端。
