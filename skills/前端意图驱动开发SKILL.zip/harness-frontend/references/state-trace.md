# 状态追踪（State Trace）

> 让复杂状态的变更路径透明可追溯

## 核心问题

**状态复杂性的根源：**
- 不知道一个状态变更会触发哪些连锁反应
- 异步竞态 bug 难以排查
- 依赖循环导致不可预测的行为
- AI 生成的代码改动风险无法评估

**根本原因：** 状态的变更路径不透明，缺少因果追踪机制。

## 状态分层管理

首先，不是所有状态都是平等的。按置信度分为四层：

```typescript
// stores/approval-store.ts
import { create } from 'zustand'

interface ApprovalStore {
  // ============ Core 层（confidence >= 0.9）============
  // 核心业务状态，轻易不动
  core: {
    list: Approval[]           // 审批列表
    loading: boolean           // 加载状态
    error: string | null       // 错误信息
  }

  // ============ Assumed 层（confidence 0.6-0.8）============
  // 假设有用的状态，可以重构
  assumed: {
    sortOrder: 'amount_desc' | 'time_desc'  // 排序方式
    // ASSUMPTION: 用户最关心金额最大的申请
    // CONFIDENCE: 0.7

    pageSize: 20              // 分页大小
    // ASSUMPTION: 20 条适合大部分场景
    // CONFIDENCE: 0.6
  }

  // ============ Experimental 层（confidence < 0.6）============
  // 实验性状态，随时可删除
  experimental: {
    showUrgentBadge: boolean   // 是否显示紧急标记
    // ASSUMPTION: 紧急标记帮助用户优先处理
    // CONFIDENCE: 0.4
    // NOTE: 如果用户根本不看这个标记，应该删除
  }

  // ============ Pending 层（有矛盾）============
  // 存在冲突，暂不实现，等待决策
  pending: {
    batchOperation?: 'approve' | 'reject'
    // CONFLICT: 需求文档要求批量操作，设计稿里没有
    // STATUS: 等待产品经理确认
  }

  // Actions
  actions: {
    fetchList: () => Promise<void>
    approve: (id: string) => Promise<void>
    reject: (id: string, reason: string) => Promise<void>
  }
}
```

**分层的价值：**
- Core 层：修改要谨慎，影响全局
- Assumed 层：可以重构，但需要验证假设
- Experimental 层：随时可以删除
- Pending 层：不碰，等人决策

## 因果追踪系统

### 1. 状态变更的元数据记录

```typescript
// stores/traced-store.ts
import { create } from 'zustand'
import { devtools } from 'zustand/middleware'

/**
 * 状态变更元数据
 */
interface StateChange {
  timestamp: number
  actionName: string           // 哪个 action 触发的
  statePath: string           // 修改了哪个状态
  oldValue: any
  newValue: any
  triggers: string[]          // 这个变更触发了哪些后续操作
  affects: string[]           // 影响了哪些组件
  source: 'user' | 'system'   // 来源
}

/**
 * 创建带追踪的 Store
 */
export function createTracedStore<T extends object>(
  config: {
    initialState: T
    actions: Record<string, Function>
    metadata: Record<string, {
      triggers?: string[]      // 这个 action 会触发哪些连锁操作
      affects?: string[]       // 影响哪些组件
      source?: 'user' | 'system'
    }>
  }
) {
  const changeHistory: StateChange[] = []

  return create<T>()(
    devtools((set, get) => {
      const tracedActions: any = {}

      // 为每个 action 添加追踪逻辑
      for (const [actionName, actionFn] of Object.entries(config.actions)) {
        tracedActions[actionName] = async (...args: any[]) => {
          const startTime = Date.now()
          const oldState = get()

          console.log(`[StateTrace] 🎬 ${actionName} 开始执行`, {
            args,
            metadata: config.metadata[actionName]
          })

          // 执行原始 action
          await actionFn(set, get, ...args)

          const newState = get()
          const endTime = Date.now()

          // 记录状态变更
          const changes = detectChanges(oldState, newState)
          changes.forEach(change => {
            const stateChange: StateChange = {
              timestamp: startTime,
              actionName,
              statePath: change.path,
              oldValue: change.oldValue,
              newValue: change.newValue,
              triggers: config.metadata[actionName]?.triggers || [],
              affects: config.metadata[actionName]?.affects || [],
              source: config.metadata[actionName]?.source || 'user'
            }

            changeHistory.push(stateChange)

            console.log(`[StateTrace] 📝 状态变更:`, {
              action: actionName,
              path: change.path,
              duration: `${endTime - startTime}ms`,
              willTrigger: stateChange.triggers,
              willAffect: stateChange.affects
            })
          })
        }
      }

      return {
        ...config.initialState,
        ...tracedActions,

        // 调试方法
        __trace: {
          getHistory: () => changeHistory,
          printCausalChain: (actionName: string) => printCausalChain(actionName, changeHistory)
        }
      }
    })
  )
}

// 检测状态变化
function detectChanges(oldState: any, newState: any, path = ''): Array<{
  path: string
  oldValue: any
  newValue: any
}> {
  const changes: any[] = []

  for (const key in newState) {
    const newPath = path ? `${path}.${key}` : key
    if (oldState[key] !== newState[key]) {
      changes.push({
        path: newPath,
        oldValue: oldState[key],
        newValue: newState[key]
      })
    }
  }

  return changes
}

// 打印因果链
function printCausalChain(actionName: string, history: StateChange[]) {
  console.log(`\n[StateTrace] 🔗 ${actionName} 的因果链：\n`)

  const relatedChanges = history.filter(c => c.actionName === actionName)

  relatedChanges.forEach(change => {
    console.log(`  📍 ${change.statePath}`)
    console.log(`     ${change.oldValue} → ${change.newValue}`)

    if (change.triggers.length > 0) {
      console.log(`     └─ 触发: ${change.triggers.join(', ')}`)
    }

    if (change.affects.length > 0) {
      console.log(`     └─ 影响: ${change.affects.join(', ')}`)
    }
  })
}
```

### 2. 使用追踪 Store

```typescript
// stores/approval-store.ts
import { createTracedStore } from './traced-store'
import { approvalService } from '@/api/approval-service'

export const useApprovalStore = createTracedStore({
  initialState: {
    list: [],
    loading: false,
    error: null,
    selectedId: null
  },

  actions: {
    // 获取列表
    fetchList: (set, get) => {
      // INTENT: 从服务端拉取最新审批列表
      set({ loading: true })

      return approvalService.getApprovals()
        .then(list => {
          set({ list, loading: false, error: null })
        })
        .catch(error => {
          set({ error: error.message, loading: false })
        })
    },

    // 审批通过
    approve: (set, get, id: string) => {
      // INTENT: 提交单条审批决策
      // WHY: 审批成功后需要刷新列表，而不只是乐观更新
      // ASSUMPTION: 审批成功后服务端数据立即更新

      set({ loading: true })

      return approvalService.approveApproval(id)
        .then(() => {
          // 刷新列表而非乐观更新
          // WHY: 避免与其他审批者并发操作造成的状态不一致
          return get().fetchList()
        })
        .then(() => {
          set({ selectedId: null })
        })
        .catch(error => {
          set({ error: error.message, loading: false })
        })
    }
  },

  // 元数据：描述每个 action 的影响范围
  metadata: {
    fetchList: {
      source: 'system',
      triggers: [],                     // 不触发其他操作
      affects: ['ApprovalList', 'ApprovalCounter']  // 影响这些组件
    },

    approve: {
      source: 'user',
      triggers: ['fetchList'],          // 会触发 fetchList
      affects: ['ApprovalList', 'ApprovalModal', 'ApprovalCounter']
    },

    reject: {
      source: 'user',
      triggers: ['fetchList'],
      affects: ['ApprovalList', 'ApprovalModal', 'ApprovalCounter']
    }
  }
})
```

### 3. 调试状态变更

```typescript
// 在组件中调试
import { useApprovalStore } from '@/stores/approval-store'

function DebugPanel() {
  const store = useApprovalStore()

  const handlePrintTrace = () => {
    // 打印 approve 的因果链
    store.__trace.printCausalChain('approve')
  }

  return (
    <button onClick={handlePrintTrace}>
      查看 approve 的因果链
    </button>
  )
}

// 控制台输出：
// [StateTrace] 🔗 approve 的因果链：
//
//   📍 loading
//      false → true
//      └─ 影响: ApprovalList, ApprovalModal, ApprovalCounter
//
//   📍 list
//      [旧列表] → [新列表]
//      └─ 触发: fetchList
//      └─ 影响: ApprovalList, ApprovalCounter
//
//   📍 selectedId
//      "123" → null
//      └─ 影响: ApprovalModal
```

## 异步竞态的结构化处理

### 1. 竞态条件的显式管理

```typescript
// hooks/useSafeAsync.ts
import { useEffect, useRef, useState } from 'react'

/**
 * 安全的异步 Hook，自动处理竞态条件
 */
export function useSafeAsync<T>(
  asyncFn: () => Promise<T>,
  deps: any[]
) {
  const [data, setData] = useState<T | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<Error | null>(null)

  // 取消标记
  const cancelledRef = useRef(false)

  useEffect(() => {
    cancelledRef.current = false
    setLoading(true)

    // RACE_CONDITION: 当 deps 快速变化时，
    //                 旧请求可能晚于新请求返回
    // SOLUTION: 使用 cancelled 标记取消过期的结果

    asyncFn()
      .then(result => {
        if (!cancelledRef.current) {
          setData(result)
          setError(null)
        } else {
          console.log('[useSafeAsync] ❌ 结果被取消（过期）')
        }
      })
      .catch(err => {
        if (!cancelledRef.current) {
          setError(err)
        }
      })
      .finally(() => {
        if (!cancelledRef.current) {
          setLoading(false)
        }
      })

    // CLEANUP: 组件卸载或 deps 再次变化时，取消旧请求
    return () => {
      cancelledRef.current = true
    }
  }, deps)

  return { data, loading, error }
}
```

### 2. 在组件中使用

```typescript
// components/ApprovalList.tsx
import { useSafeAsync } from '@/hooks/useSafeAsync'
import { approvalService } from '@/api/approval-service'

export const ApprovalList = () => {
  const [filters, setFilters] = useState({ status: 'pending' })

  // 自动处理竞态，不需要手动管理取消逻辑
  const { data: approvals, loading, error } = useSafeAsync(
    () => approvalService.getApprovals(filters),
    [filters]  // filters 变化时自动取消旧请求
  )

  return (
    <div>
      <FilterBar filters={filters} onChange={setFilters} />

      {loading && <Spinner />}
      {error && <ErrorMessage error={error} />}

      {approvals?.map(approval => (
        <ApprovalCard key={approval.id} {...approval} />
      ))}
    </div>
  )
}
```

### 3. 复杂异步流程的编排

```typescript
// stores/approval-store.ts
import pRetry from 'p-retry'
import pTimeout from 'p-timeout'

export const useApprovalStore = create((set, get) => ({
  approve: async (id: string) => {
    // INTENT: 提交审批决策，确保成功
    // RACE_CONDITION: 用户可能快速点击多次
    // SOLUTION: 用 loading 状态防止重复提交

    if (get().loading) {
      console.log('[approve] ⚠️ 正在处理中，忽略重复点击')
      return
    }

    set({ loading: true })

    try {
      // 带重试的请求（网络不稳定时）
      await pRetry(
        () => pTimeout(
          approvalService.approveApproval(id),
          { milliseconds: 5000 }  // 5秒超时
        ),
        {
          retries: 3,
          onFailedAttempt: error => {
            console.log(`[approve] 重试 ${error.attemptNumber}/${error.retriesLeft + error.attemptNumber}`)
          }
        }
      )

      // 成功后刷新列表
      await get().fetchList()

      set({ selectedId: null })

    } catch (error) {
      // 失败后给用户明确的提示
      console.error('[approve] ❌ 提交失败', error)
      set({ error: '审批提交失败，请检查网络后重试' })

    } finally {
      set({ loading: false })
    }
  }
}))
```

## 依赖关系可视化

### 1. 状态依赖图

```typescript
// scripts/visualize-state-deps.ts
import { INTENT_MAP } from '@/api/intent-map'

/**
 * 生成状态依赖关系图（Mermaid 格式）
 */
export function generateStateDependencyGraph() {
  const graph = `
graph TD
  approve[approve action]
  reject[reject action]
  fetchList[fetchList action]

  approve -->|triggers| fetchList
  reject -->|triggers| fetchList

  fetchList -->|affects| ApprovalList
  fetchList -->|affects| ApprovalCounter

  approve -->|affects| ApprovalModal
  reject -->|affects| ApprovalModal

  style approve fill:#f9f,stroke:#333,stroke-width:2px
  style reject fill:#f9f,stroke:#333,stroke-width:2px
  style fetchList fill:#bbf,stroke:#333,stroke-width:2px
  style ApprovalList fill:#bfb,stroke:#333,stroke-width:2px
  style ApprovalCounter fill:#bfb,stroke:#333,stroke-width:2px
  style ApprovalModal fill:#bfb,stroke:#333,stroke-width:2px
  `

  return graph
}
```

渲染结果：
```
approve → fetchList → ApprovalList
                   → ApprovalCounter
        → ApprovalModal

reject → fetchList → ApprovalList
                  → ApprovalCounter
       → ApprovalModal
```

### 2. 在 README 中展示

```markdown
## 状态依赖关系

\`\`\`mermaid
graph TD
  approve[approve action]
  fetchList[fetchList action]
  approve -->|triggers| fetchList
  fetchList -->|affects| ApprovalList
  fetchList -->|affects| ApprovalCounter
\`\`\`
```

## 排查 Bug 的完整流程

### 问题：审批后列表没有更新

**第一步：查看状态追踪日志**

```typescript
// 在浏览器控制台
store.__trace.printCausalChain('approve')

// 输出：
// [StateTrace] 🔗 approve 的因果链：
//   📍 loading: false → true
//      └─ 触发: fetchList
//      └─ 影响: ApprovalList
//
//   ❌ fetchList 没有被执行！
```

**第二步：检查 action 代码**

```typescript
// 发现问题：approve 里没有调用 fetchList
approve: async (set, get, id: string) => {
  await approvalService.approveApproval(id)
  // 缺少这一行：
  // await get().fetchList()
}
```

**第三步：修复并验证**

```typescript
approve: async (set, get, id: string) => {
  await approvalService.approveApproval(id)
  await get().fetchList()  // ✅ 添加刷新逻辑
}
```

**第四步：更新元数据**

```typescript
metadata: {
  approve: {
    triggers: ['fetchList'],  // 明确记录依赖关系
    affects: ['ApprovalList', 'ApprovalModal']
  }
}
```

## 最佳实践

### 1. 命名规范

```typescript
// ✅ 好的命名：动词开头，清晰表意
fetchList()
approveApproval()
updateFilters()

// ❌ 不好的命名：含糊不清
handleClick()
doSomething()
update()
```

### 2. Action 职责单一

```typescript
// ❌ 不好：一个 action 做太多事
approve: async (set, get, id: string) => {
  await api.approve(id)
  await get().fetchList()
  set({ selectedId: null })
  await api.sendNotification()
  await api.updateStatistics()
}

// ✅ 好：拆分为多个 action
approve: async (set, get, id: string) => {
  await api.approve(id)
  await get().fetchList()
  set({ selectedId: null })
}

sendNotification: async (id: string) => {
  await api.sendNotification(id)
}
```

### 3. 异步错误处理

```typescript
// ✅ 好：明确的错误处理和用户提示
approve: async (set, get, id: string) => {
  try {
    await api.approve(id)
    await get().fetchList()
    message.success('审批成功')
  } catch (error) {
    console.error('[approve] 失败', error)
    message.error('审批提交失败，请重试')
    throw error  // 重新抛出，让调用方知道失败了
  }
}
```

## 总结

状态追踪的核心价值：

1. **透明性** - 清楚知道每个状态变更的来源和影响
2. **可调试性** - Bug 发生时能快速定位根因
3. **可维护性** - 修改代码时知道影响范围
4. **安全性** - 竞态条件被显式管理，不靠运气

**记住：状态复杂不可怕，可怕的是不知道状态是怎么变的。**
