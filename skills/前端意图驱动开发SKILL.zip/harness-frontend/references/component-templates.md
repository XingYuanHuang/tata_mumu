# React 组件模板

本文档提供常见 React 组件的代码模板，基于 React + TypeScript + Ant Design + Tailwind CSS 技术栈。

## 基础组件模板

### 简单展示组件

```typescript
// Card/types.ts
export interface CardProps {
  title: string;
  description?: string;
  imageUrl?: string;
  actions?: React.ReactNode;
  className?: string;
}

// Card/index.tsx
import { FC } from 'react';
import { Card as AntCard } from 'antd';
import { CardProps } from './types';

const Card: FC<CardProps> = ({
  title,
  description,
  imageUrl,
  actions,
  className = '',
}) => {
  return (
    <AntCard
      hoverable
      cover={imageUrl && <img alt={title} src={imageUrl} className="h-48 object-cover" />}
      actions={actions ? [actions] : undefined}
      className={className}
    >
      <div className="space-y-2">
        <h3 className="text-lg font-semibold text-gray-900">{title}</h3>
        {description && (
          <p className="text-sm text-gray-600 line-clamp-3">{description}</p>
        )}
      </div>
    </AntCard>
  );
};

export default Card;
```

### 表单组件

```typescript
// LoginForm/types.ts
export interface LoginFormProps {
  onSubmit: (values: LoginFormValues) => void | Promise<void>;
  loading?: boolean;
}

export interface LoginFormValues {
  username: string;
  password: string;
  remember?: boolean;
}

// LoginForm/index.tsx
import { FC } from 'react';
import { Form, Input, Button, Checkbox } from 'antd';
import { UserOutlined, LockOutlined } from '@ant-design/icons';
import { LoginFormProps, LoginFormValues } from './types';

const LoginForm: FC<LoginFormProps> = ({ onSubmit, loading = false }) => {
  const [form] = Form.useForm<LoginFormValues>();

  const handleFinish = async (values: LoginFormValues) => {
    await onSubmit(values);
  };

  return (
    <div className="w-full max-w-md mx-auto p-8 bg-white rounded-lg shadow-lg">
      <h2 className="text-2xl font-bold text-center mb-6 text-gray-800">
        用户登录
      </h2>

      <Form
        form={form}
        name="login"
        onFinish={handleFinish}
        autoComplete="off"
        size="large"
      >
        <Form.Item
          name="username"
          rules={[
            { required: true, message: '请输入用户名' },
            { min: 3, message: '用户名至少3个字符' },
          ]}
        >
          <Input
            prefix={<UserOutlined className="text-gray-400" />}
            placeholder="用户名"
          />
        </Form.Item>

        <Form.Item
          name="password"
          rules={[
            { required: true, message: '请输入密码' },
            { min: 6, message: '密码至少6个字符' },
          ]}
        >
          <Input.Password
            prefix={<LockOutlined className="text-gray-400" />}
            placeholder="密码"
          />
        </Form.Item>

        <Form.Item name="remember" valuePropName="checked">
          <Checkbox>记住我</Checkbox>
        </Form.Item>

        <Form.Item>
          <Button
            type="primary"
            htmlType="submit"
            loading={loading}
            className="w-full"
          >
            登录
          </Button>
        </Form.Item>
      </Form>
    </div>
  );
};

export default LoginForm;
```

### 列表组件

```typescript
// UserList/types.ts
export interface User {
  id: number;
  name: string;
  email: string;
  role: string;
  status: 'active' | 'inactive';
  avatar?: string;
}

export interface UserListProps {
  users: User[];
  loading?: boolean;
  onEdit?: (user: User) => void;
  onDelete?: (userId: number) => void;
}

// UserList/index.tsx
import { FC } from 'react';
import { Table, Button, Tag, Space, Avatar } from 'antd';
import { EditOutlined, DeleteOutlined, UserOutlined } from '@ant-design/icons';
import type { ColumnsType } from 'antd/es/table';
import { UserListProps, User } from './types';

const UserList: FC<UserListProps> = ({
  users,
  loading = false,
  onEdit,
  onDelete,
}) => {
  const columns: ColumnsType<User> = [
    {
      title: '用户',
      dataIndex: 'name',
      key: 'name',
      render: (name: string, record: User) => (
        <div className="flex items-center gap-3">
          <Avatar
            src={record.avatar}
            icon={<UserOutlined />}
            className="flex-shrink-0"
          />
          <div>
            <div className="font-medium text-gray-900">{name}</div>
            <div className="text-sm text-gray-500">{record.email}</div>
          </div>
        </div>
      ),
    },
    {
      title: '角色',
      dataIndex: 'role',
      key: 'role',
      width: 120,
    },
    {
      title: '状态',
      dataIndex: 'status',
      key: 'status',
      width: 100,
      render: (status: User['status']) => (
        <Tag color={status === 'active' ? 'success' : 'default'}>
          {status === 'active' ? '启用' : '禁用'}
        </Tag>
      ),
    },
    {
      title: '操作',
      key: 'action',
      width: 150,
      render: (_, record: User) => (
        <Space size="small">
          {onEdit && (
            <Button
              type="link"
              icon={<EditOutlined />}
              onClick={() => onEdit(record)}
            >
              编辑
            </Button>
          )}
          {onDelete && (
            <Button
              type="link"
              danger
              icon={<DeleteOutlined />}
              onClick={() => onDelete(record.id)}
            >
              删除
            </Button>
          )}
        </Space>
      ),
    },
  ];

  return (
    <div className="bg-white rounded-lg shadow">
      <Table
        columns={columns}
        dataSource={users}
        rowKey="id"
        loading={loading}
        pagination={{
          showSizeChanger: true,
          showTotal: (total) => `共 ${total} 条记录`,
        }}
      />
    </div>
  );
};

export default UserList;
```

## 高级组件模板

### 弹窗表单组件

```typescript
// UserModal/types.ts
export interface UserModalProps {
  visible: boolean;
  user?: User | null;
  onSubmit: (values: UserFormValues) => void | Promise<void>;
  onCancel: () => void;
  loading?: boolean;
}

export interface UserFormValues {
  name: string;
  email: string;
  role: string;
}

// UserModal/index.tsx
import { FC, useEffect } from 'react';
import { Modal, Form, Input, Select } from 'antd';
import { UserModalProps, UserFormValues } from './types';

const UserModal: FC<UserModalProps> = ({
  visible,
  user,
  onSubmit,
  onCancel,
  loading = false,
}) => {
  const [form] = Form.useForm<UserFormValues>();

  useEffect(() => {
    if (visible && user) {
      form.setFieldsValue(user);
    } else if (!visible) {
      form.resetFields();
    }
  }, [visible, user, form]);

  const handleOk = async () => {
    try {
      const values = await form.validateFields();
      await onSubmit(values);
      form.resetFields();
    } catch (error) {
      console.error('表单验证失败:', error);
    }
  };

  return (
    <Modal
      title={user ? '编辑用户' : '新建用户'}
      open={visible}
      onOk={handleOk}
      onCancel={onCancel}
      confirmLoading={loading}
      destroyOnClose
    >
      <Form
        form={form}
        layout="vertical"
        className="mt-4"
      >
        <Form.Item
          name="name"
          label="姓名"
          rules={[{ required: true, message: '请输入姓名' }]}
        >
          <Input placeholder="请输入姓名" />
        </Form.Item>

        <Form.Item
          name="email"
          label="邮箱"
          rules={[
            { required: true, message: '请输入邮箱' },
            { type: 'email', message: '邮箱格式不正确' },
          ]}
        >
          <Input placeholder="请输入邮箱" />
        </Form.Item>

        <Form.Item
          name="role"
          label="角色"
          rules={[{ required: true, message: '请选择角色' }]}
        >
          <Select placeholder="请选择角色">
            <Select.Option value="admin">管理员</Select.Option>
            <Select.Option value="user">普通用户</Select.Option>
            <Select.Option value="guest">访客</Select.Option>
          </Select>
        </Form.Item>
      </Form>
    </Modal>
  );
};

export default UserModal;
```

### 搜索过滤组件

```typescript
// SearchFilter/types.ts
export interface SearchFilterProps {
  onSearch: (values: SearchValues) => void;
  onReset: () => void;
  loading?: boolean;
}

export interface SearchValues {
  keyword?: string;
  status?: string;
  dateRange?: [string, string];
}

// SearchFilter/index.tsx
import { FC } from 'react';
import { Form, Input, Select, DatePicker, Button, Space } from 'antd';
import { SearchOutlined, ReloadOutlined } from '@ant-design/icons';
import { SearchFilterProps, SearchValues } from './types';

const { RangePicker } = DatePicker;

const SearchFilter: FC<SearchFilterProps> = ({
  onSearch,
  onReset,
  loading = false,
}) => {
  const [form] = Form.useForm<SearchValues>();

  const handleSearch = () => {
    const values = form.getFieldsValue();
    onSearch(values);
  };

  const handleReset = () => {
    form.resetFields();
    onReset();
  };

  return (
    <div className="bg-white p-4 rounded-lg shadow mb-4">
      <Form
        form={form}
        layout="inline"
        className="flex flex-wrap gap-4"
      >
        <Form.Item name="keyword" className="mb-0">
          <Input
            placeholder="搜索关键词"
            allowClear
            style={{ width: 200 }}
          />
        </Form.Item>

        <Form.Item name="status" className="mb-0">
          <Select
            placeholder="状态"
            allowClear
            style={{ width: 150 }}
          >
            <Select.Option value="active">启用</Select.Option>
            <Select.Option value="inactive">禁用</Select.Option>
          </Select>
        </Form.Item>

        <Form.Item name="dateRange" className="mb-0">
          <RangePicker style={{ width: 240 }} />
        </Form.Item>

        <Form.Item className="mb-0">
          <Space>
            <Button
              type="primary"
              icon={<SearchOutlined />}
              onClick={handleSearch}
              loading={loading}
            >
              搜索
            </Button>
            <Button icon={<ReloadOutlined />} onClick={handleReset}>
              重置
            </Button>
          </Space>
        </Form.Item>
      </Form>
    </div>
  );
};

export default SearchFilter;
```

## 布局组件模板

### 页面容器

```typescript
// PageContainer/types.ts
export interface PageContainerProps {
  title: string;
  description?: string;
  extra?: React.ReactNode;
  children: React.ReactNode;
}

// PageContainer/index.tsx
import { FC } from 'react';
import { PageContainerProps } from './types';

const PageContainer: FC<PageContainerProps> = ({
  title,
  description,
  extra,
  children,
}) => {
  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-6 flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">{title}</h1>
            {description && (
              <p className="mt-1 text-sm text-gray-600">{description}</p>
            )}
          </div>
          {extra && <div>{extra}</div>}
        </div>
        {children}
      </div>
    </div>
  );
};

export default PageContainer;
```

## 自定义 Hooks 模板

### useTable Hook

```typescript
// hooks/useTable.ts
import { useState, useCallback } from 'react';

interface UseTableOptions<T> {
  fetchData: (params: TableParams) => Promise<{ data: T[]; total: number }>;
  pageSize?: number;
}

interface TableParams {
  page: number;
  pageSize: number;
  [key: string]: any;
}

export function useTable<T>({ fetchData, pageSize = 10 }: UseTableOptions<T>) {
  const [data, setData] = useState<T[]>([]);
  const [loading, setLoading] = useState(false);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);

  const loadData = useCallback(
    async (params: Partial<TableParams> = {}) => {
      setLoading(true);
      try {
        const result = await fetchData({
          page,
          pageSize,
          ...params,
        });
        setData(result.data);
        setTotal(result.total);
      } catch (error) {
        console.error('加载数据失败:', error);
      } finally {
        setLoading(false);
      }
    },
    [fetchData, page, pageSize]
  );

  const handlePageChange = (newPage: number, newPageSize: number) => {
    setPage(newPage);
    loadData({ page: newPage, pageSize: newPageSize });
  };

  return {
    data,
    loading,
    total,
    page,
    pageSize,
    loadData,
    handlePageChange,
  };
}
```

### useModal Hook

```typescript
// hooks/useModal.ts
import { useState, useCallback } from 'react';

export function useModal<T = any>() {
  const [visible, setVisible] = useState(false);
  const [data, setData] = useState<T | null>(null);

  const open = useCallback((initialData?: T) => {
    setVisible(true);
    if (initialData) {
      setData(initialData);
    }
  }, []);

  const close = useCallback(() => {
    setVisible(false);
    setData(null);
  }, []);

  return {
    visible,
    data,
    open,
    close,
  };
}
```
