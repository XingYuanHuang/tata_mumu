# 前端项目标准目录结构

> **核心原则：原型和源码在同一个项目目录下，便于对比和管理**

## 问题背景

### ❌ 旧的做法（不合理）

之前会创建两个分离的目录：

```bash
当前目录/
├── project-name/              # 原型目录
│   └── prototype.html
└── project-name-react/        # React 源码目录
    ├── src/
    ├── package.json
    └── ...
```

**问题：**
- 目录混乱，不便于管理
- 原型和源码分离，对比困难
- 删除或移动项目时容易遗漏
- 部署时需要分别处理

---

## ✅ 新的标准结构

### 完整项目结构

```bash
project-name/                   # 项目根目录（在当前工作目录下创建）
│
├── prototype/                  # 🎨 原型目录（HTML 原型）
│   └── index.html             # 多 Tab 原型文件
│
├── docs/                       # 📚 项目文档（可选）
│   ├── intent-tree.md         # 意图树
│   ├── requirements.md        # 需求文档
│   └── design-notes.md        # 设计笔记
│
├── src/                        # 💻 React 源码
│   ├── pages/                 # 页面组件
│   ├── components/            # 共享组件
│   ├── types/                 # TypeScript 类型定义
│   ├── store/                 # Zustand 状态管理
│   ├── api/                   # API 和 Mock 数据
│   ├── App.tsx                # 根组件
│   ├── main.tsx               # 入口文件
│   └── index.css              # 全局样式
│
├── public/                     # 🌐 静态资源
│   └── favicon.ico
│
├── package.json               # 📦 依赖配置
├── package-lock.json
├── tsconfig.json              # TypeScript 配置
├── vite.config.ts             # Vite 配置
├── tailwind.config.js         # Tailwind CSS 配置
├── postcss.config.js          # PostCSS 配置
├── .gitignore
└── README.md                  # 项目说明
```

---

## 📁 目录说明

### 1. `prototype/` - 原型目录

**用途：** 存放 HTML 静态原型

**内容：**
- `index.html` - 使用原型模板生成的多 Tab 原型
- 包含所有设计风格的可交互展示
- 用户在这里确认设计和交互

**特点：**
- 📁 独立目录，不与源码混淆
- 🚀 可以直接用 `python3 -m http.server` 启动预览
- 📝 保留原型便于日后对比和回顾

**示例：**
```html
<!-- prototype/index.html -->
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <title>原型展示 - 项目名称</title>
    ...
</head>
<body>
    <!-- Tab 1: 设计风格 A -->
    <!-- Tab 2: 设计风格 B -->
    <!-- Tab 3: 设计风格 C -->
</body>
</html>
```

---

### 2. `docs/` - 项目文档（可选）

**用途：** 存放项目相关文档

**内容：**
- `intent-tree.md` - 意图树（页面清单、组件清单、实现计划）
- `requirements.md` - 需求文档（如果用户提供）
- `design-notes.md` - 设计笔记和迭代记录
- `api-spec.md` - API 接口文档（如果有后端）

**何时创建：**
- 简单项目（1-3 页）：可以不创建
- 复杂项目（5+ 页）：强烈建议创建

---

### 3. `src/` - React 源码

**用途：** 完整的 React 应用源代码

**结构：** 遵循 React 最佳实践

**详细说明：** 见 `react-best-practices.md`

---

### 4. `public/` - 静态资源

**用途：** 存放不需要编译的静态文件

**内容：**
- `favicon.ico` - 网站图标
- 图片、字体等资源（不推荐放这里，建议放 CDN）

---

## 🚀 项目创建流程

### 步骤 1：创建项目根目录

```bash
# 在当前工作目录下创建项目根目录
mkdir -p <项目名>
cd <项目名>
```

### 步骤 2：生成原型

```bash
# 创建原型目录
mkdir -p prototype

# 生成原型（使用原型模板）
# 将生成的 HTML 保存为 prototype/index.html
```

### 步骤 3：启动原型预览

```bash
# 在原型目录启动服务器
cd prototype
python3 -m http.server 8899 > /dev/null 2>&1 &
open http://localhost:8899/index.html

# 回到项目根目录
cd ..
```

### 步骤 4：用户确认原型后，创建 React 项目

```bash
# 在项目根目录下复制 React 模板
# SKILL_BASE_DIR 是 skill 的基础目录，运行时由系统提供
cp -r ${SKILL_BASE_DIR}/templates/react-base/* .
cp -r ${SKILL_BASE_DIR}/templates/react-base/.gitignore .

# 安装依赖
npm install

# 启动开发服务器
npm run dev > /tmp/dev-server.log 2>&1 &
```

### 步骤 5：实现 React 应用

按照 `react-best-practices.md` 的流程实现所有功能。

---

## 📋 实际操作示例

### 示例：坦克大战项目

**旧的结构（❌ 不推荐）：**
```bash
当前目录/
├── tank-battle/          # 原型
└── tank-battle-react/    # React 源码
```

**新的结构（✅ 推荐）：**
```bash
tank-battle/                   # 在当前目录下
├── prototype/
│   └── index.html        # 包含 3 种风格的原型
├── docs/
│   └── intent-tree.md    # 意图树
├── src/
│   ├── components/
│   │   ├── GameCanvas.tsx
│   │   ├── Scoreboard.tsx
│   │   ├── ControlPanel.tsx
│   │   └── Instructions.tsx
│   ├── types/
│   │   └── index.ts
│   ├── App.tsx
│   └── main.tsx
├── package.json
├── vite.config.ts
└── README.md
```

**创建命令：**
```bash
# 1. 创建项目根目录（在当前目录）
mkdir -p tank-battle
cd tank-battle

# 2. 创建原型目录
mkdir -p prototype
# 生成 prototype/index.html

# 3. 在根目录初始化 React 项目
cp -r ${SKILL_BASE_DIR}/templates/react-base/* .
cp -r ${SKILL_BASE_DIR}/templates/react-base/.gitignore .

# 4. 安装依赖
npm install

# 现在目录结构为：
# tank-battle/
# ├── prototype/
# ├── src/
# ├── public/
# └── package.json
```

---

## 🎯 目录结构优势

### ✅ 集中管理
- 原型和源码在同一个项目下
- 方便版本控制（一个 Git 仓库）
- 方便部署和分享

### ✅ 便于对比
- 原型在 `prototype/`，源码在 `src/`
- 实现时可以随时打开原型对照
- 验收时可以对比原型和实现

### ✅ 清晰的职责分离
- `prototype/` - 设计和交互确认
- `src/` - 工程实现
- `docs/` - 文档记录

### ✅ 部署友好
- 原型可以部署到 `/prototype` 路径
- React 应用部署到根路径
- 一个域名可以同时访问原型和应用

---

## 🔧 特殊场景处理

### 场景 1：只需要原型，不需要 React 实现

```bash
project-name/
├── prototype/
│   └── index.html
└── README.md        # 说明这是纯原型项目
```

### 场景 2：多个原型迭代

```bash
project-name/
├── prototype/
│   ├── v1.html      # 第一版原型
│   ├── v2.html      # 第二版原型
│   └── index.html   # 最终确认版本（符号链接或复制）
├── src/
└── ...
```

### 场景 3：多个独立页面（非 SPA）

```bash
project-name/
├── prototype/
│   ├── home.html
│   ├── about.html
│   └── contact.html
├── src/
│   ├── home/        # 独立的 React 应用 1
│   ├── about/       # 独立的 React 应用 2
│   └── contact/     # 独立的 React 应用 3
└── ...
```

---

## 📝 注意事项

### 1. `.gitignore` 配置

确保 `.gitignore` 包含：

```gitignore
# 依赖
node_modules/
package-lock.json

# 构建产物
dist/
build/

# 日志
*.log

# 编辑器
.vscode/
.idea/

# 临时文件
.DS_Store
```

### 2. README.md 说明

项目根目录的 `README.md` 应该包含：

```markdown
# 项目名称

## 项目结构

- `prototype/` - HTML 原型文件
- `src/` - React 源码
- `docs/` - 项目文档

## 快速开始

### 预览原型
\`\`\`bash
cd prototype
python3 -m http.server 8899
open http://localhost:8899/
\`\`\`

### 运行 React 应用
\`\`\`bash
npm install
npm run dev
\`\`\`

## 技术栈

- React 18 + TypeScript
- Tailwind CSS v3
- Vite
- ...
```

### 3. 端口分配

- 原型预览：`8899`（或其他端口）
- React 开发服务器：`3000`（Vite 默认）

避免端口冲突。

---

## 🎓 总结

**核心原则：**
1. ✅ 原型和源码在同一个项目目录下
2. ✅ 使用 `prototype/` 目录存放原型
3. ✅ 使用 `src/` 目录存放 React 源码
4. ✅ 可选的 `docs/` 目录存放文档
5. ✅ 项目创建在当前工作目录下，不写死路径

**创建顺序：**
1. 在当前目录创建项目根目录
2. 生成原型到 `prototype/`
3. 用户确认后，在根目录初始化 React 项目
4. 实现功能

**优势：**
- 📁 目录清晰，职责分明
- 🔄 便于原型和实现的对比
- 🚀 便于版本控制和部署
- 📝 便于长期维护和回顾

---

**最后更新：** 2024-03-26
