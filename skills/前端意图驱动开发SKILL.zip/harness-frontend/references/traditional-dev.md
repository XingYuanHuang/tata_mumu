# 传统开发模式（Traditional Development Mode）

基于 **React + Vite + Ant Design + Tailwind CSS** 技术栈的前端研发全流程辅助工具，帮助开发者高效完成项目初始化、组件开发、代码审查和问题诊断。

## 技术栈

本 skill 专注于以下固定技术栈：

- **框架**: React 18+ (使用函数组件和 Hooks)
- **构建工具**: Vite 5+
- **UI 库**: Ant Design 5+
- **样式方案**: Tailwind CSS 3+ (与 Ant Design 混合使用)
- **语言**: TypeScript
- **状态管理**: React Hooks (useState, useReducer, useContext) 或 Zustand
- **路由**: React Router 6+
- **HTTP 请求**: Axios 或 fetch
- **代码规范**: ESLint + Prettier

## 核心能力

1. **项目初始化** - 快速搭建 React + Vite 项目脚手架
2. **组件开发** - 智能生成 React 组件代码（结合 Ant Design 和 Tailwind CSS）
3. **代码审查** - 分析代码质量并提供优化建议
4. **问题诊断** - 定位和解决前端 bug、样式问题和性能瓶颈

## 使用场景

### 1. 项目初始化

当用户需要创建新的 React 项目时，使用 Vite 快速搭建项目脚手架。

**初始化步骤：**

1. 创建 Vite + React + TypeScript 项目
2. 安装和配置 Ant Design
3. 集成 Tailwind CSS（配置与 Ant Design 兼容）
4. **使用模板文件创建配置** - 从 `templates/` 目录复制配置文件模板
5. 配置 ESLint + Prettier
6. 设置项目目录结构
7. 配置路由和基础布局
8. 添加开发环境配置

**⚠️ 重要：使用初始化脚本或模板文件，避免样式问题**

#### 方法 1：使用自动化初始化脚本（推荐）

```bash
# 在 frontend-skill 目录下执行
bash templates/init-project.sh my-project-name
cd my-project-name
npm run dev
```

脚本会自动完成：
- ✅ 创建 Vite + React + TypeScript 项目
- ✅ 安装所有必需依赖（Ant Design、Tailwind CSS、React Router 等）
- ✅ 复制所有配置文件模板
- ✅ 创建标准目录结构
- ✅ 配置正确的样式导入和路径别名

#### 方法 2：手动复制模板文件

如果需要手动创建，必须从 `templates/` 目录复制以下文件（去掉 `.template` 后缀）：

- ✅ `postcss.config.js.template` → `postcss.config.js` （Tailwind CSS 必需）
- ✅ `tailwind.config.js.template` → `tailwind.config.js` （禁用 preflight 避免冲突）
- ✅ `vite.config.ts.template` → `vite.config.ts` （路径别名 @ 配置）
- ✅ `tsconfig.json.template` → `tsconfig.json` （TypeScript 路径映射）
- ✅ `main.tsx.template` → `src/main.tsx` （正确导入 Ant Design 样式）
- ✅ `App.tsx.template` → `src/App.tsx` （正确的 locale 导入路径）
- ✅ `index.css.template` → `src/index.css` （Tailwind 指令）
- ✅ `.env.development.template` → `.env.development` （环境变量）
- ✅ `package.json.example` → `package.json` （所有依赖）

这些模板文件已经解决了常见的样式问题：
- ✅ Ant Design 样式导入顺序正确（`antd/dist/reset.css` 在 `index.css` 之前）
- ✅ Ant Design locale 使用正确路径（`antd/es/locale/zh_CN`）
- ✅ PostCSS 配置正确（支持 Tailwind CSS）
- ✅ Tailwind 禁用 preflight（避免与 Ant Design 冲突）
- ✅ 路径别名在 Vite 和 TypeScript 中都配置好（`@/` → `src/`）

**关键配置说明：**

1. **样式导入顺序** (`src/main.tsx`)：
   ```typescript
   import 'antd/dist/reset.css'  // ← 必须在 index.css 之前
   import './index.css'
   ```

2. **Locale 导入路径** (`src/App.tsx`)：
   ```typescript
   import zhCN from 'antd/es/locale/zh_CN'  // ← 使用 es 路径
   ```

3. **Tailwind preflight** (`tailwind.config.js`)：
   ```javascript
   corePlugins: {
     preflight: false,  // ← 禁用以避免冲突
   }
   ```

**标准项目结构：**

```
project-name/
├── src/
│   ├── assets/          # 静态资源
│   ├── components/      # 公共组件
│   │   ├── Button/
│   │   ├── Card/
│   │   └── ...
│   ├── pages/           # 页面组件
│   │   ├── Home/
│   │   ├── Dashboard/
│   │   └── ...
│   ├── hooks/           # 自定义 Hooks
│   ├── services/        # API 服务
│   ├── stores/          # 状态管理（如使用 Zustand）
│   ├── types/           # TypeScript 类型定义
│   ├── utils/           # 工具函数
│   ├── router/          # 路由配置
│   ├── App.tsx
│   └── main.tsx
├── public/
├── .eslintrc.cjs
├── .prettierrc
├── tailwind.config.js
├── tsconfig.json
├── vite.config.ts
└── package.json
```

**依赖安装命令：**

```bash
# 核心依赖
npm install react react-dom
npm install antd
npm install react-router-dom
npm install axios

# Tailwind CSS
npm install -D tailwindcss postcss autoprefixer
npx tailwindcss init -p

# 开发依赖
npm install -D @types/react @types/react-dom
npm install -D eslint @typescript-eslint/parser @typescript-eslint/eslint-plugin
npm install -D prettier eslint-config-prettier eslint-plugin-prettier
npm install -D vite @vitejs/plugin-react
```

### 2. 组件开发

根据用户描述或设计要求，生成高质量的 React 组件代码，合理使用 Ant Design 组件和 Tailwind CSS 样式。

**组件开发原则：**

1. **优先使用 Ant Design 组件** - 对于常见 UI 元素（按钮、表单、表格、弹窗等），优先使用 Ant Design 提供的组件，它们已经过充分测试且具有良好的可访问性
2. **Tailwind CSS 用于布局和自定义样式** - 使用 Tailwind 的实用类处理布局（flex、grid）、间距、颜色等，补充 Ant Design 无法覆盖的样式需求
3. **避免样式冲突** - 注意 Tailwind CSS 的 preflight 可能与 Ant Design 的样式产生冲突，需要在 `tailwind.config.js` 中合理配置
4. **TypeScript 类型安全** - 为所有 props、state 和函数定义明确的类型
5. **函数组件 + Hooks** - 统一使用函数组件，避免使用 Class 组件
6. **性能优化** - 合理使用 `React.memo`、`useMemo`、`useCallback` 避免不必要的重渲染

**组件文件结构：**

```
ComponentName/
├── index.tsx          # 组件主文件
├── types.ts           # TypeScript 类型定义
├── hooks.ts           # 组件专用 Hooks（可选）
└── index.test.tsx     # 单元测试（可选）
```

**组件代码模板：**

```typescript
// ComponentName/types.ts
export interface ComponentNameProps {
  title?: string;
  onSubmit?: (data: FormData) => void;
  loading?: boolean;
  className?: string;
}

// ComponentName/index.tsx
import { FC } from 'react';
import { Button, Form, Input } from 'antd';
import { ComponentNameProps } from './types';

const ComponentName: FC<ComponentNameProps> = ({
  title,
  onSubmit,
  loading = false,
  className = '',
}) => {
  const [form] = Form.useForm();

  const handleFinish = (values: any) => {
    onSubmit?.(values);
  };

  return (
    <div className={`flex flex-col gap-4 p-6 bg-white rounded-lg shadow ${className}`}>
      {title && <h2 className="text-xl font-bold text-gray-800">{title}</h2>}

      <Form
        form={form}
        layout="vertical"
        onFinish={handleFinish}
      >
        <Form.Item
          name="username"
          label="用户名"
          rules={[{ required: true, message: '请输入用户名' }]}
        >
          <Input placeholder="请输入用户名" />
        </Form.Item>

        <Form.Item>
          <Button type="primary" htmlType="submit" loading={loading} className="w-full">
            提交
          </Button>
        </Form.Item>
      </Form>
    </div>
  );
};

export default ComponentName;
```

**生成组件时的注意事项：**

- 为组件添加清晰的 JSDoc 注释，说明用途和参数
- Props 应该具有合理的默认值
- 复杂逻辑抽取为自定义 Hook
- 表单使用 Ant Design 的 Form 组件，利用其验证能力
- 列表和表格使用 Ant Design 的 Table 组件
- 弹窗和抽屉使用 Ant Design 的 Modal 和 Drawer 组件
- 布局使用 Tailwind CSS 的 flex/grid 类
- 颜色优先使用 Tailwind 的颜色系统（如 `text-gray-800`、`bg-blue-500`）
- 响应式设计使用 Tailwind 的响应式前缀（`sm:`、`md:`、`lg:` 等）

### 3. 代码审查

分析现有 React 代码并提供针对性的改进建议。

**审查维度：**

**React 最佳实践：**
- 是否正确使用 Hooks（依赖数组、闭包陷阱）
- 是否避免了不必要的重渲染
- 是否合理使用了 `memo`、`useMemo`、`useCallback`
- 是否正确处理异步操作和副作用
- 是否存在内存泄漏风险（未清理的定时器、事件监听等）

**TypeScript 类型安全：**
- 是否充分利用了 TypeScript 的类型系统
- 是否存在过度使用 `any` 的情况
- 是否为所有 props 和 state 定义了类型
- 是否正确使用了泛型

**Ant Design 使用规范：**
- 是否正确使用了 Ant Design 组件的 API
- 是否有不必要的自定义实现（Ant Design 已提供）
- 表单验证是否使用了 Form 组件的能力
- 是否正确使用了 message、notification 等反馈组件

**Tailwind CSS 使用规范：**
- 是否滥用内联样式类（可考虑抽取为组件）
- 是否正确使用了响应式设计
- 是否与 Ant Design 样式产生冲突
- 是否有重复的样式组合（可抽取为自定义类）

**性能问题：**
- 列表渲染是否添加了正确的 key
- 是否存在大量的内联函数导致重渲染
- 是否存在过大的组件（应拆分）
- 是否正确使用了懒加载（React.lazy、动态 import）

**安全问题：**
- 是否存在 XSS 风险（dangerouslySetInnerHTML 的使用）
- 用户输入是否进行了验证和转义
- 敏感信息是否暴露在前端代码中

**代码质量：**
- 组件职责是否单一
- 函数复杂度是否过高（建议 < 15 行）
- 是否有重复代码可以抽取
- 命名是否清晰、符合约定
- 是否有必要的注释

### 4. 问题诊断

帮助定位和解决 React + Vite + Ant Design + Tailwind CSS 技术栈中的各类问题。

**常见问题类型和诊断方法：**

**React 相关问题：**
- **白屏/组件不渲染** - 检查 console 错误、路由配置、条件渲染逻辑
- **Hooks 报错** - 检查 Hooks 使用规则（是否在条件语句中使用、依赖数组是否正确）
- **状态更新不生效** - 检查是否直接修改了 state、是否理解了异步更新
- **无限循环渲染** - 检查 useEffect 依赖数组、是否在渲染期间调用了 setState

**Vite 相关问题：**
- **启动失败/构建失败** - 检查 vite.config.ts 配置、依赖版本冲突
- **热更新不工作** - 检查 HMR 配置、文件监听问题
- **路径别名不生效** - 检查 vite.config.ts 和 tsconfig.json 中的 alias 配置
- **环境变量不生效** - 检查 .env 文件命名和 import.meta.env 使用

**Ant Design 相关问题：**
- **组件样式不生效** - 检查是否正确导入了样式、Tailwind preflight 是否影响了 Ant Design
- **表单验证不工作** - 检查 Form.Item 的 name 属性、rules 配置
- **国际化问题** - 检查 ConfigProvider 的 locale 配置
- **主题定制不生效** - 检查 ConfigProvider 的 theme 配置

**Tailwind CSS 相关问题：**
- **样式不生效** - 检查 tailwind.config.js 的 content 配置、是否包含了所有需要扫描的文件
- **与 Ant Design 样式冲突** - 检查是否禁用了 preflight、是否使用了 important 策略
- **自定义配置不生效** - 检查 tailwind.config.js 的 theme 扩展配置
- **打包后样式丢失** - 检查生产环境的 CSS 提取配置

**样式和布局问题：**
- **布局错乱** - 检查 flex/grid 布局、Tailwind 响应式类、Ant Design 的 Grid 系统
- **样式覆盖失败** - 检查 CSS 优先级、是否需要使用 `!important`、Tailwind 的 @layer 指令
- **响应式不生效** - 检查 Tailwind 的响应式前缀、viewport meta 标签

**性能问题：**
- **首屏加载慢** - 检查是否正确使用了代码分割（React.lazy）、是否有大的依赖包未按需加载
- **页面卡顿** - 检查是否有频繁的重渲染、大量的 DOM 操作、未优化的列表渲染
- **内存占用高** - 检查是否有内存泄漏（未清理的定时器、事件监听）

**诊断流程：**
1. 收集错误信息（console 错误、堆栈跟踪、Network 请求）
2. 定位问题代码（通过报错信息、source map）
3. 分析问题原因（理解代码逻辑、检查配置）
4. 提供解决方案（代码修复、配置调整）
5. 提供预防措施（最佳实践建议）

## 工作流程

### 项目初始化流程

1. 使用 Vite 创建项目：`npm create vite@latest project-name -- --template react-ts`
2. 安装 Ant Design：`npm install antd`
3. 配置 Tailwind CSS：
   - 安装依赖：`npm install -D tailwindcss postcss autoprefixer`
   - 初始化配置：`npx tailwindcss init -p`
   - 配置 `tailwind.config.js`，设置 `corePlugins: { preflight: false }` 避免与 Ant Design 冲突
   - 在 `src/index.css` 中引入 Tailwind 指令
4. 配置项目结构（创建 components、pages、hooks、services 等目录）
5. 配置路由（安装 react-router-dom 并设置基础路由）
6. 配置 ESLint 和 Prettier
7. 创建基础布局组件
8. 配置环境变量文件（.env.development、.env.production）
9. 提供启动和构建命令说明

### 组件开发流程

1. **需求分析**：理解组件的功能需求、UI 设计、交互行为
2. **技术选型**：
   - 确定使用哪些 Ant Design 组件
   - 确定使用 Tailwind 处理哪些样式
   - 确定是否需要自定义 Hooks
3. **类型定义**：在 `types.ts` 中定义 Props 接口和其他类型
4. **代码实现**：
   - 创建函数组件
   - 使用 Ant Design 组件构建基础结构
   - 使用 Tailwind CSS 类处理布局和样式
   - 实现业务逻辑和事件处理
   - 添加必要的注释
5. **导出组件**：确保组件可以被正确导入使用
6. **提供示例**：在必要时提供组件的使用示例

### 代码审查流程

1. **读取代码**：使用 Read 工具读取目标文件
2. **全面分析**：
   - React Hooks 使用是否规范
   - TypeScript 类型是否完善
   - Ant Design 和 Tailwind 使用是否合理
   - 是否存在性能问题
   - 是否存在安全隐患
   - 代码结构是否清晰
3. **分类问题**：按严重程度分类（高优先级、中优先级、建议优化）
4. **生成报告**：使用结构化的 Markdown 格式呈现审查结果
5. **提供修复方案**：对于明确的问题，提供具体的代码修改建议

### 问题诊断流程

1. **收集信息**：
   - 错误信息和堆栈跟踪
   - 问题复现步骤
   - 相关的代码文件
   - 环境信息（Node 版本、浏览器版本）
2. **定位问题**：
   - 根据错误信息定位问题代码
   - 检查相关配置文件
   - 分析可能的原因
3. **提供解决方案**：
   - 代码级别的修复
   - 配置调整建议
   - 依赖更新建议
4. **解释原因**：说明问题产生的根本原因，帮助用户理解
5. **预防措施**：提供最佳实践建议，避免类似问题再次发生

## 配置指南

### Tailwind CSS 配置

为了避免 Tailwind CSS 与 Ant Design 的样式冲突，需要在 `tailwind.config.js` 中进行如下配置：

```javascript
/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  // 禁用 preflight，避免与 Ant Design 的基础样式冲突
  corePlugins: {
    preflight: false,
  },
  theme: {
    extend: {
      // 可以在这里扩展自定义颜色、间距等
    },
  },
  plugins: [],
}
```

在 `src/index.css` 中引入 Tailwind 指令：

```css
@tailwind base;
@tailwind components;
@tailwind utilities;
```

### Vite 配置

在 `vite.config.ts` 中配置路径别名和其他选项：

```typescript
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import path from 'path'

export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
    },
  },
  server: {
    port: 3000,
    open: true,
  },
})
```

相应地在 `tsconfig.json` 中配置路径映射：

```json
{
  "compilerOptions": {
    "baseUrl": ".",
    "paths": {
      "@/*": ["src/*"]
    }
  }
}
```

### Ant Design 配置

在 `App.tsx` 或 `main.tsx` 中配置 Ant Design：

```typescript
import { ConfigProvider } from 'antd';
import zhCN from 'antd/locale/zh_CN';

function App() {
  return (
    <ConfigProvider
      locale={zhCN}
      theme={{
        token: {
          colorPrimary: '#1677ff',
          borderRadius: 6,
        },
      }}
    >
      {/* 你的应用内容 */}
    </ConfigProvider>
  );
}
```

## React + Ant Design + Tailwind 最佳实践

### 1. 样式混合使用策略

**Ant Design 优先原则：**
- UI 组件（按钮、表单、表格、弹窗等）使用 Ant Design
- 利用 Ant Design 的内置功能（表单验证、国际化、主题定制）

**Tailwind CSS 补充：**
- 布局（flex、grid）使用 Tailwind
- 间距（margin、padding）使用 Tailwind
- 自定义颜色和背景使用 Tailwind
- 响应式设计使用 Tailwind

**示例：**
```tsx
<div className="flex items-center gap-4 p-6 bg-gray-50 rounded-lg">
  <Button type="primary">Ant Design 按钮</Button>
  <span className="text-sm text-gray-600">Tailwind 文本样式</span>
</div>
```

### 2. React Hooks 使用规范

**useState**
- 简单状态使用 useState
- 相关联的多个状态考虑合并为对象

**useEffect**
- 明确依赖数组，避免遗漏或过度依赖
- 及时清理副作用（定时器、事件监听、订阅）
- 避免在 useEffect 中直接使用异步函数

**useMemo 和 useCallback**
- 仅在确有性能问题时使用
- 优化昂贵的计算
- 避免子组件不必要的重渲染

**自定义 Hooks**
- 提取可复用的逻辑
- 命名以 `use` 开头
- 保持单一职责

### 3. TypeScript 类型定义

**Props 定义：**
```typescript
interface ButtonProps {
  // 必需属性
  text: string;
  onClick: () => void;

  // 可选属性
  type?: 'primary' | 'default' | 'dashed';
  loading?: boolean;
  disabled?: boolean;
  icon?: React.ReactNode;

  // 样式相关
  className?: string;
  style?: React.CSSProperties;

  // 子元素
  children?: React.ReactNode;
}
```

**API 响应定义：**
```typescript
interface ApiResponse<T> {
  code: number;
  message: string;
  data: T;
}

interface User {
  id: number;
  name: string;
  email: string;
  avatar?: string;
}

// 使用泛型
const fetchUser = async (id: number): Promise<ApiResponse<User>> => {
  // ...
};
```

### 4. 性能优化技巧

**列表渲染：**
- 始终提供稳定的 key（避免使用 index）
- 长列表使用虚拟滚动（react-window 或 Ant Design Table 的虚拟滚动）

**代码分割：**
```typescript
import { lazy, Suspense } from 'react';
import { Spin } from 'antd';

const Dashboard = lazy(() => import('./pages/Dashboard'));

function App() {
  return (
    <Suspense fallback={<Spin size="large" />}>
      <Dashboard />
    </Suspense>
  );
}
```

**避免内联函数：**
```typescript
// ❌ 不好 - 每次渲染都创建新函数
<Button onClick={() => handleClick(id)}>点击</Button>

// ✅ 好 - 使用 useCallback
const onClick = useCallback(() => handleClick(id), [id]);
<Button onClick={onClick}>点击</Button>
```

**组件优化：**
```typescript
import { memo } from 'react';

// 避免父组件更新导致子组件重渲染
const ExpensiveComponent = memo<Props>(({ data }) => {
  // 复杂的渲染逻辑
});
```

### 5. 表单处理最佳实践

使用 Ant Design Form 组件处理表单：

```typescript
import { Form, Input, Button, message } from 'antd';

interface FormValues {
  username: string;
  email: string;
}

const MyForm: FC = () => {
  const [form] = Form.useForm<FormValues>();

  const onFinish = async (values: FormValues) => {
    try {
      await submitForm(values);
      message.success('提交成功');
      form.resetFields();
    } catch (error) {
      message.error('提交失败');
    }
  };

  return (
    <Form
      form={form}
      layout="vertical"
      onFinish={onFinish}
    >
      <Form.Item
        name="username"
        label="用户名"
        rules={[
          { required: true, message: '请输入用户名' },
          { min: 3, message: '用户名至少3个字符' },
        ]}
      >
        <Input placeholder="请输入用户名" />
      </Form.Item>

      <Form.Item>
        <Button type="primary" htmlType="submit">
          提交
        </Button>
      </Form.Item>
    </Form>
  );
};
```

## 常见模式和代码片段

### API 请求封装

```typescript
// src/utils/request.ts
import axios from 'axios';
import { message } from 'antd';

const request = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL,
  timeout: 10000,
});

request.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

request.interceptors.response.use(
  (response) => response.data,
  (error) => {
    message.error(error.response?.data?.message || '请求失败');
    return Promise.reject(error);
  }
);

export default request;
```

### 自定义 Hook 示例

```typescript
// src/hooks/useAsync.ts
import { useState, useEffect, useCallback } from 'react';

interface AsyncState<T> {
  loading: boolean;
  data: T | null;
  error: Error | null;
}

export function useAsync<T>(
  asyncFunction: () => Promise<T>,
  immediate = true
) {
  const [state, setState] = useState<AsyncState<T>>({
    loading: immediate,
    data: null,
    error: null,
  });

  const execute = useCallback(async () => {
    setState({ loading: true, data: null, error: null });
    try {
      const data = await asyncFunction();
      setState({ loading: false, data, error: null });
      return data;
    } catch (error) {
      setState({ loading: false, data: null, error: error as Error });
      throw error;
    }
  }, [asyncFunction]);

  useEffect(() => {
    if (immediate) {
      execute();
    }
  }, [execute, immediate]);

  return { ...state, execute };
}
```

## 注意事项

1. **阅读现有代码** - 在修改代码前，先充分理解其逻辑和上下文
2. **保持一致性** - 生成代码时遵循项目现有的代码风格和约定
3. **避免过度设计** - 提供的解决方案应该是可落地的、符合实际需求的
4. **重视错误处理** - 诊断问题时，优先查看 console 错误、Network 请求和堆栈信息
5. **考虑兼容性** - 确保代码在目标浏览器中正常工作
6. **关注性能** - 但不要过早优化，先保证功能正确
7. **写清晰的代码** - 代码应该是自解释的，必要时添加注释
8. **测试你的代码** - 确保生成的代码是可运行的
