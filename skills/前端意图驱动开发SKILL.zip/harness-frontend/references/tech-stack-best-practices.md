# 技术栈最佳实践

## ⚠️ 必须遵守的版本规则

### React 版本

**使用 React 18.x，不要使用 React 19！**

原因：
- Ant Design Mobile 5.x 只支持 React 16-18
- React 19 改变了 `unmountComponentAtNode` 等 API
- 会导致运行时错误：`TypeError: unmountComponentAtNode is not a function`

```bash
# ✅ 正确
npm install react@^18.3.0 react-dom@^18.3.0

# ❌ 错误
npm install react@latest react-dom@latest  # 会安装 React 19
```

### Tailwind CSS 版本

**使用 Tailwind CSS 3.x，不要使用 Tailwind CSS 4！**

原因：
- Tailwind v4 是全新架构，配置方式完全不同
- v4 不再使用 `tailwind.config.js`
- v4 使用 `@import "tailwindcss"` 和 `@theme` 语法
- v4 还在 alpha/beta 阶段，不稳定

```bash
# ✅ 正确
npm install -D tailwindcss@^3.4.0 postcss autoprefixer

# ❌ 错误
npm install -D tailwindcss@latest  # 会安装 v4
```

**Tailwind v3 配置（正确）：**

`tailwind.config.js`:
```javascript
/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  corePlugins: {
    preflight: false,  // 禁用以避免与 Ant Design 冲突
  },
  theme: {
    extend: {
      colors: {
        'primary': '#1890ff',
      },
    },
  },
  plugins: [],
}
```

`postcss.config.js`:
```javascript
export default {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
}
```

`src/index.css`:
```css
@tailwind base;
@tailwind components;
@tailwind utilities;
```

### Vite 版本

**使用 Vite 5.x（稳定版本）**

```bash
# ✅ 正确
npm create vite@5 my-app -- --template react-ts

# ⚠️ 注意
# Vite 6 可能有兼容性问题，优先使用 Vite 5
```

### Ant Design 版本

**PC 端：Ant Design 5.x**
```bash
npm install antd@^5.21.0
```

**移动端：Ant Design Mobile 5.x**
```bash
npm install antd-mobile@^5.42.0
```

注意：
- antd-mobile 依赖 React 16-18
- 导入方式：`import { Button } from 'antd-mobile'`
- locale 路径：`antd/es/locale/zh_CN`（注意是 `/es/`）

## 初始化项目的正确姿势

### Step 1: 创建项目

```bash
# 使用 Vite 5 + React 18 + TypeScript
npm create vite@5 my-project -- --template react-ts
cd my-project
```

### Step 2: 安装依赖（指定版本）

```bash
# 核心框架（指定 React 18）
npm install react@^18.3.0 react-dom@^18.3.0

# 路由
npm install react-router-dom@^6.26.0

# UI 库（根据需要选择）
npm install antd@^5.21.0              # PC 端
# 或
npm install antd-mobile@^5.42.0       # 移动端

# 状态管理
npm install zustand@^4.5.0

# 样式（Tailwind v3）
npm install -D tailwindcss@^3.4.0 postcss@^8.4.0 autoprefixer@^10.4.0

# HTTP 请求
npm install axios@^1.7.0

# 工具库
npm install dayjs@^1.11.0
npm install lodash-es@^4.17.0
npm install -D @types/lodash-es
```

### Step 3: 复制配置模板

⚠️ **不要手动写配置文件！直接使用 templates/ 目录下的模板！**

```bash
# 从 skill 的 templates/ 目录复制
cp /path/to/frontend-skill/templates/tailwind.config.js.template tailwind.config.js
cp /path/to/frontend-skill/templates/postcss.config.js.template postcss.config.js
cp /path/to/frontend-skill/templates/vite.config.ts.template vite.config.ts
cp /path/to/frontend-skill/templates/tsconfig.json.template tsconfig.json
cp /path/to/frontend-skill/templates/index.css.template src/index.css
```

### Step 4: 验证配置

```bash
# 启动开发服务器
npm run dev

# 检查是否有错误
# ✅ 应该看到：VITE v5.x.x  ready in xxx ms
# ❌ 如果报错，检查版本是否正确
```

## 常见错误和解决方案

### 错误 1: unmountComponentAtNode is not a function

**原因**: 使用了 React 19
**解决**:
```bash
npm install react@^18.3.0 react-dom@^18.3.0
rm -rf node_modules package-lock.json
npm install
```

### 错误 2: [postcss] It looks like you're trying to use `tailwindcss` directly as a PostCSS plugin

**原因**: 安装了 Tailwind v4
**解决**:
```bash
npm uninstall tailwindcss @tailwindcss/postcss
npm install -D tailwindcss@^3.4.0
# 使用 v3 的配置文件
```

### 错误 3: 样式不生效

**检查清单**:
1. ✅ `index.css` 中是否有 `@tailwind` 指令？
2. ✅ `main.tsx` 中是否导入了 `index.css`？
3. ✅ `tailwind.config.js` 中 `content` 是否包含所有文件？
4. ✅ 是否设置了 `corePlugins.preflight: false`？

### 错误 4: Ant Design 样式冲突

**解决**:
```javascript
// tailwind.config.js
export default {
  corePlugins: {
    preflight: false,  // 必须禁用
  },
}
```

```css
/* index.css - 导入顺序很重要 */
@tailwind base;
@tailwind components;
@tailwind utilities;

/* Ant Design 样式放在最后 */
```

## 包管理最佳实践

### package.json 示例

```json
{
  "name": "my-app",
  "version": "0.0.1",
  "type": "module",
  "scripts": {
    "dev": "vite",
    "build": "tsc && vite build",
    "preview": "vite preview"
  },
  "dependencies": {
    "react": "^18.3.0",
    "react-dom": "^18.3.0",
    "react-router-dom": "^6.26.0",
    "antd": "^5.21.0",
    "zustand": "^4.5.0",
    "axios": "^1.7.0",
    "dayjs": "^1.11.0"
  },
  "devDependencies": {
    "@types/react": "^18.3.0",
    "@types/react-dom": "^18.3.0",
    "@vitejs/plugin-react": "^4.3.0",
    "typescript": "^5.5.0",
    "vite": "^5.4.0",
    "tailwindcss": "^3.4.0",
    "postcss": "^8.4.0",
    "autoprefixer": "^10.4.0"
  }
}
```

### 版本锁定策略

- 使用 `^` 允许小版本更新（推荐）
- 关键依赖使用精确版本（如 React: `18.3.0`）
- 定期更新依赖，但要测试

## 检查清单

在开始开发前，确保：

- [ ] React 版本是 18.x
- [ ] Tailwind CSS 版本是 3.x
- [ ] 使用了 templates/ 目录的配置文件
- [ ] `npm run dev` 能正常启动
- [ ] 浏览器没有版本冲突警告
- [ ] Tailwind 类名能正常生效

## 更新 Skill 内存

如果遇到版本问题，立即更新此文档，避免重复犯错！
