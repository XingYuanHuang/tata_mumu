# 全栈开发者前端开发完整指南

> 面向不太懂前端的全栈开发者，从零到完成前端并输出 API Schema

[文档内容太长，请查看上一个输出中的完整内容]

## 🎯 你的目标

**从：** 一个模糊的前端需求

**到：**
- ✅ 可运行的前端页面
- ✅ 自动生成的 API Schema（YAML格式）
- ✅ 后端智能体可以直接使用的接口文档

**时间：** 2-4 小时（前端） + 输出 API Schema（自动）

---

## 📋 完整工作流（5个步骤）

```
步骤 1️⃣  30秒静态原型          → 确认方向正确
步骤 2️⃣  定义数据结构 + Mock   → 前端快速开发
步骤 3️⃣  创建意图映射层         → 解耦组件和 API
步骤 4️⃣  自动生成 API Schema    → 输出给后端
步骤 5️⃣  后端实现 + 前端切换     → 完成联调
```

---

## 步骤 1️⃣：30秒静态原型

### 怎么做？

**告诉 AI：**
```
我要做一个审批列表页面，显示：申请人、金额、状态、通过/拒绝按钮
请生成静态原型
```

**AI 生成 HTML → 打开浏览器看效果 → 确认方向**

---

## 步骤 2️⃣：定义数据 + Mock开发

### 2.1 定义数据结构

```typescript
// src/types/approval.ts
export interface ApprovalData {
  id: string
  amount: number
  applicant: { name: string; department?: string }
  status: 'pending' | 'approved' | 'rejected'
  urgency?: 'high' | 'medium' | 'low'  // 可选字段
}
```

### 2.2 创建 Mock 数据

```typescript
// src/api/mock/approval-mock.ts
export const mockApprovals: ApprovalData[] = [
  {
    id: '1',
    amount: 12000,
    applicant: { name: '张三', department: '财务部' },
    status: 'pending',
    urgency: 'high'
  }
]

export const mockApprovalService = {
  async getApprovals() { return mockApprovals }
}
```

### 2.3 用 Mock 开发组件

```typescript
// src/pages/ApprovalList.tsx
const { data } = useQuery({
  queryKey: ['approvals'],
  queryFn: () => mockApprovalService.getApprovals()
})
```

**运行 `npm run dev`，前端完成！**

---

## 步骤 3️⃣：创建意图映射层

```typescript
// src/api/intent-map.ts
export const INTENT_MAP = {
  'ApprovalCard': {
    source: 'GET /api/approvals',
    fields: {
      'id': { from: 'approval.id', confidence: 1.0 },
      'amount': { from: 'approval.amount', confidence: 1.0 },
      'applicant.name': { from: 'approval.applicant.name', confidence: 1.0 },
      'urgency': {
        from: 'approval.priority',  // 后端可能叫 priority
        confidence: 0.7,
        fallback: null
      }
    }
  }
}
```

**Confidence 分层：**
- 1.0 = Core（后端必须实现）
- 0.6-0.8 = Assumed（后端建议实现）
- <0.6 = Experimental（前端用 Mock，暂不实现）

---

## 步骤 4️⃣：自动生成 API Schema

```bash
npm run generate:api-schema
```

生成 `api-schema.yaml`：

```yaml
GET /api/approvals:

  ## 核心字段（后端必须实现）
  approval.id:
    type: string
    required: true

  approval.amount:
    type: number
    required: true

  ## 假设字段（后端建议实现）
  approval.priority:
    type: string
    confidence: 0.7
    note: "前端正在验证价值"
```

**这个文件交给后端智能体！**

---

## 步骤 5️⃣：前端切换真实 API

```typescript
// .env.development
VITE_USE_MOCK=true

// .env.production
VITE_USE_MOCK=false
```

**组件代码不需要改！**

---

## 🎉 完成！

### 你现在有了：
- ✅ 可运行的前端
- ✅ `api-schema.yaml` 给后端
- ✅ Mock 和真实 API 无缝切换

### 核心记忆点：
1. **先原型后代码** - 30秒确认方向
2. **用 Mock 快速开发** - 不等后端
3. **意图映射层解耦** - 组件和 API 独立
4. **自动生成 Schema** - 接口从前端需求涌现

**最重要的：接口不是提前设计的，是从前端数据需求中自然涌现的。**
