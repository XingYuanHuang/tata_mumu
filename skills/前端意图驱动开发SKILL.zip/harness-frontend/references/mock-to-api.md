# Mock → API 完整流程

> 从前端数据需求到后端接口定义的自动化流程

## 核心理念

**传统方式的问题：**
- 前后端开会讨论接口格式，耗时且容易理解偏差
- 前端等后端实现接口，开发效率低
- 接口定义往往在需求最模糊时就固化了

**新方式：**
1. 前端先用 Mock 数据开发，快速验证 UI 和交互
2. Mock 数据稳定后，自动生成 API Schema
3. 后端根据 Schema 实现接口，前后端异步并行

**核心原则：接口是前端数据需求的自然涌现，不是提前设计的产物。**

## 完整工作流程

### 阶段一：前端用 Mock 数据快速开发

#### 1. 定义组件数据需求

```typescript
// components/ApprovalCard/types.ts
/**
 * INTENT: 展示做决策所需的最少信息
 *
 * DATA_REQUIREMENTS:
 *   - id (必须) - 唯一标识
 *   - amount (必须) - 核心决策依据
 *   - applicant (必须) - 申请人信息
 *   - status (必须) - 当前状态
 *   - urgency (可选) - 紧急程度，用于排序
 *   - reason (可选) - 申请原因，详情页显示
 *
 * CONFIDENCE:
 *   - id, amount, applicant, status: 1.0 (核心字段，必须有)
 *   - urgency: 0.6 (假设有用，需验证)
 *   - reason: 0.8 (很可能需要，但不确定在哪展示)
 */
export interface ApprovalData {
  id: string
  amount: number
  applicant: {
    name: string
    department?: string
    avatar?: string
  }
  status: 'pending' | 'approved' | 'rejected'
  urgency?: 'high' | 'medium' | 'low'
  reason?: string
  submittedAt: string
}
```

#### 2. 创建 Mock 数据

```typescript
// api/mock/approval-mock.ts
import { ApprovalData } from '@/components/ApprovalCard/types'

/**
 * Mock 数据生成器
 * 用途：
 * 1. 前端开发时使用
 * 2. 验证数据结构是否合理
 * 3. 发现遗漏的字段
 */
export const mockApprovals: ApprovalData[] = [
  {
    id: '1',
    amount: 12000,
    applicant: {
      name: '张三',
      department: '财务部',
      avatar: 'https://i.pravatar.cc/150?img=1'
    },
    status: 'pending',
    urgency: 'high',
    reason: '北京出差三天，参加财务年会',
    submittedAt: '2024-03-20T09:00:00Z'
  },
  {
    id: '2',
    amount: 5000,
    applicant: {
      name: '李四',
      department: '技术部'
    },
    status: 'pending',
    urgency: 'medium',
    reason: '购买开发设备',
    submittedAt: '2024-03-20T10:30:00Z'
  },
  {
    id: '3',
    amount: 50000,
    applicant: {
      name: '王五',
      department: '市场部',
      avatar: 'https://i.pravatar.cc/150?img=3'
    },
    status: 'approved',
    urgency: 'low',
    reason: '季度市场推广活动费用',
    submittedAt: '2024-03-19T14:00:00Z'
  }
]

/**
 * Mock API Service
 * 模拟异步请求，让前端代码更接近真实场景
 */
export const mockApprovalService = {
  // 获取审批列表
  getApprovals: async (filters?: {
    status?: string
    urgency?: string
  }): Promise<ApprovalData[]> => {
    // 模拟网络延迟
    await delay(300)

    let result = [...mockApprovals]

    // 模拟筛选逻辑
    if (filters?.status) {
      result = result.filter(a => a.status === filters.status)
    }
    if (filters?.urgency) {
      result = result.filter(a => a.urgency === filters.urgency)
    }

    return result
  },

  // 获取单个审批详情
  getApprovalDetail: async (id: string): Promise<ApprovalData | null> => {
    await delay(200)
    return mockApprovals.find(a => a.id === id) || null
  },

  // 提交审批决策
  approveApproval: async (id: string): Promise<{ success: boolean }> => {
    await delay(500)
    // 模拟成功
    return { success: true }
  },

  rejectApproval: async (id: string, reason: string): Promise<{ success: boolean }> => {
    await delay(500)
    return { success: true }
  }
}

function delay(ms: number) {
  return new Promise(resolve => setTimeout(resolve, ms))
}
```

#### 3. 使用 Mock 数据开发

```typescript
// pages/ApprovalList.tsx
import { useQuery, useMutation } from '@tanstack/react-query'
import { mockApprovalService } from '@/api/mock/approval-mock'
import { ApprovalCard } from '@/components/ApprovalCard'

export const ApprovalList = () => {
  // 使用 Mock Service，代码结构和真实 API 一样
  const { data: approvals, isLoading, refetch } = useQuery({
    queryKey: ['approvals'],
    queryFn: () => mockApprovalService.getApprovals()
  })

  const approveMutation = useMutation({
    mutationFn: (id: string) => mockApprovalService.approveApproval(id),
    onSuccess: () => {
      refetch()
    }
  })

  if (isLoading) return <div>加载中...</div>

  return (
    <div className="space-y-4 p-6">
      <h1 className="text-2xl font-bold">待审批列表</h1>

      {approvals?.map(approval => (
        <ApprovalCard
          key={approval.id}
          {...approval}
          onApprove={() => approveMutation.mutate(approval.id)}
        />
      ))}
    </div>
  )
}
```

### 阶段二：Mock 数据稳定后，生成 API Schema

#### 1. 分析 Mock 数据生成接口定义

```typescript
// scripts/generate-api-from-mock.ts
import { ApprovalData } from '@/components/ApprovalCard/types'
import { INTENT_MAP } from '@/api/intent-map'

/**
 * 从 Mock 数据和意图映射生成 API Schema
 */
export function generateAPISchema() {
  const schemas: any[] = []

  // 遍历所有使用 Mock 的组件
  for (const [componentName, mapping] of Object.entries(INTENT_MAP)) {
    const endpoint = mapping.source
    const fields = mapping.fields

    // 分析字段的 confidence
    const coreFields: any[] = []
    const assumedFields: any[] = []
    const experimentalFields: any[] = []

    for (const [componentField, config] of Object.entries(fields)) {
      const fieldInfo = {
        field: config.from,
        componentField,
        type: inferType(componentField),
        required: config.confidence >= 0.9,
        confidence: config.confidence,
        assumption: config.assumption,
        usedBy: componentName
      }

      if (config.confidence >= 0.9) {
        coreFields.push(fieldInfo)
      } else if (config.confidence >= 0.6) {
        assumedFields.push(fieldInfo)
      } else {
        experimentalFields.push(fieldInfo)
      }
    }

    schemas.push({
      endpoint,
      method: 'GET',
      intent: mapping.intent || `为 ${componentName} 提供数据`,
      coreFields,
      assumedFields,
      experimentalFields
    })
  }

  return schemas
}

// 类型推断辅助函数
function inferType(fieldName: string): string {
  if (fieldName.includes('id')) return 'string'
  if (fieldName.includes('amount') || fieldName.includes('count')) return 'number'
  if (fieldName.includes('is') || fieldName.includes('has')) return 'boolean'
  if (fieldName.includes('at') || fieldName.includes('time') || fieldName.includes('date')) return 'datetime'
  if (fieldName.includes('list') || fieldName.includes('items')) return 'array'
  return 'string'
}
```

#### 2. 导出为 YAML 格式（给后端使用）

```typescript
// scripts/export-api-schema.ts
import fs from 'fs'
import { generateAPISchema } from './generate-api-from-mock'

/**
 * 生成给后端的 API Schema 文档
 */
function exportToYAML() {
  const schemas = generateAPISchema()

  const yaml = schemas.map(schema => `
# ${schema.intent}
${schema.method} ${schema.endpoint}:

  ## 核心字段（必须实现，confidence >= 0.9）
${schema.coreFields.map((f: any) => `
  ${f.field}:
    type: ${f.type}
    required: true
    used_by: ${f.usedBy}
    description: "${f.componentField} - 前端必需字段"
`).join('')}

  ## 假设字段（建议实现，confidence 0.6-0.8）
${schema.assumedFields.map((f: any) => `
  ${f.field}:
    type: ${f.type}
    required: false
    confidence: ${f.confidence}
    assumption: "${f.assumption || '前端假设有用'}"
    used_by: ${f.usedBy}
    note: "后端可以迭代实现此字段"
`).join('')}

  ## 实验性字段（暂不实现，confidence < 0.6）
${schema.experimentalFields.length > 0 ? schema.experimentalFields.map((f: any) => `
  ${f.field}:
    type: ${f.type}
    required: false
    confidence: ${f.confidence}
    note: "前端正在用 Mock 探索此字段的价值，暂不需要后端实现"
`).join('') : '  # 无实验性字段'}

---
`).join('\n')

  return yaml
}

// 执行导出
const yamlContent = exportToYAML()
fs.writeFileSync('api/schemas/api-schema.yaml', yamlContent, 'utf-8')
console.log('✅ API Schema 已导出到 api/schemas/api-schema.yaml')
```

生成的 YAML 示例：

```yaml
# 为 ApprovalCard 提供数据
GET /api/approvals:

  ## 核心字段（必须实现，confidence >= 0.9）

  approval.id:
    type: string
    required: true
    used_by: ApprovalCard
    description: "id - 前端必需字段"

  approval.amount:
    type: number
    required: true
    used_by: ApprovalCard
    description: "amount - 前端必需字段"

  approval.applicant.name:
    type: string
    required: true
    used_by: ApprovalCard
    description: "applicant.name - 前端必需字段"

  approval.status:
    type: string
    required: true
    used_by: ApprovalCard
    description: "status - 前端必需字段"

  ## 假设字段（建议实现，confidence 0.6-0.8）

  approval.urgency:
    type: string
    required: false
    confidence: 0.7
    assumption: "用户会根据紧急程度排序"
    used_by: ApprovalCard
    note: "后端可以迭代实现此字段"

  approval.reason:
    type: string
    required: false
    confidence: 0.8
    assumption: "支撑审批决策的上下文信息"
    used_by: ApprovalCard
    note: "后端可以迭代实现此字段"

  ## 实验性字段（暂不实现，confidence < 0.6）

  approval.similarCases:
    type: array
    required: false
    confidence: 0.3
    note: "前端正在用 Mock 探索此字段的价值，暂不需要后端实现"

---
```

### 阶段三：后端实现接口

后端智能体接收到 `api-schema.yaml` 后：

1. **优先实现核心字段**（confidence >= 0.9）
2. **迭代实现假设字段**（confidence 0.6-0.8）
3. **暂不实现实验性字段**（confidence < 0.6）

后端返回的 JSON 结构：

```json
{
  "approvals": [
    {
      "id": "uuid-1",
      "amount": 12000,
      "applicant": {
        "name": "张三",
        "dept": "财务部"
      },
      "status": "pending",
      "priority": "high",
      "reason": "北京出差三天",
      "submittedAt": "2024-03-20T09:00:00Z"
    }
  ]
}
```

### 阶段四：前端切换到真实 API

#### 1. 更新 API Service

```typescript
// api/approval-service.ts
import { ApprovalData } from '@/components/ApprovalCard/types'
import { useIntentData } from '@/hooks/useIntentData'

const USE_MOCK = import.meta.env.VITE_USE_MOCK === 'true'

export const approvalService = {
  getApprovals: async (filters?: any): Promise<ApprovalData[]> => {
    if (USE_MOCK) {
      // 开发环境使用 Mock
      const { mockApprovalService } = await import('./mock/approval-mock')
      return mockApprovalService.getApprovals(filters)
    }

    // 生产环境使用真实 API
    const response = await fetch('/api/approvals')
    const raw = await response.json()

    // 通过 INTENT_MAP 转换数据
    return raw.approvals.map((item: any) =>
      useIntentData<ApprovalData>('ApprovalCard', item)
    )
  }
}
```

#### 2. 环境变量控制

```bash
# .env.development
VITE_USE_MOCK=true

# .env.production
VITE_USE_MOCK=false
```

#### 3. 组件代码不需要修改

```typescript
// pages/ApprovalList.tsx
// 完全不需要改，因为 Service 层做了抽象
const { data: approvals } = useQuery({
  queryKey: ['approvals'],
  queryFn: () => approvalService.getApprovals()
})
```

## Mock 数据管理最佳实践

### 1. Mock 数据的组织结构

```
api/
├── mock/
│   ├── approval-mock.ts      # 审批相关 Mock
│   ├── user-mock.ts          # 用户相关 Mock
│   ├── fixtures/             # 固定的测试数据
│   │   ├── users.json
│   │   └── approvals.json
│   └── generators/           # 数据生成器
│       ├── user-generator.ts
│       └── approval-generator.ts
├── services/
│   ├── approval-service.ts   # 真实 API Service
│   └── user-service.ts
└── schemas/
    └── api-schema.yaml       # 自动生成的接口文档
```

### 2. Mock 数据生成器

```typescript
// api/mock/generators/approval-generator.ts
import { faker } from '@faker-js/faker'
import { ApprovalData } from '@/components/ApprovalCard/types'

/**
 * 生成大量 Mock 数据，用于测试极端情况
 */
export function generateApprovals(count: number): ApprovalData[] {
  return Array.from({ length: count }, (_, i) => ({
    id: `approval-${i + 1}`,
    amount: faker.number.int({ min: 100, max: 100000 }),
    applicant: {
      name: faker.person.fullName(),
      department: faker.helpers.arrayElement(['财务部', '技术部', '市场部', '运营部']),
      avatar: faker.image.avatar()
    },
    status: faker.helpers.arrayElement(['pending', 'approved', 'rejected']),
    urgency: faker.helpers.arrayElement(['high', 'medium', 'low']),
    reason: faker.lorem.sentence(),
    submittedAt: faker.date.recent().toISOString()
  }))
}

// 极端情况测试数据
export const edgeCaseMocks = {
  // 超长文本
  longText: {
    id: 'edge-1',
    amount: 999999.99,
    applicant: {
      name: '欧阳震华南区市场部门高级主管兼财务总监',
      department: '市场运营与品牌推广第一事业部'
    },
    status: 'pending',
    reason: faker.lorem.paragraphs(5)
  },

  // 空列表
  empty: [],

  // 单条数据
  single: [generateApprovals(1)[0]]
}
```

### 3. Mock 数据版本管理

```typescript
// api/mock/versions.ts
/**
 * Mock 数据版本，用于跟踪数据结构的演变
 */
export const MOCK_VERSION = {
  current: '2.0',
  history: [
    {
      version: '1.0',
      date: '2024-03-01',
      changes: '初始版本，基础字段'
    },
    {
      version: '1.5',
      date: '2024-03-10',
      changes: '添加 urgency 字段，confidence 0.6'
    },
    {
      version: '2.0',
      date: '2024-03-20',
      changes: 'urgency 验证有效，confidence 提升到 0.8'
    }
  ]
}
```

## 自动化工作流

### 完整的 npm scripts

```json
{
  "scripts": {
    "dev": "vite",
    "dev:mock": "VITE_USE_MOCK=true vite",
    "dev:api": "VITE_USE_MOCK=false vite",

    "generate:api-schema": "tsx scripts/export-api-schema.ts",
    "generate:mock": "tsx scripts/generate-mock-data.ts",

    "check:api-alignment": "tsx scripts/check-api-alignment.ts"
  }
}
```

### API 对齐检查

```typescript
// scripts/check-api-alignment.ts
/**
 * 检查真实 API 是否符合 INTENT_MAP 的期望
 */
async function checkAPIAlignment() {
  const schemas = generateAPISchema()

  for (const schema of schemas) {
    console.log(`\n检查 ${schema.endpoint}...`)

    try {
      const response = await fetch(`http://localhost:3000${schema.endpoint}`)
      const data = await response.json()

      // 检查核心字段是否存在
      for (const field of schema.coreFields) {
        const value = getNestedValue(data, field.field)
        if (value === undefined) {
          console.error(`❌ 缺少核心字段: ${field.field}`)
        } else {
          console.log(`✅ ${field.field}`)
        }
      }
    } catch (error) {
      console.error(`❌ API 请求失败: ${error}`)
    }
  }
}

checkAPIAlignment()
```

## 总结

Mock → API 流程的核心价值：

1. **前端不等后端** - 用 Mock 数据快速开发和验证
2. **接口自然涌现** - Mock 数据稳定后自动生成接口定义
3. **异步并行协作** - 前后端通过 Schema 文件异步协作
4. **减少沟通成本** - 不需要开会讨论接口格式
5. **渐进式实现** - 后端按 confidence 优先级实现字段

**记住：不要提前设计接口，让接口从前端的真实数据需求中自然涌现。**
