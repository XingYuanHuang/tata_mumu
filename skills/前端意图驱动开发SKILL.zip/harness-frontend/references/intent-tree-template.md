# 意图树模板（Intent Tree Template）

## 项目级意图树（INTENT_TREE/README.md）

```markdown
# [项目名称] - 项目意图树

## 项目意图（WHY）

为什么要做这个项目？解决什么问题？

示例：
> 创建一个类似微信的即时通讯应用，让用户可以发送消息、查看朋友圈、管理联系人。

## 核心价值

用户通过这个应用能获得什么？

示例：
- ✅ 即时沟通 - 快速发送和接收消息
- ✅ 社交网络 - 查看朋友动态
- ✅ 便捷服务 - 一站式生活服务入口

## 技术栈

- **框架**: React 18.x
- **构建工具**: Vite 5.x
- **UI 库**: Ant Design Mobile 5.x
- **样式**: Tailwind CSS 3.x
- **状态管理**: Zustand 4.x
- **路由**: React Router 6.x

## 页面架构

```
App (Root)
├── Login (登录页) - /login
├── ChatList (聊天列表) - /chats
│   └── TabBar (底部导航)
├── ChatDetail (聊天详情) - /chat/:id
├── Contacts (通讯录) - /contacts
│   └── TabBar
├── Discover (发现) - /discover
│   └── TabBar
├── Moments (朋友圈) - /moments
├── Profile (个人资料) - /profile
│   └── TabBar
└── Settings (设置) - /settings
```

## 共享组件

- `TabBar` - 底部导航栏（4个Tab）
- `Avatar` - 用户头像（渐变色）
- `Badge` - 未读消息红点

## 关键设计决策

1. **移动端优先** - 375px 宽度，适配手机屏幕
2. **品牌色** - 微信绿 #07C160
3. **导航模式** - 底部 Tab 导航，主流移动应用模式
4. **状态管理** - 使用 Zustand 而非 Redux，更轻量

## 待解决问题

- [ ] 真实消息发送需要后端 API
- [ ] 图片上传功能需要 OSS 服务
- [ ] 语音消息需要录音权限
```

---

## 页面级意图树（INTENT_TREE/02-ChatList.md）

```markdown
# 聊天列表页 - 页面意图树

## 页面意图（WHY）

展示用户的所有聊天会话，快速找到想要联系的人。

## 成功指标（SUCCESS_SIGNAL）

- ✅ 用户能在 3 秒内找到目标聊天
- ✅ 未读消息红点显示准确
- ✅ 点击聊天项进入详情页响应 < 200ms

## 组件树（WHAT）

**⚠️ 这是最重要的部分！必须清晰列出所有组件及其调用关系**

```
ChatList (Page) - src/pages/ChatList/index.tsx
│
├── TopBar (内联组件)
│   ├── Title: "微信"
│   ├── SearchButton: 🔍
│   └── AddButton: ➕
│
├── ChatListContainer (主内容区)
│   └── ChatItem (组件) × N
│       ├── Avatar (内联)
│       │   └── 渐变色背景 + Emoji
│       ├── ChatInfo (内联)
│       │   ├── Name: 联系人名称
│       │   ├── LastTime: 最后消息时间
│       │   └── LastMessage: 最后消息内容
│       └── UnreadBadge (条件渲染)
│           └── 红色圆点 + 未读数
│
└── TabBar (共享组件) - src/components/TabBar/index.tsx
    └── Tab × 4: 微信/通讯录/发现/我
```

**组件说明：**

- **ChatList**: 页面容器，负责数据获取和路由跳转
  - 文件：`src/pages/ChatList/index.tsx`
  - Props: 无
  - State: `chats` (从 Zustand Store 获取)

- **ChatItem**: 单个聊天项（内联在 ChatList 中）
  - Props: `chat: Chat` (包含 id, name, lastMessage, lastTime, unreadCount)
  - Events: `onClick` → 导航到 `/chat/:id`

- **TabBar**: 底部导航栏（共享组件）
  - 文件：`src/components/TabBar/index.tsx`
  - Props: 无
  - State: `activeTab` (从 Zustand Store 获取)

## 数据流（HOW）

### 输入数据：
```typescript
interface Chat {
  id: string
  name: string
  type: 'single' | 'group'
  lastMessage: string
  lastTime: string
  unreadCount: number
}

// 来源：src/store/index.ts
const chats: Chat[] = useAppStore(state => state.chats)
```

### 输出数据：
- 导航到聊天详情页：`navigate(/chat/${chatId})`

### 状态管理：
- ✅ 使用 Zustand Store
- ✅ Store 路径：`src/store/index.ts`
- ✅ Mock 数据：`src/api/mock/data.ts`

## 实现清单（CHECKLIST）

**文件清单：**
- [ ] `src/pages/ChatList/index.tsx` - 主页面组件
- [ ] `src/components/TabBar/index.tsx` - 底部导航（如果不存在）
- [ ] `src/store/index.ts` - Zustand Store（如果不存在）
- [ ] `src/api/mock/data.ts` - Mock 聊天数据（如果不存在）

**功能清单：**
- [ ] 显示聊天列表（从 Store 获取数据）
- [ ] 渲染头像（渐变色 + Emoji）
- [ ] 显示未读红点（unreadCount > 0）
- [ ] 点击跳转到聊天详情
- [ ] 顶部搜索和添加按钮（暂无功能）
- [ ] 底部导航栏切换

**样式清单（与原型一致）：**
- [ ] 头像：`w-12 h-12 bg-gradient-to-br from-blue-400 to-blue-500 rounded-lg`
- [ ] 列表项：`p-4 hover:bg-gray-50`
- [ ] 未读红点：`w-5 h-5 bg-red-500 rounded-full text-white text-xs`
- [ ] 分割线：`divide-y divide-gray-200`

## 关键设计决策

1. **头像颜色策略**：根据 chat.id 计算颜色（blue/pink/purple/green 循环）
2. **未读数显示**：超过 99 显示 "99+"
3. **时间格式**：相对时间（"2小时前"、"昨天"、"星期二"）

## 待解决问题（OPEN_QUESTIONS）

- [ ] 是否需要下拉刷新功能？
- [ ] 聊天置顶功能如何实现？
- [ ] 删除聊天需要二次确认吗？

## 影响范围（AFFECTS）

- `src/pages/ChatDetail/index.tsx` - 聊天详情页（接收 chatId）
- `src/components/TabBar/index.tsx` - 底部导航（共享）
- `src/store/index.ts` - 状态管理

## 迭代记录

- 2024-03-25: 初始版本，实现基础列表功能
- 2024-03-25: 添加未读红点功能
```

---

## 关键要点总结

### 1. 组件树必须包含：
- ✅ 完整的组件层级关系（父子关系清晰）
- ✅ 每个组件的文件路径
- ✅ 组件是内联还是独立文件
- ✅ Props 和 State 说明

### 2. 实现清单必须包含：
- ✅ 所有需要创建的文件
- ✅ 所有功能点
- ✅ 样式的 Tailwind 类名（从原型复制）

### 3. 数据流必须包含：
- ✅ 输入数据的类型和来源
- ✅ 输出数据的去向
- ✅ 状态管理方式

### 4. 影响范围必须包含：
- ✅ 会被当前页面调用的组件
- ✅ 会调用当前页面的组件
- ✅ 共享的 Store 或 Service

这样可以确保：
1. **实现和意图树完全一致** - 写代码时对照意图树，不会遗漏
2. **组件关系清晰** - 一眼看出哪些是独立组件，哪些是内联
3. **方便检查完整性** - 实现完成后对照 Checklist，确保没有遗漏
