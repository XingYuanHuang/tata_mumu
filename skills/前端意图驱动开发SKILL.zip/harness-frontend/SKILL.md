---
name: harness-frontend
description: React + Vite + Ant Design + Tailwind CSS 前端研发全能助手。支持两种开发模式：传统模式（需求明确时）和意图驱动模式（探索性开发时）。当用户提到任何前端开发任务、组件开发、页面实现、代码优化、问题诊断时使用此 skill。即使用户简单说"做个XXX"、"加个功能"、"改一下"都应该触发此 skill。
---

# Frontend Skill - 前端研发全能助手

基于 **React + Vite + Ant Design + Tailwind CSS** 技术栈的前端研发助手，提供两种开发模式以适应不同场景。

---

## 👋 欢迎使用 Frontend Skill

### 📋 完整开发流程

使用本 Skill 开发项目，AI 将引导您完成以下步骤：

#### 🎯 意图驱动模式（推荐用于新项目）

```
第 0 步：权限设置
  ↓  AI 会提示您设置文件操作权限，请选择 "Yes, allow all edits in xxx/ during this session"

第 1 步：生成原型（30 秒）
  ↓  AI 自动生成 3 个不同风格的主题原型（HTML 可视化）

第 2 步：原型对齐
  ├─ 阶段 2.1：选择主题风格（A/B/C 三选一）
  └─ 阶段 2.2：设计功能模块（拆解需求，逐个确认）⭐ 不要跳过！

第 3 步：React 实现
  ↓  AI 基于确认的原型，创建完整的 React 项目

第 4 步：测试验证
  └─ 启动开发服务器，实时预览和调整
```

#### ⚡ 传统开发模式（需求已明确时）

```
需求分析 → 设计组件 → 编写代码 → 测试优化
```

---

### ⚠️ 重要注意事项

#### 1. **不要跳过原型阶段**
- ❌ 错误：直接说"帮我做个 XXX 网站"就开始写代码
- ✅ 正确：让 AI 先生成 3 个原型，选择风格后再实现

#### 2. **阶段 2.2 最关键**
- 这一步会拆解所有功能模块，逐个确认
- 跳过这步会导致实现结果与预期不符
- AI 会引导您确认每个模块的设计

#### 3. **权限设置必不可少**
- 原型阶段会创建 4+ 个文件
- React 实现会创建 10+ 个文件
- 不设置权限会导致频繁弹窗确认

#### 4. **如何正确启动**
只需告诉 AI 您的需求，例如：
- "我要做一个企业官网"
- "帮我创建一个管理后台"
- "做个电商网站"

AI 会自动：
1. 提醒您设置权限
2. 询问需求细节
3. 生成原型供您选择
4. 基于确认的原型实现 React 项目

#### 5. **如果遇到 AI 跳过步骤**
直接说：
- "请按照 frontend-skill 的标准流程"
- "先生成原型，不要直接写代码"
- "我们还没有完成原型对齐"

---

## ⚠️ 使用前必读 - 权限设置

**此 Skill 涉及大量文件操作（创建原型、生成 React 项目、批量写入文件），为避免频繁的权限确认提示：**

AI 会在开始项目时主动触发权限请求，请在弹窗中选择：
- **"Yes, allow all edits in xxx/ during this session"**（本次会话允许编辑特定目录，其中 xxx 为实际项目目录名）

### 为什么需要项目级权限？

此 Skill 的工作流程：
1. **原型生成** - 一次性创建 4+ 个 HTML 文件
2. **React 实现** - 批量创建 10+ 个源文件（组件、页面、API）
3. **意图树生成** - 为每个源文件创建对应的意图文件

项目级权限可确保后续文件操作流畅进行，无需频繁确认。

---

## 快速开始

### 1. 选择项目模板

根据项目类型和开发阶段选择合适的模板：

#### 原型模板（意图驱动模式 - 第一阶段）

**适用场景：** 需求不明确时，先生成可视化原型验证想法

**模板文件：** `templates/prototype-shell-template.html`

**特点：**
- ✅ 统一的设计工具面板（类似 Figma）
- ✅ iframe + Tab 切换架构
- ✅ 键盘快捷键、自动刷新、缩放功能
- ✅ 支持主题选择 → 模块设计的两阶段流程

**使用方式：**
```bash
# 读取模板，替换占位符，生成标准结构
Read templates/prototype-shell-template.html
# → 生成 <项目名>/prototype/index.html + themes/*.html
```

**详细指南：** 必看 → `templates/PROTOTYPE_SHELL_GUIDE.md`

---

#### React 基础模板（意图驱动模式 - 第二阶段）

**适用场景：** 快速原型、单页应用、个人项目、探索性开发

**特点：**
- ✅ 轻量级（React + Tailwind + Zustand + React Router）
- ✅ 30 秒完成初始化
- ✅ 预防所有已知配置错误
- ✅ 包含最佳实践示例

**使用方式：**
```bash
# 一键初始化
cp -r templates/react-base <项目名>
cd <项目名> && npm install
npm run dev > /tmp/dev-server.log 2>&1 &
```

**详细文档：** `references/react-best-practices.md`

---

#### React + Ant Design 模板（传统开发模式）

**适用场景：** 管理后台、企业应用、需要完整 UI 组件库

**特点：**
- ✅ 包含 Ant Design（PC + Mobile）
- ✅ 完整的企业级配置
- ✅ 已解决所有样式冲突

**使用方式：**
```bash
# 复制所有模板文件
cp templates/*.template <项目目录>
# 详见 references/tech-stack-best-practices.md
```

**详细文档：** `references/tech-stack-best-practices.md`

---

### 2. 选择开发模式

根据需求明确程度选择：

```
需求明确？
  ├─ 是 → 传统开发模式（直接写代码）
  └─ 否 → 意图驱动模式（先原型后代码）
```

---

## 两种开发模式

### 模式 1：传统开发模式

**适用场景：**
- ✅ 需求明确，技术方案清晰
- ✅ 维护现有项目，修复 bug
- ✅ 标准的 CRUD 功能开发

**工作流：**
```
需求分析 → 设计组件 → 编写代码 → 测试优化
```

**详细文档：** `references/traditional-dev.md`

---

### 模式 2：意图驱动模式

**适用场景：**
- ✅ 需求不明确，需要快速验证想法
- ✅ 探索性开发，尝试多种方案
- ✅ 用户难以用语言描述需求

**核心特点：**
- 30 秒生成静态原型
- **两阶段设计流程**（主题选择 → 模块设计）
- **统一原型框架**（iframe + Tab 切换）
- Branch A/B 原型对齐循环
- 意图树驱动实现

**工作流：**
```
输入识别
  ↓
第一步：生成 3 个主题原型
  ↓
第二步：原型对齐（两个阶段）
  ├─ 阶段 2.1：主题选择对齐（用户选择 A/B/C）
  └─ 阶段 2.2：模块设计对齐（拆解功能，逐个确认）  ↓
第三步：React 实现
```

**⚠️ 重要：不要跳过阶段 2.2，必须先设计模块原型再实现！**

**详细文档：** `references/intent-driven-dev.md`
**模板使用：** `templates/PROTOTYPE_SHELL_GUIDE.md`

---

## 意图驱动模式核心流程

### 准备工作：权限设置

**⚠️ 开始任何项目前，AI 必须主动请求整个项目文件夹的权限！**

**🚨 核心问题：被动 vs 主动**

**❌ 错误做法（被动等待）：**
```
1. 告诉用户"请在弹窗时选择 'Yes, allow all edits in xxx/ during this session'"
2. 开始创建第一个文件
3. 第一个文件被拦截 → 用户授权
4. 创建第二个文件 → 可能还会被拦截
5. 用户需要多次点击授权 → 体验差
```

**✅ 正确做法（主动触发）：**
```
1. 告诉用户即将请求项目文件夹权限
2. 创建项目目录 + 一个测试文件（主动触发权限弹窗）
3. 用户在弹窗中一次性授权整个文件夹
4. 批量创建所有原型文件 → 全程无拦截
5. 删除测试文件（清理）
```

---

**AI 话术模板（必须使用）：**

```
🔐 项目权限设置

即将在 <完整路径> 创建项目。
请在弹窗中选择：

✅ "Yes, allow all edits in <项目名>/ during this session"

这样可以一次性授权，后续文件操作不会被拦截。

准备好了请回复 "继续"。
```

---

**执行流程（严格遵守）：**

**步骤 1：确定项目路径**
```
自动确定项目创建位置：
- 优先使用 /Users/<username>/work/<项目名>
- 或当前工作目录的合理父目录
```

**步骤 2：发送权限提醒**
```
使用话术模板，明确告知用户项目将创建在哪里
```

**步骤 3：等待用户确认**
```
用户回复"继续"、"OK"、"好的"等
```

**步骤 4：创建项目目录并触发权限**
```bash
# 创建项目根目录
mkdir -p <项目路径>

# 创建测试文件，触发权限弹窗
Write <项目路径>/.permission-test
```

**步骤 5：用户授权后，清理并创建文件**
```bash
# 删除测试文件
rm <项目路径>/.permission-test

# 创建子目录
mkdir -p <项目路径>/prototype/themes

# 并发创建所有文件
Write <项目路径>/prototype/index.html
Write <项目路径>/prototype/themes/theme-a.html
Write <项目路径>/prototype/themes/theme-b.html
Write <项目路径>/prototype/themes/theme-c.html
```

---

**为什么这样做？**

1. **主动而非被动** - 在创建文件之前就触发权限请求，而不是等第一个文件被拦截
2. **一次性授权** - 用户只需要点击一次授权，覆盖整个项目文件夹
3. **批量操作流畅** - 后续所有文件创建都不会被拦截，体验流畅
4. **用户体验更好** - 不会在创建文件过程中被多次打断

---

**重要原则：**
- ✅ **每次开始新项目都要主动触发权限请求** - 不要等第一个文件被拦截
- ✅ **使用测试文件触发弹窗** - `.permission-test` 或任意临时文件
- ✅ **明确告知选择正确的权限选项** - "Yes, allow all edits in xxx/ during this session" (精确范围,更安全,xxx 为实际目录名)
- ✅ **授权后立即批量创建文件** - 充分利用已授权的权限
- ❌ **不要被动等待拦截** - 这会导致用户需要多次授权
- ❌ **不要让用户设置全局权限**（/permissions auto）- 安全考虑
- ❌ **不要假设用户已经了解权限机制** - 每次都要提醒

---

**对比示例：**

**❌ 旧流程（被动，体验差）：**
```
AI: "请在弹窗时选择 'Yes, allow all edits in xxx/ during this session'"
AI: [创建 index.html]
    → 弹窗 → 用户点击授权
AI: [创建 theme-a.html]
    → 可能再次弹窗 → 用户再次授权
AI: [创建 theme-b.html]
    → 可能又弹窗 → 用户又授权
用户：😡 为什么要点这么多次？
```

**✅ 新流程（主动，体验好）：**
```
AI: "我会先创建项目文件夹并触发权限请求，请在弹窗中选择 'Yes, allow all edits in xxx/ during this session'"
用户："继续"
AI: [创建 <项目名>/.permission-test]
    → 弹窗 → 用户点击授权（只需一次）
AI: [并发创建所有文件：index.html, theme-a.html, theme-b.html, theme-c.html]
    → 全程无拦截 ✅
用户：😊 很流畅！
```

---

### 第一步：原型生成（30秒）

⚠️ **关键要求：必须使用标准模板结构！**

**正确流程：**
1. 📖 **读取框架模板**：`templates/prototype-shell-template.html`
2. 📁 **创建项目目录**：`mkdir -p <项目名>/prototype/themes`
   - ⚠️ **重要**：在项目根目录操作，不要进入 prototype 子目录！
3. 🎨 **并发生成文件**：一次性写入 4 个文件
   - Write <项目名>/prototype/index.html
   - Write <项目名>/prototype/themes/theme-a.html
   - Write <项目名>/prototype/themes/theme-b.html
   - Write <项目名>/prototype/themes/theme-c.html
4. 🔄 **启动 web 服务器**：cd 到 prototype 目录再启动

**❌ 错误做法：** 不要直接写一个巨大的单文件 HTML，把所有内容都塞在一起！

**✅ 正确结构：**
```
<项目名>/prototype/
├── index.html          # 统一框架（由模板生成）
└── themes/             # 主题文件目录
    ├── theme-a.html    # 主题 A（只包含内容）
    ├── theme-b.html    # 主题 B（只包含内容）
    └── theme-c.html    # 主题 C（只包含内容）
```

**🚨 关键错误：第一版 index.html 不要包含模块 Tab！**

**❌ 错误示例：一次性添加所有 Tab**
```html
<!-- ❌ 错误：第一阶段就包含了模块 Tab -->
<button id="tab-theme-a">主题A</button>
<button id="tab-theme-b">主题B</button>
<button id="tab-theme-c">主题C</button>
<div class="tab-divider"></div>
<button id="tab-module-dashboard">工作台</button>  ❌ 太早了！
<button id="tab-module-articles">文章管理</button>  ❌ 还没设计！
```

**✅ 正确示例：分阶段添加**

**第一版 index.html（阶段 2.1 - 主题选择）：**
```html
<!-- ✅ 正确：只包含 3 个主题 Tab -->
<button id="tab-theme-a" class="tab-btn theme-tab ...">🎨 主题A</button>
<button id="tab-theme-b" class="tab-btn theme-tab ...">🎨 主题B</button>
<button id="tab-theme-c" class="tab-btn theme-tab ...">🎨 主题C</button>
<!-- 没有分隔线，没有模块 Tab -->

<script>
const TAB_IDS = ['theme-a', 'theme-b', 'theme-c'];  // 只有主题
</script>
```

**第二版 index.html（阶段 2.2 - 模块设计）：**
```html
<!-- 用户选择主题C后，移除A和B，添加模块 Tab -->
<button id="tab-theme-c" class="tab-btn theme-tab ...">🎨 主题C</button>
<div class="tab-divider"></div>  <!-- ✅ 现在添加分隔线 -->
<button id="tab-module-dashboard" class="tab-btn module-tab ...">📊 工作台</button>
<button id="tab-module-articles" class="tab-btn module-tab ...">📝 文章管理</button>

<script>
const TAB_IDS = ['theme-c', 'module-dashboard', 'module-articles'];
</script>
```

**为什么要分阶段？**
1. **避免混淆**：用户看到还不存在的模块Tab会困惑
2. **清晰流程**：明确"先选主题，再设计模块"的顺序
3. **渐进式设计**：每个阶段专注一个目标
4. **更好体验**：不会出现"点击Tab发现页面不存在"的情况

**详细指南：** 必看 → `templates/PROTOTYPE_SHELL_GUIDE.md`

---

**⚡ 性能优化与用户体验：**

1. **在项目根目录操作** - 使用绝对路径
   ```bash
   # ✅ 正确：在根目录操作，使用绝对路径
   mkdir -p <项目名>/prototype/themes
   Write <项目名>/prototype/index.html
   Write <项目名>/prototype/themes/theme-a.html

   # ❌ 错误：进入子目录后操作
   cd <项目名>/prototype
   Write index.html  # 路径不清晰，容易出错
   ```

2. **并发写入文件** - 提高生成速度
   ```bash
   # ✅ 正确：在一个消息中并发调用 4 次 Write
   Write <项目名>/prototype/index.html
   Write <项目名>/prototype/themes/theme-a.html
   Write <项目名>/prototype/themes/theme-b.html
   Write <项目名>/prototype/themes/theme-c.html
   ```

3. **精简输出内容** - 不打断用户
   ```markdown
   ✅ 只显示粗粒度进度：
   "正在生成原型框架和 3 个主题..."

   ❌ 不要：
   - 打印每个文件的详细内容
   - 逐个说明每个文件的生成过程
   - 展示大量代码片段
   ```

4. **启动 Web 服务器并打开浏览器**

   **⚠️ 关键规则：**
   - 一条命令完成所有操作（kill + cd + start + open），不要分步执行
   - 必须在命令中使用 cd 指定完整路径
   - 如果命令执行后没有预期效果，先检查状态（ps/lsof/pwd），不要重复执行相同命令

   ```bash
   # 正确示例：确保服务器就绪后再打开浏览器
   lsof -ti:8899 | xargs kill -9 2>/dev/null; cd <项目名>/prototype && npx live-server --port=8899 --no-browser --ignorePattern=".*\.log$" > /tmp/prototype-server.log 2>&1 & for i in {1..30}; do curl -s http://localhost:8899 > /dev/null && break || sleep 0.5; done && open http://localhost:8899/index.html
   ```

   **工作原理：**
   - 清理旧端口 → 启动 live-server 后台运行
   - 循环检查服务器是否就绪（最多尝试30次，每次间隔0.5秒）
   - 一旦 curl 成功访问，立即打开浏览器
   - 最长等待时间：15秒（通常1-2秒内就绪）

   **为什么必须用 live-server？⭐**
   - ✅ **文件修改自动刷新** - 修改任何 .html 文件立即在浏览器中生效
   - ✅ 自动禁用缓存 - 无需手动清缓存或硬刷新
   - ✅ WebSocket 实时通信 - 比轮询 Last-Modified 更可靠
   - ✅ 支持 iframe - 框架和模块都能正常工作
   - ✅ 无需安装 - npx 直接运行

   **备选方案（不推荐）：**
   如果 npx 不可用，使用 Python SimpleHTTPServer：
   ```bash
   python3 -m http.server 8899 > /tmp/prototype-server.log 2>&1 &
   open "http://localhost:8899/index.html?_=$(date +%s)"
   ```
   ⚠️ 缺点：修改文件后需要手动刷新浏览器（`Cmd + Shift + R`）

5. **简洁的完成提示**
   ```markdown
   ✅ 原型已生成，服务器已启动
   🌐 访问: http://localhost:8899/index.html

   - 主题 A：极简优雅风格
   - 主题 B：卡片瀑布流风格
   - 主题 C：传统博客风格

   用键盘 ← → 快速切换查看
   ```

---

**输入类型识别：**
- 类型 A：文字描述 → 提取需求 → 生成原型
- 类型 B：设计稿 → 分析设计 → 基于设计生成原型
- 类型 C：混合输入 → 融合两者 → 生成原型

**原型框架特点：**
- iframe + Tab 切换的分离式架构
- 键盘快捷键（← → 切换主题）
- **Live Reload 自动刷新** - 修改任何文件立即生效 - 缩放功能（+ - 按钮）
- 类似设计软件的工具栏
- 自动禁用缓存 - 无需手动清缓存

**⚠️ 自动刷新机制（live-server）：**

1. **工作原理：**
   - live-server 通过 WebSocket 监听文件变化
   - 任何 .html 文件修改 → 自动刷新浏览器
   - 包括 index.html（框架）和所有 theme/module 文件
   - 无需轮询，实时响应，延迟 < 1 秒

2. **用户体验：**
   - 修改任何原型文件 → 保存 → **自动刷新** ✅
   - 无需手动刷新 ❌ `Cmd + Shift + R`
   - 无需清除缓存
   - 开发效率大幅提升

3. **如果 live-server 不可用：**
   - 降级使用 Python SimpleHTTPServer
   - 需要手动刷新浏览器查看修改

---

### 第二步：原型对齐（两个阶段）

#### 阶段 2.1：主题选择对齐

**流程：**
```
生成 3 个主题 → 打开浏览器 → 询问用户选择
              ↓
        ┌─────┴─────┐
        ↓           ↓
    Branch A    Branch B
    （选定）    （调整）
        ↓           ↓
   进入阶段2.2  修改主题文件
                    ↓
              再次询问 → 循环
```

**关键原则：**
- 用户说"使用主题 X"后，**立即清理 index.html，移除未选择的主题**
- 然后进入阶段 2.2，开始模块设计
- 如果用户不满意，可以修改 theme-x.html
- 必须等用户明确选择主题才能进入下一阶段

**用户选择主题后的清理动作（必须执行）：**
- ✅ 删除未选择主题的 Tab 按钮（如选了 C，删除 A 和 B 的按钮）
- ✅ 删除未选择主题的 Tab 内容 div
- ✅ 从 TAB_IDS 数组中移除未选择的主题
- ✅ 可选：完全移除选中主题的 Tab，只保留模块 Tab

**修改主题时：**
- ✅ 直接 Edit 具体的 theme-a/b/c.html 文件
- ❌ 不要重新生成整个文件（会丢失已有改动）

---

#### 阶段 2.2：模块设计对齐 
**⚠️ 关键：用户选择主题后，必须进入此阶段，不能直接跳到 React 实现！**

**流程：**
```
1. 询问用户需要哪些模块/页面
2. 为每个模块生成独立的原型 HTML
3. 添加到 index.html 作为新的 Tab
4. 逐个让用户确认
5. 全部确认后 → React 实现
```

**具体操作：**

**步骤 1：询问需要的模块**
```
用户：使用主题 C
AI：好的！接下来设计具体的功能模块。

新闻后台发布系统通常包含以下模块：
1. 工作台（Dashboard）
2. 文章管理（列表、编辑）
3. 分类管理
4. 标签管理
5. 媒体库
6. 评论管理
7. 用户管理
8. 系统设置

请问你需要哪些？（可以选择或补充）
```

**步骤 2：为每个模块生成原型**
```bash
# 假设用户选择了：工作台、文章管理、分类管理

# 并发生成 3 个模块的原型 HTML
Write <项目名>/prototype/themes/module-dashboard.html
Write <项目名>/prototype/themes/module-articles.html
Write <项目名>/prototype/themes/module-categories.html
```

**步骤 3：清理并添加到 index.html** 
**⚠️ 关键：用户选择主题后，必须移除未选择的主题 Tab！**

假设用户选择了主题 C，需要修改 4 个地方：

1. **移除未选择的主题 Tab 按钮**
```html
<!-- 删除 theme-a 和 theme-b 的按钮，只保留 theme-c -->
<button id="tab-theme-c" class="tab-btn theme-tab ...">主题 C</button>
<!-- 添加分隔线 -->
<div class="tab-divider"></div>
<!-- 添加模块按钮 -->
<button id="tab-module-dashboard" class="tab-btn module-tab ...">工作台</button>
```

2. **移除未选择的主题 Tab 内容**
```html
<!-- 删除 theme-a 和 theme-b 的 div，只保留 theme-c -->
<div id="theme-c" class="tab-content">
    <iframe src="themes/theme-c.html"></iframe>
</div>
<!-- 添加模块内容 -->
<div id="module-dashboard" class="tab-content">
    <iframe src="themes/module-dashboard.html"></iframe>
</div>
```

3. **更新 Tab ID 数组**（移除未选择的主题）
```javascript
// ❌ 错误：保留所有主题
const TAB_IDS = ['theme-a', 'theme-b', 'theme-c', 'module-dashboard', ...];

// ✅ 正确：只保留选中的主题（可选）+ 模块
const TAB_IDS = ['theme-c', 'module-dashboard', 'module-articles', ...];
// 或者完全移除主题引用，只保留模块
const TAB_IDS = ['module-dashboard', 'module-articles', ...];
```

4. **更新默认显示的 Tab**
```javascript
// 确保初始显示第一个模块而不是主题
window.addEventListener('DOMContentLoaded', () => {
    showTab('module-dashboard');  // 显示第一个模块
});
```

**步骤 4：逐个让用户确认**
```
✅ 已生成 3 个模块原型，请逐个查看：

1. 工作台 - 统计卡片 + 文章列表
2. 文章管理 - 列表 + 编辑器
3. 分类管理 - 分类列表 + 新建编辑

请在浏览器中切换 Tab 查看，如有需要调整的模块，告诉我。
全部确认后，我将开始 React 实现。
```

**步骤 5：调整循环**

如果用户说"XX 模块需要调整"：
- Edit 对应的 module-xxx.html 文件
- 告知用户已更新
- 等待用户再次确认

如果用户说"都OK"、"确认"或"开始实现"：
- 立即进入第三步：React 实现

**关键原则：**
- ✅ 必须等用户确认全部模块后才能进入 React 实现
- ✅ 每个模块都要生成独立的原型 HTML
- ✅ 修改时使用 Edit，不要重新生成
- ❌ 不要跳过模块设计阶段直接实现

---

### 第三步：React 实现

**使用模板快速初始化：**
```bash
cp -r templates/react-base <项目名>
cd <项目名> && npm install
npm run dev > /tmp/dev-server.log 2>&1 &
```

**错误检测（强制执行）：**
```bash
# 等待编译完成
sleep 3

# 检测错误
tail -100 /tmp/dev-server.log | grep -iE "error"

# 如果有错误，立即修复后再打开浏览器
```

**⚠️ 端口检测机制（关键）：**

**问题背景：**
- Vite 配置的默认端口(如3000)可能已被占用
- Vite 会自动尝试下一个可用端口(3001, 3002...)
- **绝不能假设端口号**,必须从日志中读取实际端口

**正确做法：**
```bash
# 1. 等待服务器启动
sleep 3

# 2. 从日志中提取实际运行的端口
ACTUAL_PORT=$(tail -20 /tmp/dev-server.log | grep -oE 'localhost:[0-9]+' | head -1 | cut -d':' -f2)

# 3. 如果提取失败,再尝试其他格式
if [ -z "$ACTUAL_PORT" ]; then
  ACTUAL_PORT=$(tail -20 /tmp/dev-server.log | grep -oE 'http://.*:[0-9]+' | head -1 | grep -oE '[0-9]+$')
fi

# 4. 使用实际端口打开浏览器
if [ -n "$ACTUAL_PORT" ]; then
  open "http://localhost:$ACTUAL_PORT"
  echo "服务器运行在: http://localhost:$ACTUAL_PORT"
else
  echo "⚠️ 无法自动检测端口,请检查日志: tail -20 /tmp/dev-server.log"
fi
```

**典型日志格式示例：**
```
Port 3000 is in use, trying another one...
  VITE v6.4.1  ready in 345 ms
  ➜  Local:   http://localhost:3002/
```

**常见错误自动修复：**
- 导入路径错误 → 自动修正相对路径
- Zustand 无限循环 → 添加 useMemo
- Tailwind 配置问题 → 重装依赖

**实现流程（严格执行）：**

### 意图树结构（分布式）

意图树采用**分布式文件结构**，每个源文件都有对应的意图文件：

```
project/
├── intent/                          # 意图树文件夹（与 app 同级）
│   ├── PROJECT.md                   # 项目总体说明
│   └── src/                         # 与 app/src 结构完全对应
│       ├── pages/
│       │   ├── Articles.tsx.md      # 对应 app/src/pages/Articles.tsx
│       │   └── Dashboard.tsx.md
│       ├── components/
│       │   ├── Layout.tsx.md
│       │   └── ArticleFormModal.tsx.md
│       └── api/
│           └── services/
│               └── articles.ts.md   # 对应 app/src/api/services/articles.ts
└── app/                             # React 应用
    └── src/
```

**命名规则：**
- `intent/src/a.tsx.md` → `app/src/a.tsx`
- `intent/src/c/c.js.md` → `app/src/c/c.js`
- **严格 1:1 对应**，路径和文件名完全匹配

**意图文件固定结构（不可遗漏）：**

```markdown
# <文件名> - <简短描述>

## WHY（意图）
文件的意图和目的，为什么需要这个文件

## 组件树（UI 组件必填）
组件的层级结构，列出所有子组件

## API 接口（有数据交互必填）
列出需要的所有 API 接口（GET/POST/PUT/DELETE）

## Props 接口（组件必填）
组件的 Props 类型定义

## 数据类型（必填）
使用的 TypeScript 类型

## 依赖关系（必填）
依赖哪些其他文件

## 交互逻辑（有交互必填）
详细的交互处理函数和状态管理

## 实现状态（必填）- [ ] 任务1 - 未完成
- [x] 任务2 - 已完成
- [ ] 任务3 - 待修复
```

**类目说明：**
- **必填类目**：WHY、数据类型、依赖关系、实现状态
- **条件类目**：组件树（UI组件）、API接口（有数据交互）、Props接口（组件）、交互逻辑（有交互）
- **实现状态**：必须详细列出所有子任务，完成一个勾一个

### 工作流程（严格执行）
**🚫 铁律：不允许存在没有 intent 文件的源码文件！**

#### 阶段 0：检查完整性
```bash
# 检查是否有孤立的源文件（没有对应的意图文件）
# 必须先为所有现有源文件创建意图文件
```

#### 阶段 1：创建意图树
1. **创建文件夹结构**
   ```bash
   mkdir -p intent/src/{pages,components,api/services}
   ```

2. **创建 PROJECT.md**（项目总览）

3. **为所有计划的源文件创建意图文件**
   - ⚠️ 必须先写意图文件，再写源码
   - 使用固定的类目结构（不可遗漏）
   - 实现状态详细列出所有子任务

#### 阶段 2：按意图实现（循环执行）

**循环步骤：**

1. **读取意图文件**
   - 从 `intent/` 目录选择一个未完成的任务
   - 读取对应的意图文件，理解需求

2. **实现源码**
   - 严格按照意图文件实现
   - 如果需要修改其他文件，先更新那些文件的意图

3. **更新意图状态**
   - 完成一个任务，在意图文件中标记 `[x]`
   - 如果发现需要新增任务，先在意图中添加 `[ ]`

4. **检查是否完成**
   - 如果该文件所有任务都完成 → 继续下一个文件
   - 如果还有未完成任务 → 继续循环

5. **验证完整性**
   - 定期检查是否有新建的源文件缺少意图文件
   - 如果有，立即创建对应的意图文件

**循环终止条件：**
- 所有意图文件的实现状态都是 `[x]`
- 所有源文件都有对应的意图文件

### 核心原则：Intent 是第一公民 ⭐⭐
**Intent（意图树）的地位：**
1. **最高优先级** - Intent 是项目的唯一真相来源
2. **先于代码** - 任何代码编写前，必须先有 Intent 文件
3. **同步更新** - 代码修改前，必须先更新 Intent 文件
4. **完整覆盖** - 每个源文件都必须有对应的 Intent 文件
5. **状态追踪** - Intent 中的实现状态是进度的唯一指标
6. **🔄 驱动循环** - **Intent 状态清单 = AI 的工作清单**，必须按照清单逐个实现并实时更新

**决策优先级：**
```
Intent 文件 > 源代码 > 原型 > 需求描述
```

当发生冲突时，以 Intent 文件为准。如果 Intent 需要修改，先修改 Intent，再修改代码。

**❌ 严重错误示例：**
- **最严重**：创建了源文件但没有对应的 Intent 文件
- 直接修改源码，不先更新 Intent 文件
- Intent 文件的实现状态与实际不符
- Intent 文件缺少必填类目
- 意图文件路径与源文件不对应
- 页面直接 import mock 数据
- 完成任务后不在 Intent 中标记 `[x]`

### 完整性检查机制

**每次开始工作前必须执行：**
```bash
# 1. 列出所有源文件
find app/src -type f \( -name "*.tsx" -o -name "*.ts" \) | sort > /tmp/source_files.txt

# 2. 列出所有意图文件（去掉 .md 后缀）
find intent/src -type f -name "*.md" | sed 's|intent/|app/|' | sed 's|\.md$||' | sort > /tmp/intent_files.txt

# 3. 找出孤立的源文件（有源码但没有意图）
comm -23 /tmp/source_files.txt /tmp/intent_files.txt

# 如果有输出，说明存在孤立文件，必须先创建对应的意图文件！
```

**每次完成任务后必须执行：**
1. 检查该文件的意图状态是否全部标记为 `[x]`
2. 检查是否创建了新的源文件但忘记创建意图文件
3. 如果修改了其他文件，检查那些文件的意图是否需要更新

---

**✅ 正确示例：添加文章编辑功能**

```markdown
第 1 步：创建/更新意图文件
─────────────────────────────
Write intent/src/pages/Articles.tsx.md
→ 在组件树中添加 ArticleFormModal
→ 在实现状态中添加：
  - [ ] 添加 Modal 状态管理
  - [ ] 实现新建功能
  - [ ] 实现编辑功能
  - [ ] 实现删除功能

Write intent/src/components/ArticleFormModal.tsx.md
→ 定义组件意图、Props、表单字段、验证规则
→ 实现状态：
  - [ ] 定义 Props 接口
  - [ ] 实现表单布局
  - [ ] 实现提交逻辑

Write intent/src/api/services/articles.ts.md
→ 定义 API 接口：
  - [ ] POST /api/articles - createArticle()
  - [ ] PUT /api/articles/:id - updateArticle()
  - [ ] DELETE /api/articles/:id - deleteArticle()

第 2 步：实现数据层（从意图文件读取任务）
────────────────────────────────────────
Read intent/src/api/services/articles.ts.md
→ 看到需要实现 3 个 API 函数

Edit app/src/api/services/articles.ts
→ 实现 createArticle()
Edit intent/src/api/services/articles.ts.md ⚡ 立即更新
→ [ ] createArticle() 改为 [x] createArticle()

Edit app/src/api/services/articles.ts
→ 实现 updateArticle()
Edit intent/src/api/services/articles.ts.md ⚡ 立即更新
→ [ ] updateArticle() 改为 [x] updateArticle()

Edit app/src/api/services/articles.ts
→ 实现 deleteArticle()
Edit intent/src/api/services/articles.ts.md ⚡ 立即更新
→ [ ] deleteArticle() 改为 [x] deleteArticle()

Edit app/src/utils/request.ts
→ 添加 Mock 映射

第 3 步：实现组件（从意图文件读取任务）
────────────────────────────────────
Read intent/src/components/ArticleFormModal.tsx.md
→ 看到需要实现 3 个子任务

Write app/src/components/ArticleFormModal.tsx
→ 定义 Props 接口
Edit intent/src/components/ArticleFormModal.tsx.md ⚡ 立即更新
→ [ ] 定义 Props 接口 改为 [x] 定义 Props 接口

Edit app/src/components/ArticleFormModal.tsx
→ 实现表单布局
Edit intent/src/components/ArticleFormModal.tsx.md ⚡ 立即更新
→ [ ] 实现表单布局 改为 [x] 实现表单布局

Edit app/src/components/ArticleFormModal.tsx
→ 实现提交逻辑
Edit intent/src/components/ArticleFormModal.tsx.md ⚡ 立即更新
→ [ ] 实现提交逻辑 改为 [x] 实现提交逻辑

第 4 步：更新页面（从意图文件读取任务）
────────────────────────────────────
Read intent/src/pages/Articles.tsx.md
→ 看到需要实现 4 个功能

Edit app/src/pages/Articles.tsx
→ 添加 Modal 状态管理
Edit intent/src/pages/Articles.tsx.md ⚡ 立即更新
→ [ ] 添加 Modal 状态管理 改为 [x] 添加 Modal 状态管理

Edit app/src/pages/Articles.tsx
→ 实现新建功能
Edit intent/src/pages/Articles.tsx.md ⚡ 立即更新
→ [ ] 实现新建功能 改为 [x] 实现新建功能

Edit app/src/pages/Articles.tsx
→ 实现编辑功能
Edit intent/src/pages/Articles.tsx.md ⚡ 立即更新
→ [ ] 实现编辑功能 改为 [x] 实现编辑功能

Edit app/src/pages/Articles.tsx
→ 实现删除功能
Edit intent/src/pages/Articles.tsx.md ⚡ 立即更新
→ [ ] 实现删除功能 改为 [x] 实现删除功能

第 5 步：验证完成
─────────────────
Read intent/src/pages/Articles.tsx.md
→ 确认所有任务都是 [x]

Read intent/src/components/ArticleFormModal.tsx.md
→ 确认所有任务都是 [x]

Read intent/src/api/services/articles.ts.md
→ 确认所有任务都是 [x]

✅ 全部完成！
```

**⚠️ 数据层架构（关键）：**

```
src/
├── api/
│   ├── services/         # 接口函数（页面调用这里）
│   │   ├── articles.ts   # export async function getArticles()
│   │   ├── categories.ts
│   │   └── ...
│   └── mock/            # Mock 数据
│       ├── articles.ts   # export const mockArticles = [...]
│       └── ...
├── utils/
│   └── request.ts       # Axios 实例 + Mock 拦截器
└── pages/               # 页面只调用 services
```

**🚨 严重错误示例（绝不允许）：**

```typescript
// ❌❌❌ 错误！Service 层直接导入并返回 Mock 数据
import { mockArticles } from '../mock/articles';

export async function getArticles() {
  await new Promise(resolve => setTimeout(resolve, 300));
  return mockArticles;  // ❌ 写死了 Mock 数据！
}
```

**为什么这是严重错误？**
- 一旦有真实接口，所有 Service 文件都需要重写
- Mock 数据和真实 API 无法共存
- 无法通过环境变量切换
- 部署到生产环境时会引入 Mock 代码

**✅ 正确实现方式：**

**步骤 1：Service 层写真实的 API 调用**
```typescript
// src/api/services/articles.ts
import request from '../../utils/request';
import type { Article } from '../mock/articles';

export async function getArticles(): Promise<Article[]> {
  const response = await request.get('/api/articles');  // ✅ 真实 API 路径
  return response.data;
}

export async function getArticleById(id: string): Promise<Article> {
  const response = await request.get(`/api/articles/${id}`);
  return response.data;
}

export async function createArticle(data: Partial<Article>): Promise<Article> {
  const response = await request.post('/api/articles', data);
  return response.data;
}
```

**步骤 2：使用通用 request.ts 模板**

**🎯 模板位置：** `templates/react-base/src/utils/request.ts`

**使用步骤：**

1. **复制模板文件** → `src/utils/request.ts`
2. **导入项目的 Mock 数据**：
   ```typescript
   import { mockArticles } from '../api/mock/articles';
   import { mockUserProfile } from '../api/mock/users';
   ```
3. **配置 mockDataMap 映射**：
   ```typescript
   const mockDataMap: Record<string, any> = {
     'GET /api/articles': mockArticles,
     'GET /api/articles/:id': (config: any) => {
       const id = config.url?.split('/').pop();
       return mockArticles.find(a => a.id === id) || null;
     },
     'POST /api/articles': (config: any) => {
       const data = typeof config.data === 'string' ? JSON.parse(config.data) : config.data;
       return { ...data, id: `article_${Date.now()}` };
     },
     // ... 其他 API 映射
   };
   ```

**核心机制：** 使用 Custom Adapter 在 Mock 模式下直接返回数据，无需发起网络请求

**步骤 3：配置环境变量**
```bash
# .env
VITE_USE_MOCK=true        # 开发阶段使用 Mock
VITE_API_BASE_URL=/api

# .env.production
VITE_USE_MOCK=false       # 生产环境使用真实 API
VITE_API_BASE_URL=https://api.example.com
```

**关键原则：**
- ❌ **Service 层禁止直接 import mock 数据**
- ❌ **Service 层禁止在代码中写死 Mock 逻辑**
- ✅ **Service 层只写真实的 API 调用代码**
- ✅ **Mock 逻辑统一在 request.ts 的拦截器中处理**
- ✅ **通过环境变量 `VITE_USE_MOCK` 全局控制**
- ✅ **页面只调用 Service 层接口**

**切换方式：**
```bash
# 开发阶段 - 使用 Mock
VITE_USE_MOCK=true npm run dev

# 联调阶段 - 使用真实 API
VITE_USE_MOCK=false npm run dev

# 生产环境 - 自动使用真实 API
npm run build
```

**详细文档：** `references/react-best-practices.md`

---

### 第四步：生成 API 文档 
**⚠️ 重要：实现完成后，必须生成 API 文档！**

**为什么需要 API 文档？**
1. **单一数据源** - Intent 文件是前后端协作的唯一依据
2. **后端开发友好** - 后端 Agent 直接读取 intent 文件实现接口
3. **自动生成** - 从 intent 自动生成，无需手动维护
4. **前后端一致** - 避免文档和实现不同步

**🎯 核心原则：**
- ❌ **不要手写 React 组件维护 API 文档**（信息重复且难维护）
- ✅ **Intent 文件是唯一数据源**（`intent/src/api/` 目录）
- ✅ **自动扫描 intent 生成 markdown**（`API.md`）
- ✅ **前端渲染 markdown 展示**（`/api-docs` 路由）

---

**实现步骤：**

#### 1️⃣ 创建 API 文档生成脚本

**脚本位置：** `templates/react-base/scripts/generate-api-docs.js`

**功能：** 自动扫描 `intent/src/api/` 目录，提取接口信息和数据类型，生成 `API.md` 文档

**使用：** 将脚本复制到项目的 `scripts/` 目录，确保可执行权限

#### 2️⃣ 添加到 package.json

```json
{
  "scripts": {
    "dev": "vite",
    "build": "tsc && vite build",
    "docs": "node scripts/generate-api-docs.js"
  }
}
```

#### 3️⃣ 创建 API 文档展示页面

可以创建一个简单的页面来渲染 API.md，或者让用户直接查看 markdown 文件。

#### 4️⃣ 配置静态资源访问

**编辑 `vite.config.ts`，将 API.md 复制到 public：**

```typescript
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  publicDir: 'public',
  build: {
    rollupOptions: {
      input: {
        main: './index.html'
      }
    }
  }
});
```

**将 API.md 放到 public 目录（或在构建时复制）：**

```bash
# 生成并复制到 public
npm run docs && cp API.md public/
```

#### 5️⃣ 添加路由

```typescript
// App.tsx
import ApiDocs from './pages/ApiDocs';

<Route path="/api-docs" element={<ApiDocs />} />
```

---

**📋 完整工作流：**

1. **AI 实现功能时** → 创建 intent 文件（`intent/src/api/services/*.md`, `intent/src/api/mock/*.md`）
2. **运行文档生成** → `npm run docs` → 生成 `API.md`
3. **前端展示** → 访问 `/api-docs` 查看渲染后的文档
4. **后端开发** → 后端 Agent 读取 intent 文件实现真实接口

**✅ 优势：**
- 单一数据源（intent 文件）
- 自动生成，无需手动维护
- 前后端协作清晰
- 文档与实现始终同步

**完成后输出（关键）：**

**⚠️ 必须检测实际端口，不能硬编码！**

```bash
# 从日志中提取实际端口
ACTUAL_PORT=$(tail -20 /tmp/dev-server.log | grep -oE 'localhost:[0-9]+' | head -1 | cut -d':' -f2)

# 输出完成信息
echo "✅ 核心功能已完成！

🌐 应用访问：http://localhost:$ACTUAL_PORT
📚 API 文档：http://localhost:$ACTUAL_PORT/api-docs

**已实现功能：**
1. ✅ 首页 - 帖子列表
2. ✅ 帖子详情 - 完整内容展示
3. ✅ 话题广场 - 话题浏览
4. ✅ 个人中心 - 用户内容管理
5. ✅ API 文档 - 自动生成的接口文档 
**API 文档特点：**
- 📋 完整的 API 接口列表
- 📊 Mock 数据示例展示
- 🎨 清晰的数据类型定义
- 🤖 AI 友好的结构化展示"
```

**输出模板（复制使用）：**

```
✅ 项目完成！

🌐 访问地址：
- 应用首页：http://localhost:{从日志读取的实际端口}/
- API 文档：http://localhost:{从日志读取的实际端口}/api-docs
- 原型预览：http://localhost:8899/

📝 已实现功能：
[列出所有已完成的页面和功能]

💡 提示：
- 修改代码后会自动热更新
- API 文档页面可以查看所有接口和 Mock 数据
- 通过 VITE_USE_MOCK 环境变量切换 Mock/真实 API
```

**关键原则：**
- 必须从日志读取实际端口，不能硬编码
- 实现完成后生成 API 文档页面
- 自动扫描并展示所有接口和数据

---

## 核心改进（基于实战经验）

### 改进 1：新需求原型确认

**⚠️ 关键原则：新模块=新功能，必须先做原型**

**当用户提出新需求时，先判断：**
- **必须原型**：新模块、新页面、全新功能、涉及布局设计
  - 示例："开发育儿经验模块"、"添加设置页面"、"实现商品列表"
  - 原因：布局、内容组织、交互流程都需要用户确认
- **不需要原型**：Bug 修复、小改动、数据更新
  - 示例："修复按钮样式"、"更新接口地址"

**话术示例：**

**新模块开发（直接生成原型）：**
```
用户："接下来开发育儿经验模块"
→ "好的，我先生成原型展示一下布局结构"
  [立即生成原型，无需询问]
```

**新页面开发（给用户选择）：**
```
用户："添加设置页面"
→ "我建议先生成原型让你看看效果，还是直接开发？
   1. 生成原型（推荐）
   2. 直接开发"
```

---

### 改进 2：React 实现完整性检查

**完成后主动告知：**
```
✅ 已完成的页面（7个）：
- ✅ 登录页 (Login)
- ✅ 聊天列表 (ChatList)
...

⚠️ 以下功能尚未实现：
- ❌ 设置页面 - 原型中未包含

是否需要继续？
```

---

### 改进 3：意图树组件关系

**每个页面必须包含清晰的组件树：**
```markdown
## 组件树

ChatList (Page)
├── TopBar (内联)
├── ChatItem (内联) × N
└── TabBar (共享)

## 实现清单
- [ ] src/pages/ChatList/index.tsx
- [ ] src/components/TabBar/index.tsx
```

**详见：** `references/intent-tree-template.md`

---

## 技术栈

### 稳定版本（已在模板中配置）

- React 18.x + TypeScript
- Vite 5.x / 6.x
- Tailwind CSS **v3**（不是 v4）
- Ant Design 5.x（可选）
- Zustand / React Router

**⚠️ 不要手动配置，直接使用模板！**

---

## 参考文档体系

### 🚀 快速开始

- **`references/react-best-practices.md`** ⭐ - React 最佳实践
  - 模板使用指南
  - 错误检测机制
  - 常见问题解决
  - 实战案例

- **`references/fullstack-guide.md`** - 全栈开发者完整指南
  - 5 步完成前端开发
  - Mock → API 切换
  - 前后端协作

---

### 📘 开发模式

- **`references/traditional-dev.md`** - 传统开发模式完整指南
- **`references/intent-driven-dev.md`** - 意图驱动模式完整指南

---

### 🛠️ 核心机制

- **`references/intent-map.md`** - 意图映射层（解耦组件和 API）
- **`references/mock-to-api.md`** - Mock → API 完整流程
- **`references/state-trace.md`** - 状态追踪和管理

---

### 📚 资源库

- **`references/component-templates.md`** - 组件模板库
- **`references/intent-tree-template.md`** - 意图树模板
- **`references/tech-stack-best-practices.md`** - 技术栈最佳实践
- **`references/troubleshooting.md`** - 问题排查指南

---

### 📖 推荐阅读顺序

**第一次使用：**
1. 本文档（SKILL.md）- 了解整体
2. `react-best-practices.md` - 使用模板
3. `intent-driven-dev.md` - 理解工作流

**深入学习：**
1. `intent-map.md` - 理解解耦机制
2. `mock-to-api.md` - 前后端协作
3. `component-templates.md` - 参考模板

---

## 核心原则

### ✅ DO（推荐）

1. **使用原型模板** - 生成原型时必须用 `prototype-shell-template.html`，创建标准的 index.html + themes/ 结构
2. **批量操作自主完成** - 用户确认开始大任务后(如"确认"、"开始实现"),自主完成所有文件操作,不逐个等待确认
3. **并发写入文件** - 生成原型时,在一个消息中并发调用多个 Write
4. **精简输出内容** - 只显示粗粒度进度,避免打断用户
5. **使用 React 模板** - React 项目用 `templates/react-base`
6. **原型先行** - 需求不明确时先生成原型
7. **错误检测** - 启动前必须检查编译错误
8. **Intent 驱动** - 按照意图文件逐个实现并实时更新状态

### ❌ DON'T（避免）

1. **手动配置** - 不要从头创建项目
2. **跳过原型** - 不确定时不要直接写代码
3. **忽略错误** - 不要让用户看到编译错误
4. **直接调用 selector** - 会导致无限循环
5. **使用 Tailwind v4** - 不稳定
6. **单文件原型** - 必须使用 prototype-shell-template.html
7. **串行写入** - 应该并发执行
8. **详细日志** - 只显示进度和结果
9. **直接 open 文件** - 必须先启动 web 服务器

---

## 开发效率

使用模板后的效率提升：

| 环节 | 优化前 | 优化后 | 提升 |
|------|--------|--------|------|
| 项目初始化 | 5 分钟 | 30 秒 | 90% |
| 配置调试 | 30 分钟 | 0 分钟 | 100% |
| 错误修复 | 40 分钟 | 5 分钟 | 87.5% |
| **总计** | **2 小时** | **45 分钟** | **62.5%** |

---

## 获取帮助

遇到问题时的查阅顺序：

1. **`references/react-best-practices.md`** - 常见错误和解决方案
2. **`references/troubleshooting.md`** - 问题排查指南
3. **`CHANGELOG.md`** - 查看最新改进和已知问题

---

**最后更新：** 2024-03-25（第四次优化 - 模板和错误检测）
