# Frontend Skill - 前端研发全能助手

> React + Vite + Ant Design + Tailwind CSS 技术栈的前端研发全能助手

**特别适合：** 全栈开发者（不太懂前端）完成前端开发并自动生成 API Schema 给后端

## 🎯 核心价值

### 对全栈新手：
- ⚡ **2-4 小时完成前端** - 有完整的引导流程
- 🚀 **自动生成 API 文档** - 输出标准化的 YAML 给后端智能体
- 🔄 **Mock → API 无缝切换** - 不等后端，快速开发
- 🎨 **30秒看到效果** - 先原型后代码，快速验证

### 对有经验的前端：
- 📚 **两种开发模式** - 传统模式（需求明确）+ 意图驱动模式（探索性）
- 🛠️ **完整的工具链** - 意图映射、状态追踪、组件模板
- 📖 **最佳实践库** - React Hooks、性能优化、问题排查

## 📦 安装

```bash
tnpm i -g @antskill/harness-frontend
```

## 🚀 5 分钟快速开始（全栈新手推荐）

### 1. 告诉 AI 你的需求

```
我要做一个审批列表页面，显示申请人、金额、状态，有通过/拒绝按钮
```

### 2. AI 生成 30 秒静态原型

打开浏览器看效果 → 确认方向正确 ✅

### 3. AI 用 Mock 数据开发前端

2-4 小时完成可运行的前端应用 ✅

### 4. AI 自动生成 API Schema

```bash
npm run generate:api-schema
# 生成 api-schema.yaml
```

### 5. 交给后端智能体实现

前端切换到真实 API → 联调完成 ✅

**详细指南：** 查看 [`references/fullstack-guide.md`](./references/fullstack-guide.md)

## 🎯 核心特性

### 双模式开发

根据需求明确度和项目阶段，智能选择合适的开发模式：

#### 1. 传统开发模式（Traditional Mode）

适合需求明确、技术方案清晰的场景。

- ✅ 直接编写生产级代码
- ✅ 注重代码质量和最佳实践
- ✅ 完整的类型定义和错误处理
- ✅ 详细的代码审查清单

**使用场景：**
- 实现标准的 CRUD 功能
- 维护现有项目，修复 bug
- 代码审查和优化
- 明确的技术需求

#### 2. 意图驱动模式（Intent-Driven Mode）

适合需求不明确、需要快速验证想法的场景。

- 🚀 30 秒内生成静态原型
- 🎯 先渲染后逻辑，快速反馈
- 🔄 遇到不确定点生成多变体对比
- 📝 每个组件带有意图注释和假设说明

**使用场景：**
- 需求模糊，需要快速验证
- 探索性开发，尝试多种方案
- 用户难以用语言描述需求
- 需要原型辅助决策

## 🛠️ 技术栈

- **框架**: React 18+ (函数组件 + Hooks)
- **构建工具**: Vite 5+
- **UI 库**: Ant Design 5+
- **样式方案**: Tailwind CSS 3+
- **语言**: TypeScript
- **状态管理**: React Hooks / Zustand
- **路由**: React Router 6+

## 📚 使用示例

### 场景 1：明确需求（传统模式）

```
用户: 实现一个用户列表页面，包含搜索、分页、编辑和删除功能

AI: [使用传统开发模式]
    - 直接生成完整的组件代码
    - 包含 TypeScript 类型定义
    - 使用 Ant Design Table 组件
    - 集成搜索和分页功能
```

### 场景 2：模糊需求（意图驱动模式）

```
用户: 做个用户管理的东西

AI: [使用意图驱动模式]
    1. 30秒内生成静态 HTML 原型（3个变体）
       - 变体 A：简单列表视图
       - 变体 B：卡片网格视图
       - 变体 C：表格视图
    2. 等待用户选择
    3. 基于选择的变体编写真实代码
```

## 📖 文档结构

### 核心文档

- **`SKILL.md`** - 入口文档，介绍两种模式和使用指南

### 参考文档

- **`references/traditional-dev.md`** - 传统开发模式完整指南
  - 项目初始化详细步骤
  - 组件开发模板和最佳实践
  - 代码审查清单
  - 工作流程说明

- **`references/intent-driven-dev.md`** - 意图驱动模式完整指南
  - 30 秒原型生成规则
  - INTENT 注释规范
  - 多变体对比方法
  - 意图树维护指南
  - 状态分层管理

- **`references/component-templates.md`** - 组件模板库
  - 表单组件模板
  - 列表组件模板
  - 弹窗组件模板
  - 自定义 Hooks 模板

- **`references/troubleshooting.md`** - 问题排查指南
  - Vite 相关问题
  - React Hooks 相关问题
  - Ant Design 相关问题
  - Tailwind CSS 相关问题

### 模板文件

- **`templates/prototype-template.html`** - 静态原型模板
- **`templates/comparison-template.html`** - 变体对比模板
- **`templates/intent-tree.ts`** - 意图树模板
- **`templates/component-with-intent.tsx`** - 带意图注释的组件模板

## 🚀 快速开始

### 创建新项目

```bash
# 使用 Vite 创建项目
npm create vite@latest my-app -- --template react-ts

# 安装依赖
cd my-app
npm install react react-dom antd react-router-dom axios

# 配置 Tailwind CSS
npm install -D tailwindcss postcss autoprefixer
npx tailwindcss init -p

# 启动开发服务器
npm run dev
```

### 配置要点

#### Tailwind CSS 配置（避免与 Ant Design 冲突）

```javascript
// tailwind.config.js
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  corePlugins: {
    preflight: false,  // 禁用 preflight
  },
}
```

#### Vite 配置（路径别名）

```typescript
// vite.config.ts
import path from 'path'

export default defineConfig({
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
    },
  },
})
```

## 💡 核心能力

### 1. 项目初始化
快速搭建 React + Vite + Ant Design + Tailwind CSS 项目

### 2. 组件开发
智能生成高质量 React 组件，合理使用 Ant Design 和 Tailwind CSS

### 3. 代码审查
分析代码质量，提供针对性优化建议

### 4. 问题诊断
快速定位和解决前端开发中的各类问题

## 🎨 开发原则

### 样式混合使用策略

**Ant Design 优先：**
- UI 组件（按钮、表单、表格、弹窗等）
- 利用内置功能（表单验证、国际化）

**Tailwind CSS 补充：**
- 布局（flex、grid）
- 间距（margin、padding）
- 自定义颜色和背景
- 响应式设计

**示例：**
```tsx
<div className="flex items-center gap-4 p-6 bg-gray-50 rounded-lg">
  <Button type="primary">Ant Design 按钮</Button>
  <span className="text-sm text-gray-600">Tailwind 文本样式</span>
</div>
```

## 📊 模式对比

| 维度 | 传统开发模式 | 意图驱动模式 |
|------|------------|------------|
| **适用场景** | 需求明确 | 需求模糊 |
| **开发速度** | 中等 | 极快（原型） |
| **代码质量** | 生产级 | 迭代渐进 |
| **决策方式** | 语言描述 | 可视化感知 |
| **不确定处理** | 提问用户 | 生成多变体 |
| **适合人群** | 有经验的开发者 | 需要快速验证的团队 |

## 🔧 开发工具

本 skill 提供以下辅助工具：

- 静态原型生成器
- 变体对比页面生成器
- 意图树追踪系统
- 组件模板生成器

## 📝 开发

```bash
# 克隆项目
cd harness-frontend

# 安装依赖
tnpm install

# 本地测试（复制到 Claude skills 目录）
mkdir -p ~/.claude/skills/harness-frontend
cp -r . ~/.claude/skills/harness-frontend/

# 发布
npm publish
```

## 🤝 贡献

欢迎提交 Issue 和 Pull Request！

## 📄 License

MIT

---

Made with ❤️ by luguosheng
