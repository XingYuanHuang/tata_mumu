#!/bin/bash

# Skill 打包脚本
# 功能：将 skill 打包成 zip 压缩包，自动排除不必要的文件

set -e

# 获取脚本所在目录的父目录（项目根目录）
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
PROJECT_NAME="$(basename "$PROJECT_DIR")"

# 读取 package.json 中的版本号
if [ -f "$PROJECT_DIR/package.json" ]; then
    VERSION=$(node -p "require('$PROJECT_DIR/package.json').version")
else
    VERSION="latest"
fi

# 输出目录（项目根目录的父目录）
OUTPUT_DIR="$(dirname "$PROJECT_DIR")"
OUTPUT_FILE="$OUTPUT_DIR/${PROJECT_NAME}-${VERSION}.zip"

echo "📦 开始打包 Skill..."
echo "   项目: $PROJECT_NAME"
echo "   版本: $VERSION"
echo "   输出: $OUTPUT_FILE"
echo ""

# 切换到项目父目录（这样压缩包内会包含项目文件夹名）
cd "$OUTPUT_DIR"

# 删除旧的压缩包（如果存在）
rm -f "$OUTPUT_FILE"

# 使用 zip 打包，排除不需要的文件和目录
zip -r "$OUTPUT_FILE" "$PROJECT_NAME" \
    -x "*/.git/*" \
    -x "*/node_modules/*" \
    -x "*/.DS_Store" \
    -x "*.log" \
    -x "*/.claude/*" \
    -x "*/dist/*" \
    -x "*/build/*" \
    -x "*/.npm/*" \
    -x "*/.cache/*" \
    -x "*/coverage/*" \
    -x "*.tgz" \
    -x "*.tar.gz" \
    -x "*.zip" \
    > /dev/null

# 获取压缩包大小
if [[ "$OSTYPE" == "darwin"* ]]; then
    # macOS
    FILE_SIZE=$(ls -lh "$OUTPUT_FILE" | awk '{print $5}')
else
    # Linux
    FILE_SIZE=$(ls -lh "$OUTPUT_FILE" | awk '{print $5}')
fi

echo ""
echo "✅ 打包完成！"
echo ""
echo "📄 文件信息:"
echo "   路径: $OUTPUT_FILE"
echo "   大小: $FILE_SIZE"
echo ""
echo "🔍 查看内容: unzip -l $OUTPUT_FILE | head -30"
echo "📂 解压命令: unzip $OUTPUT_FILE"
echo ""
