#!/bin/bash

# Frontend Dev Skill Setup Script
# This script helps initialize the skill environment

echo "🎨 Frontend Development Assistant - Setup"
echo "=========================================="
echo ""

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is not installed. Please install Node.js first."
    exit 1
fi

echo "✅ Node.js detected: $(node --version)"

# Check if npm/tnpm is installed
if command -v tnpm &> /dev/null; then
    PKG_MANAGER="tnpm"
    echo "✅ tnpm detected: $(tnpm --version)"
elif command -v npm &> /dev/null; then
    PKG_MANAGER="npm"
    echo "✅ npm detected: $(npm --version)"
else
    echo "❌ No package manager found. Please install npm or tnpm."
    exit 1
fi

echo ""
echo "✨ Setup completed successfully!"
echo ""
echo "You can now use the frontend-dev skill with Claude Code."
