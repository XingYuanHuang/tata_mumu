/**
 * API Schema 自动生成器
 * 根据 INTENT_MAP 生成给后端的接口文档（YAML 格式）
 */

import fs from 'fs'
import path from 'path'

// 类型定义
interface IntentMapField {
  from: string
  confidence: number
  fallback?: any
  assumption?: string
}

interface IntentMapConfig {
  source: string
  intent?: string
  fields: Record<string, IntentMapField>
}

interface APISchema {
  endpoint: string
  method: string
  intent: string
  coreFields: FieldInfo[]
  assumedFields: FieldInfo[]
  experimentalFields: FieldInfo[]
}

interface FieldInfo {
  field: string
  componentField: string
  type: string
  required: boolean
  confidence: number
  assumption?: string
  usedBy: string
}

/**
 * 从 Intent Map 生成 API Schema
 */
export function generateAPISchema(intentMap: Record<string, IntentMapConfig>): APISchema[] {
  const schemas: APISchema[] = []

  for (const [componentName, mapping] of Object.entries(intentMap)) {
    const endpoint = mapping.source
    const method = 'GET'  // 默认 GET，可扩展

    const coreFields: FieldInfo[] = []
    const assumedFields: FieldInfo[] = []
    const experimentalFields: FieldInfo[] = []

    // 分析每个字段
    for (const [componentField, config] of Object.entries(mapping.fields)) {
      const fieldInfo: FieldInfo = {
        field: config.from,
        componentField,
        type: inferType(componentField, config),
        required: config.confidence >= 0.9,
        confidence: config.confidence,
        assumption: config.assumption,
        usedBy: componentName
      }

      // 按置信度分层
      if (config.confidence >= 0.9) {
        coreFields.push(fieldInfo)
      } else if (config.confidence >= 0.6) {
        assumedFields.push(fieldInfo)
      } else {
        experimentalFields.push(fieldInfo)
      }
    }

    schemas.push({
      endpoint,
      method,
      intent: mapping.intent || `为 ${componentName} 组件提供数据`,
      coreFields,
      assumedFields,
      experimentalFields
    })
  }

  return schemas
}

/**
 * 类型推断
 */
function inferType(fieldName: string, config: IntentMapField): string {
  // 从字段名推断类型
  if (fieldName.includes('id')) return 'string'
  if (fieldName.includes('amount') || fieldName.includes('count') || fieldName.includes('price')) return 'number'
  if (fieldName.includes('is') || fieldName.includes('has') || fieldName.includes('enabled')) return 'boolean'
  if (fieldName.includes('at') || fieldName.includes('time') || fieldName.includes('date')) return 'datetime'
  if (fieldName.includes('list') || fieldName.includes('items') || fieldName.includes('array')) return 'array'

  // 从 fallback 推断类型
  if (config.fallback !== undefined) {
    if (Array.isArray(config.fallback)) return 'array'
    if (typeof config.fallback === 'number') return 'number'
    if (typeof config.fallback === 'boolean') return 'boolean'
  }

  return 'string'  // 默认 string
}

/**
 * 导出为 YAML 格式
 */
export function exportToYAML(schemas: APISchema[]): string {
  return schemas.map(schema => {
    const parts: string[] = []

    // 接口说明
    parts.push(`# ${schema.intent}`)
    parts.push(`${schema.method} ${schema.endpoint}:`)
    parts.push('')

    // 核心字段
    if (schema.coreFields.length > 0) {
      parts.push('  ## 核心字段（confidence >= 0.9，后端必须实现）')
      parts.push('')

      schema.coreFields.forEach(field => {
        parts.push(`  ${field.field}:`)
        parts.push(`    type: ${field.type}`)
        parts.push(`    required: true`)
        parts.push(`    used_by: ${field.usedBy}`)
        parts.push(`    description: "${field.componentField} - 前端必需字段"`)
        parts.push('')
      })
    }

    // 假设字段
    if (schema.assumedFields.length > 0) {
      parts.push('  ## 假设字段（confidence 0.6-0.8，后端建议实现）')
      parts.push('')

      schema.assumedFields.forEach(field => {
        parts.push(`  ${field.field}:`)
        parts.push(`    type: ${field.type}`)
        parts.push(`    required: false`)
        parts.push(`    confidence: ${field.confidence}`)
        if (field.assumption) {
          parts.push(`    assumption: "${field.assumption}"`)
        }
        parts.push(`    used_by: ${field.usedBy}`)
        parts.push(`    note: "后端可以迭代实现此字段"`)
        parts.push('')
      })
    }

    // 实验性字段
    if (schema.experimentalFields.length > 0) {
      parts.push('  ## 实验性字段（confidence < 0.6，后端暂不实现）')
      parts.push('')

      schema.experimentalFields.forEach(field => {
        parts.push(`  ${field.field}:`)
        parts.push(`    type: ${field.type}`)
        parts.push(`    required: false`)
        parts.push(`    confidence: ${field.confidence}`)
        parts.push(`    note: "前端正在用 Mock 探索此字段的价值，暂不需要后端实现"`)
        parts.push('')
      })
    } else {
      parts.push('  ## 实验性字段')
      parts.push('  # 无实验性字段')
      parts.push('')
    }

    parts.push('---')
    parts.push('')

    return parts.join('\n')
  }).join('\n')
}

/**
 * 生成示例 JSON
 */
export function generateExampleJSON(schemas: APISchema[]): string {
  return schemas.map(schema => {
    const example: any = {}
    const entityName = schema.endpoint.split('/').pop() || 'data'

    // 生成示例数据
    const item: any = {}

    // 核心字段
    schema.coreFields.forEach(field => {
      const path = field.field.split('.')
      setNestedValue(item, path, generateMockValue(field.type, field.componentField))
    })

    // 假设字段
    schema.assumedFields.forEach(field => {
      const path = field.field.split('.')
      setNestedValue(item, path, generateMockValue(field.type, field.componentField))
    })

    example[entityName] = [item]

    return `# ${schema.intent}\n${schema.method} ${schema.endpoint} 返回格式：\n\n${JSON.stringify(example, null, 2)}`
  }).join('\n\n---\n\n')
}

function setNestedValue(obj: any, path: string[], value: any) {
  const last = path.pop()!
  const target = path.reduce((current, key) => {
    if (!current[key]) current[key] = {}
    return current[key]
  }, obj)
  target[last] = value
}

function generateMockValue(type: string, fieldName: string): any {
  switch (type) {
    case 'string':
      if (fieldName.includes('id')) return 'uuid-123'
      if (fieldName.includes('name')) return '张三'
      if (fieldName.includes('status')) return 'pending'
      return '示例文本'

    case 'number':
      if (fieldName.includes('amount')) return 12000
      if (fieldName.includes('count')) return 10
      return 0

    case 'boolean':
      return true

    case 'datetime':
      return new Date().toISOString()

    case 'array':
      return []

    default:
      return null
  }
}

/**
 * 完整的导出流程
 */
export function exportAPISchemaToFile(
  intentMap: Record<string, IntentMapConfig>,
  outputDir: string
) {
  // 生成 Schema
  const schemas = generateAPISchema(intentMap)

  // 导出 YAML
  const yamlContent = exportToYAML(schemas)
  const yamlPath = path.join(outputDir, 'api-schema.yaml')
  fs.writeFileSync(yamlPath, yamlContent, 'utf-8')
  console.log(`✅ API Schema (YAML) 已导出到: ${yamlPath}`)

  // 导出示例 JSON
  const exampleContent = generateExampleJSON(schemas)
  const examplePath = path.join(outputDir, 'api-examples.md')
  fs.writeFileSync(examplePath, exampleContent, 'utf-8')
  console.log(`✅ API 示例 (JSON) 已导出到: ${examplePath}`)

  return {
    yamlPath,
    examplePath,
    schemas
  }
}

// 使用示例
if (require.main === module) {
  // 导入你的 INTENT_MAP
  // const { INTENT_MAP } = require('../api/intent-map')

  // 示例数据
  const exampleIntentMap = {
    'ApprovalCard': {
      source: 'GET /api/approvals',
      intent: '为审批卡片提供数据',
      fields: {
        'id': { from: 'approval.id', confidence: 1.0 },
        'amount': { from: 'approval.amount', confidence: 1.0 },
        'applicant.name': { from: 'approval.applicant.name', confidence: 1.0 },
        'status': { from: 'approval.status', confidence: 1.0 },
        'urgency': {
          from: 'approval.priority',
          confidence: 0.7,
          assumption: '用户会根据紧急程度排序'
        }
      }
    }
  }

  const outputDir = path.join(process.cwd(), 'api', 'schemas')
  if (!fs.existsSync(outputDir)) {
    fs.mkdirSync(outputDir, { recursive: true })
  }

  exportAPISchemaToFile(exampleIntentMap, outputDir)
}
