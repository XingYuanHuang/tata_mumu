# 原型模板使用指南

## 模板位置

`templates/prototype-template.html` - 设计工具风格的原型模板

## 使用方法

每次生成原型时，按以下步骤操作：

### 步骤 1：复制模板内容

读取模板文件：
```
templates/prototype-template.html
```

### 步骤 2：替换占位符

模板中有以下占位符需要替换：

| 占位符 | 说明 | 示例 |
|--------|------|------|
| `{{PROJECT_NAME}}` | 项目名称 | `DJI 官网设计` |
| `{{CUSTOM_STYLES}}` | 页面特定的 CSS 样式 | 渐变、动画、悬停效果等 |
| `{{TAB_BUTTONS}}` | Tab 按钮 HTML | 见下方示例 |
| `{{TAB_CONTENTS}}` | 各个 Tab 的页面内容 | 见下方示例 |
| `{{TAB_IDS_ARRAY}}` | Tab ID 数组（JavaScript） | `['tech', 'minimal', 'dynamic']` |

### 步骤 3：填充内容

#### 3.1 填充项目名称

```html
<!-- 替换前 -->
<title>原型展示 - {{PROJECT_NAME}}</title>

<!-- 替换后 -->
<title>原型展示 - DJI 官网设计</title>
```

#### 3.2 填充自定义样式

```css
/* 示例：添加页面特定的样式 */
.hero-gradient {
    background: linear-gradient(135deg, #0a0a0a 0%, #1a1a2e 50%, #16213e 100%);
}

.product-card {
    transition: transform 0.3s ease;
}

.product-card:hover {
    transform: translateY(-8px);
}

@keyframes float {
    0%, 100% { transform: translateY(0px); }
    50% { transform: translateY(-20px); }
}
```

#### 3.3 填充 Tab 按钮

```html
<!-- 示例：3 个 Tab 按钮 -->
<button onclick="showTab('tech')" id="tab-tech"
    class="tab-btn px-4 py-1.5 text-sm font-medium bg-gray-700 text-white border-t-2 border-blue-500 rounded-t">
    🚀 科技感版本
</button>
<button onclick="showTab('minimal')" id="tab-minimal"
    class="tab-btn px-4 py-1.5 text-sm font-medium bg-gray-800 text-gray-400 border-t-2 border-transparent hover:text-gray-200 rounded-t">
    ✨ 简约版本
</button>
<button onclick="showTab('dynamic')" id="tab-dynamic"
    class="tab-btn px-4 py-1.5 text-sm font-medium bg-gray-800 text-gray-400 border-t-2 border-transparent hover:text-gray-200 rounded-t">
    🎨 动感版本
</button>
```

**注意事项：**
- 第一个按钮有 `active` 状态：`bg-gray-700 text-white border-blue-500`
- 其他按钮：`bg-gray-800 text-gray-400 border-transparent`
- 按钮 ID 格式：`tab-{tabId}`
- 使用 emoji 增加辨识度

#### 3.4 填充 Tab 内容

```html
<!-- Tab 1 -->
<div id="tech" class="tab-content active">
    <!-- 页面内容：导航栏 + Hero + 产品列表等 -->
    <nav>...</nav>
    <section>...</section>
    <section>...</section>
</div>

<!-- Tab 2 -->
<div id="minimal" class="tab-content">
    <!-- 另一种风格的页面内容 -->
    <nav>...</nav>
    <section>...</section>
</div>

<!-- Tab 3 -->
<div id="dynamic" class="tab-content">
    <!-- 第三种风格的页面内容 -->
    <nav>...</nav>
    <section>...</section>
</div>
```

**注意事项：**
- 第一个 Tab 要有 `active` 类
- Tab 的 ID 要和按钮的 `onclick` 参数一致

#### 3.5 填充 Tab ID 数组

```javascript
// 替换前
const tabs = {{TAB_IDS_ARRAY}};

// 替换后
const tabs = ['tech', 'minimal', 'dynamic'];
```

**注意：** 这个数组出现在 JavaScript 中两次，都要替换。

---

## 完整示例

### 示例场景：大疆官网原型

```html
<!-- 1. 项目名称 -->
<title>原型展示 - DJI 官网设计</title>
<span>DJI 官网设计</span>

<!-- 2. 自定义样式 -->
<style>
.hero-gradient {
    background: linear-gradient(135deg, #0a0a0a 0%, #1a1a2e 50%, #16213e 100%);
}
.floating {
    animation: float 3s ease-in-out infinite;
}
</style>

<!-- 3. Tab 按钮 -->
<button onclick="showTab('tech')" id="tab-tech"
    class="tab-btn px-4 py-1.5 text-sm font-medium bg-gray-700 text-white border-t-2 border-blue-500 rounded-t">
    🚀 科技感版本
</button>
<button onclick="showTab('minimal')" id="tab-minimal"
    class="tab-btn px-4 py-1.5 text-sm font-medium bg-gray-800 text-gray-400 border-t-2 border-transparent hover:text-gray-200 rounded-t">
    ✨ 简约版本
</button>
<button onclick="showTab('dynamic')" id="tab-dynamic"
    class="tab-btn px-4 py-1.5 text-sm font-medium bg-gray-800 text-gray-400 border-t-2 border-transparent hover:text-gray-200 rounded-t">
    🎨 动感版本
</button>

<!-- 4. Tab 内容 -->
<div id="tech" class="tab-content active">
    <nav class="bg-black/90">...</nav>
    <section class="hero-gradient min-h-screen">
        <h1>未来无所不能</h1>
        ...
    </section>
</div>

<div id="minimal" class="tab-content">
    <nav class="bg-white/90">...</nav>
    <section class="hero-minimal">
        <h1>专业影像无限可能</h1>
        ...
    </section>
</div>

<div id="dynamic" class="tab-content">
    <nav class="bg-purple-900/90">...</nav>
    <section class="hero-dynamic">
        <h1>FLY HIGHER</h1>
        ...
    </section>
</div>

<!-- 5. Tab ID 数组 -->
<script>
const tabs = ['tech', 'minimal', 'dynamic'];  // 第一处
...
const tabs = ['tech', 'minimal', 'dynamic'];  // 第二处
</script>
```

---

## 优势

✅ **节省时间** - 不用每次重写工具栏、标尺、Tab 切换逻辑
✅ **保持一致** - 所有原型的设计工具风格完全一致
✅ **专注内容** - AI 只需关注页面内容本身
✅ **易于维护** - 修改模板一次，所有新原型都受益

---

## 注意事项

1. **不要修改固定部分** - 工具栏、标尺、JavaScript 逻辑不要动
2. **保持占位符格式** - 使用 `{{}}` 包裹，便于识别
3. **Tab ID 一致性** - 确保按钮、内容、数组中的 ID 完全一致
4. **第一个 Tab 激活** - 第一个按钮和内容要有 `active` 状态

---

**最后更新：** 2024-03-25
