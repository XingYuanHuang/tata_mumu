// intent-tree.ts
// 这个文件追踪整个项目的意图树和决策历史
// 每次创建新组件时，必须在这里添加对应的意图节点

export interface IntentNode {
  // ============ 核心信息 ============
  /** 这个组件存在的原因（一句话） */
  intent: string

  /** 组件实现的文件路径 */
  implementation: string

  /** 用户应该有什么可观测的行为 */
  successSignal: string

  // ============ 置信度和状态 ============
  /**
   * 置信度 (0.0 - 1.0)
   * - 0.0-0.5: 实验性功能，随时可能删除
   * - 0.6-0.8: 假设成立，但需要验证
   * - 0.9-1.0: 核心功能，经过验证
   */
  confidence: number

  /**
   * 状态层级
   * - core: 核心业务，谨慎修改
   * - assumed: 假设成立，可重构
   * - experimental: 未验证，随时可删
   * - pending: 有矛盾，等待决策
   */
  layer: 'core' | 'assumed' | 'experimental' | 'pending'

  // ============ 假设和问题 ============
  /** 这个设计依赖的未验证假设 */
  assumptions: string[]

  /** 还没决策的开放问题 */
  openQuestions: string[]

  // ============ 影响范围 ============
  /** 修改此组件会影响哪些地方 */
  affects: string[]

  // ============ 决策历史 ============
  /** 创建时间 */
  createdAt: string

  /** 上次更新时间 */
  updatedAt: string

  /** 决策历史记录 */
  decisions: Decision[]
}

export interface Decision {
  /** 决策时间 */
  timestamp: string

  /** 需要决策的问题 */
  question: string

  /** 最终选择的方案 */
  chosen: string

  /** 备选方案 */
  alternatives: string[]

  /** 选择理由 */
  reason: string

  /** 决策者 */
  decidedBy: 'user' | 'team' | 'assumption'
}

// ============================================
// 意图树
// ============================================

export const intentTree: Record<string, IntentNode> = {
  // 示例：用户搜索栏组件
  'UserSearchBar': {
    intent: '让用户能够快速搜索和筛选用户列表',
    implementation: 'src/components/UserSearchBar/index.tsx',
    successSignal: '输入关键词后 300ms 内看到筛选结果',

    confidence: 0.6,
    layer: 'assumed',

    assumptions: [
      '搜索不需要后端支持，前端内存筛选足够快',
      '用户习惯输入完整词汇，而非拼音首字母',
      '用户列表数据不超过 1000 条',
    ],

    openQuestions: [
      '是否需要搜索历史记录？',
      '是否需要高级筛选（多条件组合）？',
      '搜索结果是否需要高亮关键词？',
    ],

    affects: [
      'src/pages/UserManagement.tsx',
      'src/hooks/useUserFilter.ts',
    ],

    createdAt: '2026-03-25T10:30:00Z',
    updatedAt: '2026-03-25T10:30:00Z',

    decisions: [],
  },

  // 示例：用户列表组件
  'UserList': {
    intent: '展示用户列表，支持排序、分页和批量操作',
    implementation: 'src/components/UserList/index.tsx',
    successSignal: '用户能够看到清晰的列表，并能快速找到目标用户',

    confidence: 0.8,
    layer: 'core',

    assumptions: [
      '用户数据结构稳定，不会频繁变动',
      '分页大小 20 条适合大部分场景',
    ],

    openQuestions: [
      '是否需要支持列的显示/隐藏？',
      '是否需要支持拖拽排序？',
    ],

    affects: [
      'src/pages/UserManagement.tsx',
      'src/components/UserSearchBar/index.tsx',
    ],

    createdAt: '2026-03-25T09:00:00Z',
    updatedAt: '2026-03-25T11:15:00Z',

    decisions: [
      {
        timestamp: '2026-03-25T11:15:00Z',
        question: '删除操作是否需要二次确认？',
        chosen: '需要弹窗确认',
        alternatives: [
          '直接删除',
          '批量删除时才确认',
        ],
        reason: '防止误操作，删除用户是敏感操作',
        decidedBy: 'user',
      },
    ],
  },

  // 你可以在这里继续添加更多组件的意图节点...
}

// ============================================
// 辅助函数
// ============================================

/**
 * 添加新的意图节点
 */
export function addIntentNode(key: string, node: Omit<IntentNode, 'createdAt' | 'updatedAt' | 'decisions'>): void {
  intentTree[key] = {
    ...node,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    decisions: [],
  }
}

/**
 * 更新意图节点
 */
export function updateIntentNode(key: string, updates: Partial<IntentNode>): void {
  if (!intentTree[key]) {
    throw new Error(`Intent node "${key}" not found`)
  }

  intentTree[key] = {
    ...intentTree[key],
    ...updates,
    updatedAt: new Date().toISOString(),
  }
}

/**
 * 记录决策
 */
export function recordDecision(key: string, decision: Omit<Decision, 'timestamp'>): void {
  if (!intentTree[key]) {
    throw new Error(`Intent node "${key}" not found`)
  }

  intentTree[key].decisions.push({
    ...decision,
    timestamp: new Date().toISOString(),
  })

  intentTree[key].updatedAt = new Date().toISOString()
}

/**
 * 获取所有低置信度的节点（需要关注）
 */
export function getLowConfidenceNodes(): [string, IntentNode][] {
  return Object.entries(intentTree).filter(([_, node]) => node.confidence < 0.6)
}

/**
 * 获取所有待决策的节点
 */
export function getPendingNodes(): [string, IntentNode][] {
  return Object.entries(intentTree).filter(
    ([_, node]) => node.layer === 'pending' || node.openQuestions.length > 0
  )
}

/**
 * 查找会影响指定文件的所有组件
 */
export function findAffectedBy(filePath: string): [string, IntentNode][] {
  return Object.entries(intentTree).filter(([_, node]) =>
    node.affects.includes(filePath)
  )
}
