# 原型框架模板使用指南

## 快速开始

模板文件：`templates/prototype-shell-template.html`

**核心概念：** 读取模板 → 替换占位符 → 生成 index.html

## 占位符说明

| 占位符 | 说明 | 示例 |
|--------|------|------|
| `{{PROJECT_NAME}}` | 项目名称 | "育儿论坛" |
| `{{VIEWPORT_SIZE}}` | 视口尺寸 | "1920 × 1080" |
| `{{TAB_BUTTONS}}` | Tab 按钮 HTML | 见下文 |
| `{{TAB_CONTENTS}}` | Tab 内容 HTML | 见下文 |
| `{{TAB_IDS_ARRAY}}` | Tab ID 数组 | `["theme-a", "module-products"]` |

---

## 第一阶段：主题选择（3选1）

### Step 1: 读取模板

```bash
Read ${SKILL_BASE_DIR}/templates/prototype-shell-template.html
```

### Step 2: 准备占位符内容

**Tab 按钮：**
```html
<button onclick="showTab('theme-a')" id="tab-theme-a" class="tab-btn theme-tab px-4 py-1.5 text-sm font-medium">
    🎨 温馨家庭风格
</button>
<button onclick="showTab('theme-b')" id="tab-theme-b" class="tab-btn theme-tab px-4 py-1.5 text-sm font-medium">
    🎨 现代简约风格
</button>
<button onclick="showTab('theme-c')" id="tab-theme-c" class="tab-btn theme-tab px-4 py-1.5 text-sm font-medium">
    🎨 社区活力风格
</button>
```

**Tab 内容：**
```html
<div id="theme-a" class="tab-content active">
    <iframe src="themes/theme-a.html" title="温馨家庭风格"></iframe>
</div>
<div id="theme-b" class="tab-content">
    <iframe src="themes/theme-b.html" title="现代简约风格"></iframe>
</div>
<div id="theme-c" class="tab-content">
    <iframe src="themes/theme-c.html" title="社区活力风格"></iframe>
</div>
```

**Tab ID 数组：**
```javascript
["theme-a", "theme-b", "theme-c"]
```

### Step 3: 替换并输出

```bash
# 替换占位符
{{PROJECT_NAME}} → "育儿论坛"
{{VIEWPORT_SIZE}} → "1920 × 1080"
{{TAB_BUTTONS}} → 上面的按钮 HTML
{{TAB_CONTENTS}} → 上面的内容 HTML
{{TAB_IDS_ARRAY}} → ["theme-a", "theme-b", "theme-c"]

# 输出
Write <项目名>/prototype/index.html
```

---

## 第二阶段：模块设计（逐个确认）

用户选定主题后（如 theme-c），更新 index.html：

### Step 1: 准备新的占位符内容

**Tab 按钮：**（只保留选中的主题 + 模块 Tab）
```html
<!-- 已选主题 -->
<button onclick="showTab('theme-c')" id="tab-theme-c" class="tab-btn theme-tab px-4 py-1.5 text-sm font-medium">
    🏡 首页预览
</button>

<!-- 分隔线 -->
<div class="tab-divider"></div>

<!-- 模块 Tab -->
<button onclick="showTab('module-products')" id="tab-module-products" class="tab-btn module-tab px-4 py-1.5 text-sm font-medium">
    📦 产品展示
</button>
<button onclick="showTab('module-news')" id="tab-module-news" class="tab-btn module-tab px-4 py-1.5 text-sm font-medium">
    📰 新闻动态
</button>
```

**Tab 内容：**
```html
<!-- 主题预览 -->
<div id="theme-c" class="tab-content">
    <iframe src="themes/theme-c.html" title="首页预览"></iframe>
</div>

<!-- 模块预览 -->
<div id="module-products" class="tab-content active">
    <iframe src="modules/products.html" title="产品展示"></iframe>
</div>
<div id="module-news" class="tab-content">
    <iframe src="modules/news.html" title="新闻动态"></iframe>
</div>
```

**Tab ID 数组：**
```javascript
["theme-c", "module-products", "module-news"]
```

### Step 2: 直接编辑 index.html

⚠️ **第二阶段不需要重新生成整个文件，直接 Edit 三个地方：**

1. **编辑 Tab 按钮区域**（`<div class="flex space-x-1 flex-1 overflow-x-auto">` 内部）
2. **编辑 Tab 内容区域**（`<div class="viewport">` 内部）
3. **编辑 Tab ID 数组**（`const TAB_IDS = ...`）

---

## Tab 样式规范

### 主题 Tab（蓝色系）
```html
<button class="tab-btn theme-tab ...">🎨 主题名</button>
```
- 用于第一阶段
- 激活：蓝色边框 + 深蓝背景

### 模块 Tab（绿色系）
```html
<button class="tab-btn module-tab ...">📦 模块名</button>
```
- 用于第二阶段
- 激活：绿色边框 + 深绿背景

### 分隔线
```html
<div class="tab-divider"></div>
```
- 用于分隔主题和模块

---

## 功能特性

| 功能 | 说明 |
|------|------|
| **键盘快捷键** | `←` `→` 切换 Tab |
| **URL 参数** | `?tab=xxx` 保持状态 |
| **缩放** | `−` `+` 调整视图，`重置` 恢复 |
| **自动刷新** | 每 2 秒检测 iframe 文件变化 |

---

## 命名规范

| 类型 | ID 格式 | 示例 |
|------|---------|------|
| 主题 | `theme-{字母}` | `theme-a`, `theme-b`, `theme-c` |
| 模块 | `module-{名称}` | `module-products`, `module-news` |

---

## 目录结构

```
<项目名>/
└── prototype/
    ├── index.html        # 由模板生成
    ├── themes/           # 主题文件
    │   ├── theme-a.html
    │   ├── theme-b.html
    │   └── theme-c.html
    └── modules/          # 模块文件
        ├── products.html
        └── news.html
```

---

## 最佳实践

1. ✅ **第一阶段用模板生成** - 保证框架统一
2. ✅ **第二阶段用 Edit** - 只修改三个地方
3. ✅ **主题/模块文件只包含内容** - 不含外层框架
4. ✅ **模块继承主题样式** - 配色、组件保持一致

---

## 常见问题

**Q: 如何添加新模块？**
A: Edit 三个地方 → Tab 按钮 + Tab 内容 + ID 数组

**Q: 缩放后布局乱了？**
A: 点击"重置"按钮恢复 100%

**Q: 自动刷新不工作？**
A: 检查文件路径是否正确，浏览器控制台查看错误
