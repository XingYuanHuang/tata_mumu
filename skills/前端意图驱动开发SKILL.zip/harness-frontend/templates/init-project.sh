#!/bin/bash

# Frontend Skill 项目快速初始化脚本
# 使用方法：bash init-project.sh <project-name>

set -e

PROJECT_NAME=$1

if [ -z "$PROJECT_NAME" ]; then
  echo "❌ 请提供项目名称"
  echo "使用方法: bash init-project.sh <project-name>"
  exit 1
fi

echo "🚀 开始创建项目: $PROJECT_NAME"
echo ""

# 1. 创建 Vite 项目
echo "📦 步骤 1/5: 创建 Vite + React + TypeScript 项目..."
npm create vite@latest $PROJECT_NAME -- --template react-ts
cd $PROJECT_NAME

# 2. 安装依赖
echo ""
echo "📦 步骤 2/5: 安装依赖..."
npm install

# 核心依赖
npm install antd react-router-dom @tanstack/react-query axios

# Tailwind CSS（固定 3.x 版本，避免 4.x 兼容性问题）
npm install -D tailwindcss@^3.4.0 postcss autoprefixer

# 开发工具
npm install -D @types/node cross-env tsx

# 3. 复制配置文件模板
echo ""
echo "📝 步骤 3/5: 复制配置文件..."

SKILL_DIR="$(cd "$(dirname "$0")/.." && pwd)"

# 复制根目录配置文件
cp "$SKILL_DIR/templates/postcss.config.js.template" postcss.config.js
cp "$SKILL_DIR/templates/tailwind.config.js.template" tailwind.config.js
cp "$SKILL_DIR/templates/vite.config.ts.template" vite.config.ts
cp "$SKILL_DIR/templates/tsconfig.json.template" tsconfig.json
cp "$SKILL_DIR/templates/.env.development.template" .env.development

# 更新 package.json scripts
cp "$SKILL_DIR/templates/package.json.example" package.json.tmp
node --input-type=module -e "
import { readFileSync, writeFileSync } from 'fs';
const pkg = JSON.parse(readFileSync('./package.json', 'utf8'));
const tmp = JSON.parse(readFileSync('./package.json.tmp', 'utf8'));
pkg.scripts = tmp.scripts;
pkg.dependencies = {...pkg.dependencies, ...tmp.dependencies};
pkg.devDependencies = {...pkg.devDependencies, ...tmp.devDependencies};
writeFileSync('package.json', JSON.stringify(pkg, null, 2));
"
rm package.json.tmp

# 复制 src 目录文件
cp "$SKILL_DIR/templates/main.tsx.template" src/main.tsx
cp "$SKILL_DIR/templates/App.tsx.template" src/App.tsx
cp "$SKILL_DIR/templates/index.css.template" src/index.css

# 4. 创建目录结构
echo ""
echo "📁 步骤 4/5: 创建目录结构..."
mkdir -p src/{components,pages,hooks,services,stores,types,utils,router,api}
mkdir -p src/api/{mock,schemas}
mkdir -p scripts

echo "✅ 目录结构已创建"

# 5. 重新安装依赖（确保新添加的依赖生效）
echo ""
echo "📦 步骤 5/5: 安装更新的依赖..."
npm install

echo ""
echo "🎉 项目初始化完成！"
echo ""
echo "📋 下一步："
echo "  cd $PROJECT_NAME"
echo "  npm run dev          # 启动开发服务器"
echo "  npm run dev:mock     # 使用 Mock 数据启动"
echo ""
echo "✨ 已配置："
echo "  ✅ Ant Design 样式"
echo "  ✅ Tailwind CSS（与 Ant Design 兼容）"
echo "  ✅ 路径别名 @/"
echo "  ✅ TypeScript 严格模式"
echo "  ✅ Mock/API 环境切换"
echo ""
