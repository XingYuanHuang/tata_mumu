/**
 * INTENT: [一句话说明这个组件存在的原因和价值]
 *   示例：让用户能够快速搜索和筛选用户列表
 *
 * SUCCESS_SIGNAL: [用户应该有什么可观测的行为]
 *   示例：输入关键词后 300ms 内看到筛选结果
 *
 * CONFIDENCE: [0.0 - 1.0，表示这个设计的置信度]
 *   - 0.0-0.5: 实验性功能，随时可能删除
 *   - 0.6-0.8: 假设成立，但需要验证
 *   - 0.9-1.0: 核心功能，经过验证
 *
 * ASSUMPTION: [这个设计依赖的未验证假设]
 *   - 假设搜索不需要后端支持，前端内存筛选足够快
 *   - 假设用户习惯输入完整词汇，而非拼音首字母
 *   - 假设列表数据不超过 1000 条
 *
 * OPEN_QUESTION: [还没决策的问题]
 *   - 是否需要搜索历史记录？
 *   - 是否需要高级筛选（多条件组合）？
 *   - 搜索结果是否需要高亮关键词？
 *
 * AFFECTS: [修改此组件会影响哪些地方]
 *   - src/pages/UserManagement.tsx
 *   - src/hooks/useUserFilter.ts
 */

import { FC, useState, useCallback, useEffect } from 'react'

// ============================================
// 类型定义
// ============================================

export interface ComponentNameProps {
  // Props 定义
  data?: any[]
  onAction?: (item: any) => void
  loading?: boolean
  className?: string
}

// ============================================
// 组件实现
// ============================================

const ComponentName: FC<ComponentNameProps> = ({
  data = [],
  onAction,
  loading = false,
  className = '',
}) => {
  // ============================================
  // 状态管理
  // ============================================

  const [state, setState] = useState<any>(null)

  // ============================================
  // 事件处理
  // ============================================

  const handleAction = useCallback(() => {
    // 事件处理逻辑
    // WHY: [解释为什么这样处理]
    // ASSUMPTION: [说明假设的前提条件]

    onAction?.(state)
  }, [state, onAction])

  // ============================================
  // 副作用
  // ============================================

  useEffect(() => {
    // 副作用逻辑
    // WHY: [解释为什么需要这个副作用]
    // ASSUMPTION: [说明假设的前提条件]

    return () => {
      // 清理逻辑
      // WHY: [解释为什么需要清理]
    }
  }, [])

  // ============================================
  // 渲染
  // ============================================

  if (loading) {
    return <div>加载中...</div>
  }

  return (
    <div className={`component-name ${className}`}>
      {/* 组件内容 */}
      <div>
        {data.map((item, index) => (
          <div key={item.id || index}>
            {/* 列表项 */}
          </div>
        ))}
      </div>

      {/* 操作按钮 */}
      <button onClick={handleAction}>
        执行操作
      </button>
    </div>
  )
}

export default ComponentName

// ============================================
// 使用示例（可选）
// ============================================

/**
 * 基础用法：
 *
 * <ComponentName
 *   data={items}
 *   onAction={handleAction}
 * />
 *
 * ----
 *
 * 带加载状态：
 *
 * <ComponentName
 *   data={items}
 *   loading={isLoading}
 *   onAction={handleAction}
 * />
 */
