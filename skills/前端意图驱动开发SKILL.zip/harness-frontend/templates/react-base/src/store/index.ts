import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface AppState {
  // 在这里定义状态
  count: number;

  // 在这里定义 actions
  increment: () => void;
  decrement: () => void;
}

export const useStore = create<AppState>()(
  persist(
    (set) => ({
      // 初始状态
      count: 0,

      // Actions
      increment: () => set((state) => ({ count: state.count + 1 })),
      decrement: () => set((state) => ({ count: state.count - 1 })),
    }),
    {
      name: 'app-storage', // localStorage key
      partialize: (state) => ({ count: state.count }), // 只持久化需要的字段
    }
  )
);
