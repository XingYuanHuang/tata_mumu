import { BrowserRouter, Routes, Route } from 'react-router-dom';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<div className="p-8">欢迎使用 React 应用模板</div>} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
