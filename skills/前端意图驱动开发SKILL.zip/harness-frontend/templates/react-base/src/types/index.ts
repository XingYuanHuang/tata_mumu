// 在这里定义项目的 TypeScript 类型

export interface Example {
  id: number;
  name: string;
}
