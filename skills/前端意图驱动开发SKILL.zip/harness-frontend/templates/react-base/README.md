# React 项目基础模板

## 技术栈

- **React 18** - 前端框架
- **TypeScript** - 类型安全
- **Vite** - 构建工具
- **React Router v6** - 路由管理
- **Zustand** - 状态管理
- **Tailwind CSS v3** - 样式框架
- **Google Fonts** - Inter + JetBrains Mono

## 目录结构

```
src/
├── api/          # API 接口和 Mock 数据
│   └── mock/     # Mock 数据
├── components/   # 共享组件
├── pages/        # 页面组件
├── store/        # Zustand 状态管理
├── types/        # TypeScript 类型定义
├── App.tsx       # 根组件
├── main.tsx      # 入口文件
└── index.css     # 全局样式
```

## 安装依赖

```bash
npm install
```

## 开发

```bash
npm run dev
```

## 构建

```bash
npm run build
```

## 预览

```bash
npm run preview
```

## 注意事项

### Zustand 最佳实践

**❌ 错误写法（会导致无限循环）：**
```tsx
const articles = useStore((state) => state.getArticles());
```

**✅ 正确写法：**
```tsx
// 方式 1：直接获取数据
const articles = useStore((state) => state.articles);

// 方式 2：使用 useMemo 缓存函数结果
const getArticles = useStore((state) => state.getArticles);
const articles = useMemo(() => getArticles(), [getArticles]);
```

### 路径引用规范

- 同级目录：`./Component`
- 上一级：`../Component`
- 上两级：`../../Component`

### Tailwind CSS 配置

- 使用 Tailwind v3（稳定版）
- PostCSS 配置已优化
- 避免在 `@layer base` 中使用 `@apply`

## License

MIT
