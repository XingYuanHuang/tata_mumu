# Frontend Skill 项目模板

本目录包含 React + Vite + Ant Design + Tailwind CSS 项目的所有配置文件模板。

## 🚀 快速开始

### 方法 1：使用自动化脚本（推荐）

```bash
# 在 frontend-skill 目录下执行
bash templates/init-project.sh my-project-name
cd my-project-name
npm run dev
```

一行命令完成项目初始化！

### 方法 2：手动复制模板

```bash
# 1. 创建 Vite 项目
npm create vite@latest my-project -- --template react-ts
cd my-project

# 2. 复制配置文件（去掉 .template 后缀）
cp ../templates/postcss.config.js.template postcss.config.js
cp ../templates/tailwind.config.js.template tailwind.config.js
cp ../templates/vite.config.ts.template vite.config.ts
cp ../templates/tsconfig.json.template tsconfig.json
cp ../templates/.env.development.template .env.development
cp ../templates/main.tsx.template src/main.tsx
cp ../templates/App.tsx.template src/App.tsx
cp ../templates/index.css.template src/index.css

# 3. 安装依赖
npm install
npm install antd react-router-dom @tanstack/react-query axios
npm install -D tailwindcss postcss autoprefixer cross-env tsx

# 4. 启动
npm run dev
```

## 📦 模板文件说明

| 文件 | 用途 | 关键配置 |
|------|------|----------|
| `postcss.config.js.template` | PostCSS 配置 | 支持 Tailwind CSS |
| `tailwind.config.js.template` | Tailwind 配置 | 禁用 preflight，避免与 Ant Design 冲突 |
| `vite.config.ts.template` | Vite 配置 | 路径别名 `@/` → `src/` |
| `tsconfig.json.template` | TypeScript 配置 | 路径映射、严格模式 |
| `main.tsx.template` | 应用入口 | **正确的样式导入顺序** |
| `App.tsx.template` | 根组件 | **正确的 locale 路径** |
| `index.css.template` | 全局样式 | Tailwind 指令 |
| `.env.development.template` | 环境变量 | Mock/API 切换 |
| `package.json.example` | 依赖清单 | 所有必需依赖 |

## ⚠️ 为什么必须使用模板？

这些模板已经解决了常见的样式问题：

### 问题 1：页面没有任何样式

**原因：**
- 缺少 Ant Design 样式导入
- 缺少 PostCSS 配置
- locale 导入路径错误

**模板中的解决方案：**

```typescript
// main.tsx.template
import 'antd/dist/reset.css'  // ← 必须添加
import './index.css'
```

```typescript
// App.tsx.template
import zhCN from 'antd/es/locale/zh_CN'  // ← 使用 es 路径
```

```javascript
// postcss.config.js.template
export default {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
}
```

### 问题 2：Tailwind 与 Ant Design 样式冲突

**原因：**
- Tailwind 的 preflight 会重置 Ant Design 的基础样式

**模板中的解决方案：**

```javascript
// tailwind.config.js.template
corePlugins: {
  preflight: false,  // ← 禁用 preflight
}
```

### 问题 3：路径别名 `@/` 不生效

**原因：**
- 需要同时配置 Vite 和 TypeScript

**模板中的解决方案：**

```typescript
// vite.config.ts.template
resolve: {
  alias: {
    '@': path.resolve(__dirname, './src')
  }
}
```

```json
// tsconfig.json.template
"paths": {
  "@/*": ["src/*"]
}
```

## ✅ 模板包含的配置

- ✅ Ant Design 样式导入顺序正确
- ✅ Ant Design locale 使用正确路径
- ✅ PostCSS 配置完整
- ✅ Tailwind preflight 已禁用
- ✅ 路径别名在 Vite 和 TypeScript 中都配置好
- ✅ 环境变量配置（Mock/API 切换）
- ✅ 所有必需的 npm 依赖

## 📝 使用 init-project.sh 脚本的优势

1. **零配置** - 一行命令完成所有设置
2. **避免遗漏** - 自动复制所有必需文件
3. **依赖完整** - 自动安装所有依赖
4. **目录规范** - 自动创建标准目录结构
5. **即开即用** - 创建后立即可以运行

## 🎯 验证配置是否正确

创建项目后，运行以下命令验证：

```bash
# 1. 检查是否有 PostCSS 配置
ls postcss.config.js

# 2. 检查 Tailwind 配置中是否禁用了 preflight
grep "preflight: false" tailwind.config.js

# 3. 启动开发服务器
npm run dev
```

打开浏览器，检查：
- ✅ Ant Design 组件有样式
- ✅ Tailwind 工具类生效
- ✅ 没有控制台错误

## 📚 相关文档

- `../references/traditional-dev.md` - 传统开发模式指南
- `../references/intent-driven-dev.md` - 意图驱动开发模式指南
- `../example-approval-app/` - 完整示例项目

---

**记住：不要手动配置，直接使用模板！**
